<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<!-- ============================
     HEADER — Logo + Nav (one line)
     ============================ -->
<header id="site-header">
    <div class="container">
        <div class="header-inner">

            <!-- Logo — LEFT -->
            <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="site-logo" aria-label="<?php bloginfo('name'); ?>">
                <?php
                if ( has_custom_logo() ) {
                    the_custom_logo();
                } else {
                    echo '<span style="font-family:\'Plus Jakarta Sans\',sans-serif;font-size:1.5rem;font-weight:800;color:var(--gold);">Advertza</span>';
                }
                ?>
            </a>

            <!-- Nav — RIGHT -->
            <nav class="main-nav" aria-label="Primary Navigation">
                <a href="<?php echo home_url('/'); ?>"          <?php if(is_front_page()) echo 'class="active"'; ?>>Home</a>
                <a href="<?php echo home_url('/services'); ?>"  <?php if(is_post_type_archive('service')||get_post_type()==='service') echo 'class="active"'; ?>>Services</a>
                <a href="<?php echo home_url('/industries'); ?>"<?php if(is_post_type_archive('industry')||get_post_type()==='industry') echo 'class="active"'; ?>>Industries</a>
                <a href="<?php echo home_url('/about'); ?>"     <?php if(is_page('about')) echo 'class="active"'; ?>>About</a>
                <a href="<?php echo home_url('/blog'); ?>"      <?php if(is_home()||is_single()) echo 'class="active"'; ?>>Blog</a>
                <a href="<?php echo home_url('/contact'); ?>"   <?php if(is_page('contact')) echo 'class="active"'; ?>>Contact</a>
                <a href="<?php echo home_url('/contact'); ?>" class="nav-cta">Get Free Audit</a>
            </nav>

            <!-- Mobile Toggle -->
            <button class="menu-toggle" aria-label="Toggle Menu" aria-expanded="false" id="menu-toggle">
                <span></span><span></span><span></span>
            </button>
        </div>

        <!-- Mobile Menu -->
        <nav class="mobile-nav" id="mobile-nav" aria-label="Mobile Navigation">
            <a href="<?php echo home_url('/'); ?>">Home</a>
            <a href="<?php echo home_url('/services'); ?>">Services</a>
            <a href="<?php echo home_url('/industries'); ?>">Industries</a>
            <a href="<?php echo home_url('/about'); ?>">About</a>
            <a href="<?php echo home_url('/blog'); ?>">Blog</a>
            <a href="<?php echo home_url('/contact'); ?>">Contact</a>
            <a href="<?php echo home_url('/contact'); ?>" style="color:var(--gold);font-weight:700;">Get Free Audit →</a>
        </nav>
    </div>
</header>
