<?php
/**
 * Blog Archive / Index — advertza.co.in/blog/
 */
get_header();
?>
<style>
/* ── Blog Archive: inline CSS (cache-safe) ── */
.adv-blog-hero{background:linear-gradient(135deg,hsl(220,20%,10%) 0%,hsl(220,20%,16%) 100%);padding:4.5rem 0 3.5rem;text-align:center;position:relative;overflow:hidden;}
.adv-blog-hero-bar{position:absolute;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,#C9A84C,#e0c070,#C9A84C);}
.adv-blog-hero-dots{position:absolute;inset:0;opacity:.04;background-image:radial-gradient(#C9A84C 1px,transparent 1px);background-size:32px 32px;pointer-events:none;}
.adv-blog-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:2rem;margin:0;}
.adv-blog-card{background:#fff;border:1.5px solid #e8e8ec;border-radius:12px;overflow:hidden;text-decoration:none;color:inherit;display:flex;flex-direction:column;transition:box-shadow .25s,transform .25s,border-color .25s;}
.adv-blog-card:hover{box-shadow:0 12px 36px -10px rgba(0,0,0,.14);transform:translateY(-3px);border-color:rgba(201,168,76,.4);}
.adv-blog-card-img{width:100%;height:220px;overflow:hidden;position:relative;flex-shrink:0;background:linear-gradient(135deg,#111827,#1e2a3a);}
.adv-blog-card-img img{width:100%;height:100%;object-fit:cover;object-position:center;display:block;transition:transform .4s ease;}
.adv-blog-card:hover .adv-blog-card-img img{transform:scale(1.04);}
.adv-blog-placeholder{width:100%;height:100%;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:.65rem;background:linear-gradient(135deg,#111827,#1e2a3a);}
.adv-blog-placeholder-txt{font-size:.6rem;font-weight:800;letter-spacing:.14em;color:rgba(201,168,76,.5);text-transform:uppercase;}
.adv-blog-cat-pill{position:absolute;bottom:.75rem;left:.75rem;background:rgba(10,12,20,.78);backdrop-filter:blur(6px);color:#C9A84C;font-size:.65rem;font-weight:700;text-transform:uppercase;letter-spacing:.07em;padding:.3rem .75rem;border-radius:100px;border:1px solid rgba(201,168,76,.3);}
.adv-blog-card-body{padding:1.35rem 1.5rem 1.5rem;display:flex;flex-direction:column;flex:1;}
.adv-blog-title{font-size:1rem;font-weight:700;color:#1a1d2e;line-height:1.45;margin-bottom:.6rem;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;}
.adv-blog-excerpt{font-size:.82rem;color:#64748b;line-height:1.65;flex:1;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden;margin-bottom:1.1rem;}
.adv-blog-footer{display:flex;align-items:center;justify-content:space-between;gap:.5rem;flex-wrap:wrap;margin-top:auto;padding-top:1rem;border-top:1px solid #e8e8ec;}
.adv-blog-read-more{font-size:.8rem;font-weight:700;color:#C9A84C;}
.adv-blog-meta{font-size:.75rem;color:#94a3b8;}
.adv-nav-links{display:flex;align-items:center;justify-content:center;gap:.5rem;flex-wrap:wrap;margin-top:3.5rem;}
.adv-nav-links .page-numbers{display:inline-flex;align-items:center;justify-content:center;min-width:2.25rem;height:2.25rem;padding:0 .5rem;border-radius:8px;font-size:.85rem;font-weight:600;border:1.5px solid #e8e8ec;color:#1a1d2e;text-decoration:none;transition:background .2s,border-color .2s,color .2s;}
.adv-nav-links .page-numbers:hover,.adv-nav-links .page-numbers.current{background:#C9A84C;border-color:#C9A84C;color:#fff;}
.adv-nav-links .page-numbers.dots{border:none;background:none;}
@media(max-width:960px){.adv-blog-grid{grid-template-columns:repeat(2,1fr);gap:1.5rem;}}
@media(max-width:580px){.adv-blog-grid{grid-template-columns:1fr;gap:1.25rem;}.adv-blog-card-img{height:190px;}}
</style>

<main>

<!-- ── Hero ──────────────────────────────────────────── -->
<section class="adv-blog-hero">
    <div class="adv-blog-hero-bar"></div>
    <div class="adv-blog-hero-dots"></div>
    <div class="container" style="position:relative;">
        <span style="display:inline-block;font-size:.7rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:#C9A84C;margin-bottom:.6rem;">Blog</span>
        <h1 style="font-size:clamp(2rem,5vw,3rem);font-weight:800;color:#fff;margin:.4rem 0 1rem;line-height:1.2;">
            Marketing <span style="background:linear-gradient(135deg,#C9A84C,#e0c070);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;">Insights</span>
        </h1>
        <p style="color:rgba(255,255,255,.6);max-width:38rem;margin:0 auto;font-size:1.05rem;line-height:1.7;">
            Expert tips, strategies &amp; case studies to help your eCommerce brand grow profitably.
        </p>
    </div>
</section>

<!-- ── Posts Grid ─────────────────────────────────────── -->
<section style="padding:4rem 0 6rem;background:#fff;">
    <div class="container">
        <?php if ( have_posts() ) : ?>

        <div class="adv-blog-grid">
            <?php while ( have_posts() ) : the_post();
                $cats      = get_the_category();
                $cat_name  = ! empty($cats) ? $cats[0]->name : 'Marketing';
                $read_time = ceil( str_word_count( strip_tags( get_the_content() ) ) / 200 ) ?: 1;
                $thumb_url = get_the_post_thumbnail_url( get_the_ID(), 'advertza-blog-thumb' );
            ?>

            <a href="<?php the_permalink(); ?>" class="adv-blog-card">

                <!-- Image -->
                <div class="adv-blog-card-img">
                    <?php if ( $thumb_url ) : ?>
                        <img src="<?php echo esc_url($thumb_url); ?>"
                             alt="<?php echo esc_attr(get_the_title()); ?>"
                             loading="lazy">
                    <?php else : ?>
                        <div class="adv-blog-placeholder">
                            <svg width="34" height="34" viewBox="0 0 24 24" fill="none" stroke="rgba(201,168,76,0.45)" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
                                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
                            </svg>
                            <span class="adv-blog-placeholder-txt">Advertza</span>
                        </div>
                    <?php endif; ?>
                    <!-- Category pill on image -->
                    <span class="adv-blog-cat-pill"><?php echo esc_html($cat_name); ?></span>
                </div>

                <!-- Body -->
                <div class="adv-blog-card-body">
                    <h3 class="adv-blog-title"><?php the_title(); ?></h3>
                    <p class="adv-blog-excerpt">
                        <?php echo esc_html( wp_trim_words( get_the_excerpt() ?: get_the_content(), 20 ) ); ?>
                    </p>
                    <div class="adv-blog-footer">
                        <span class="adv-blog-read-more">Read More →</span>
                        <span class="adv-blog-meta">
                            <?php echo get_the_date('M j, Y'); ?>
                            &nbsp;·&nbsp;<?php echo $read_time; ?> min
                        </span>
                    </div>
                </div>

            </a>

            <?php endwhile; ?>
        </div>

        <!-- Pagination -->
        <div class="adv-nav-links">
            <?php the_posts_pagination( array( 'prev_text' => '← Prev', 'next_text' => 'Next →' ) ); ?>
        </div>

        <?php else : ?>

        <!-- Empty state -->
        <div style="text-align:center;padding:6rem 0;">
            <div style="width:4.5rem;height:4.5rem;background:linear-gradient(135deg,#111827,#1e2a3a);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 1.5rem;">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="rgba(201,168,76,.7)" stroke-width="1.5"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
            </div>
            <h3 style="font-size:1.5rem;font-weight:800;margin-bottom:.75rem;">No posts yet</h3>
            <p style="color:#64748b;max-width:28rem;margin:0 auto 2rem;">Our marketing insights are on their way. Check back soon or talk to our team.</p>
            <a href="<?php echo home_url('/contact'); ?>" class="btn-primary" style="display:inline-flex;">Talk to Our Team →</a>
        </div>

        <?php endif; ?>
    </div>
</section>

<!-- ── CTA ───────────────────────────────────────────── -->
<section class="cta-section" style="padding-top:0;">
    <div class="container">
        <div class="cta-inner">
            <h2>Ready to Scale Your Brand?</h2>
            <p>Get a free marketing audit. No commitments — just real growth insights.</p>
            <div class="cta-btns">
                <a href="<?php echo home_url('/contact'); ?>" class="btn-primary">Get Your Free Audit →</a>
            </div>
        </div>
    </div>
</section>

</main>
<?php get_footer(); ?>
