<?php
/**
 * Industries Archive
 */
get_header();
?>
<main>
    <section class="page-hero">
        <div class="container">
            <span class="section-label">Industries We Serve</span>
            <h1>Marketing for <span class="text-gradient-gold">Every Industry</span></h1>
            <p>Deep expertise across the most competitive eCommerce verticals. We understand your industry's unique challenges.</p>
        </div>
    </section>

    <section style="padding:3rem 0 5rem;background:var(--surface-warm);">
        <div class="container">
            <div class="services-grid">
                <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
                <a href="<?php the_permalink(); ?>" class="service-card">
                    <div class="service-icon"><?php echo esc_html( get_post_meta( get_the_ID(), 'icon', true ) ?: '🏭' ); ?></div>
                    <h3 class="service-title"><?php the_title(); ?></h3>
                    <p class="service-desc"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 18 ) ); ?></p>
                    <span class="service-link">Learn More →</span>
                </a>
                <?php endwhile; else: ?>
                <?php
                $industries = array(
                    array( 'icon' => '👗', 'title' => 'Fashion & Apparel', 'desc' => 'Scale your fashion brand with targeted ads, influencer partnerships, and conversion-focused campaigns.', 'href' => '/industries/fashion' ),
                    array( 'icon' => '💄', 'title' => 'Beauty & Cosmetics', 'desc' => 'Grow your beauty brand with creative storytelling and precision-targeted performance marketing.', 'href' => '/industries/beauty' ),
                    array( 'icon' => '🏡', 'title' => 'Home & Garden', 'desc' => 'Drive qualified buyers to your home & garden products through strategic multi-channel marketing.', 'href' => '/industries/home-garden' ),
                    array( 'icon' => '📱', 'title' => 'Electronics & Tech', 'desc' => 'Navigate competitive tech markets with data-driven advertising that reaches buyers ready to purchase.', 'href' => '/industries/electronics' ),
                    array( 'icon' => '💪', 'title' => 'Health & Wellness', 'desc' => 'Build trust and drive conversions in the health & wellness space with compliant, effective campaigns.', 'href' => '/industries/health-wellness' ),
                    array( 'icon' => '🍕', 'title' => 'Food & Beverage', 'desc' => 'Grow your F&B brand with appetite-inducing creative and campaigns that convert browsers into buyers.', 'href' => '/industries/food-beverage' ),
                    array( 'icon' => '🐾', 'title' => 'Pet Supplies', 'desc' => 'Tap into the passionate pet owner market with targeted campaigns that drive repeat purchases.', 'href' => '/industries/pet-supplies' ),
                    array( 'icon' => '💍', 'title' => 'Jewelry', 'desc' => 'Showcase your jewelry with stunning creative and targeted campaigns that reach gift-givers and luxury buyers.', 'href' => '/industries/jewelry' ),
                    array( 'icon' => '⚽', 'title' => 'Sporting Goods', 'desc' => 'Reach active consumers and drive sales with performance marketing built for sporting goods brands.', 'href' => '/industries/sporting-goods' ),
                    array( 'icon' => '✨', 'title' => 'Custom Solutions', 'desc' => "Don't see your industry? We create custom marketing solutions for any eCommerce vertical.", 'href' => '/industries/custom' ),
                );
                foreach ( $industries as $ind ) : ?>
                <a href="<?php echo home_url( $ind['href'] ); ?>" class="service-card">
                    <div class="service-icon"><?php echo $ind['icon']; ?></div>
                    <h3 class="service-title"><?php echo esc_html( $ind['title'] ); ?></h3>
                    <p class="service-desc"><?php echo esc_html( $ind['desc'] ); ?></p>
                    <span class="service-link">Learn More →</span>
                </a>
                <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <section class="cta-section">
        <div class="container">
            <div class="cta-inner">
                <h2>Don't See Your Industry?</h2>
                <p>We work with brands across all eCommerce verticals. Let's talk about your specific needs.</p>
                <div class="cta-btns">
                    <a href="<?php echo home_url('/contact'); ?>" class="btn-primary">Get a Custom Strategy →</a>
                </div>
            </div>
        </div>
    </section>
</main>
<?php get_footer(); ?>
