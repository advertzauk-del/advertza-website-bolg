<?php
/**
 * Template Name: Site Audit Tools
 * Two powerful tools: 1) Full Site Audit, 2) Content Analyzer
 * Similar to pageaudit.com & heytony.ca/content-analyzer
 */
get_header(); ?>

<style>
/* ── Site Audit Page Styles ── */
.audit-hero {
  background: linear-gradient(135deg, #0f172a 0%, #1e293b 60%, #0f172a 100%);
  padding: 5rem 0 3rem;
  text-align: center;
}
.audit-hero h1 {
  font-size: clamp(2rem, 5vw, 3.5rem);
  font-weight: 900;
  color: #fff;
  margin-bottom: 0.75rem;
}
.audit-hero h1 span { color: var(--gold); }
.audit-hero p {
  color: #94a3b8;
  font-size: 1.15rem;
  max-width: 600px;
  margin: 0 auto;
}

/* ── Tab Switch ── */
.audit-tabs {
  display: flex;
  gap: 0;
  max-width: 640px;
  margin: 2.5rem auto 0;
  background: #0f172a;
  border-radius: 999px;
  padding: 5px;
  border: 1px solid rgba(255,255,255,0.1);
}
.audit-tab-btn {
  flex: 1;
  padding: 0.75rem 1.5rem;
  border: none;
  border-radius: 999px;
  font-weight: 700;
  font-size: 0.9rem;
  cursor: pointer;
  transition: all 0.25s;
  background: transparent;
  color: #94a3b8;
}
.audit-tab-btn.active {
  background: linear-gradient(135deg, hsl(43,78%,47%), hsl(43,78%,57%));
  color: #fff;
  box-shadow: 0 4px 20px rgba(0,0,0,0.3);
}

/* ── Tool Panels ── */
.audit-section { padding: 3rem 0 5rem; background: #f8fafc; min-height: 60vh; }
.audit-panel { display: none; }
.audit-panel.active { display: block; }

.audit-card {
  background: #fff;
  border-radius: 1.25rem;
  box-shadow: 0 4px 40px rgba(0,0,0,0.08);
  overflow: hidden;
  max-width: 860px;
  margin: 0 auto 2.5rem;
}
.audit-card-header {
  background: linear-gradient(135deg, #0f172a, #1e293b);
  padding: 1.75rem 2rem;
  display: flex;
  align-items: center;
  gap: 1rem;
}
.audit-card-header .icon {
  width: 48px; height: 48px;
  background: linear-gradient(135deg, hsl(43,78%,47%), hsl(43,78%,57%));
  border-radius: 12px;
  display: flex; align-items: center; justify-content: center;
  font-size: 1.5rem;
  flex-shrink: 0;
}
.audit-card-header h2 { color: #fff; font-size: 1.4rem; font-weight: 800; margin: 0 0 0.2rem; }
.audit-card-header p  { color: #94a3b8; font-size: 0.875rem; margin: 0; }
.audit-card-body { padding: 2rem; }

/* Input Area */
.audit-input-row {
  display: flex; gap: 0.75rem; flex-wrap: wrap;
}
.audit-input-row input, .audit-input-row textarea {
  flex: 1;
  min-width: 200px;
  padding: 0.875rem 1.125rem;
  border: 1.5px solid #e2e8f0;
  border-radius: var(--radius);
  font-size: 1rem;
  font-family: inherit;
  color: #0f172a;
  background: #f8fafc;
  transition: border 0.2s;
  outline: none;
}
.audit-input-row input:focus, .audit-input-row textarea:focus {
  border-color: hsl(43,78%,47%);
  background: #fff;
}
.audit-input-row textarea { min-height: 120px; resize: vertical; }
.audit-run-btn {
  padding: 0.875rem 2rem;
  background: linear-gradient(135deg, hsl(43,78%,47%), hsl(43,78%,57%));
  color: #fff;
  border: none;
  border-radius: var(--radius);
  font-weight: 700;
  font-size: 1rem;
  cursor: pointer;
  transition: opacity 0.2s, transform 0.15s;
  white-space: nowrap;
}
.audit-run-btn:hover { opacity: 0.9; transform: translateY(-1px); }
.audit-run-btn:disabled { opacity: 0.6; cursor: not-allowed; transform: none; }

/* Results */
.audit-results { margin-top: 2rem; display: none; }
.audit-results.show { display: block; }

.score-ring-wrap {
  display: flex;
  align-items: center;
  gap: 2rem;
  flex-wrap: wrap;
  margin-bottom: 2rem;
}
.score-ring {
  position: relative;
  width: 130px; height: 130px; flex-shrink: 0;
}
.score-ring svg { transform: rotate(-90deg); }
.score-ring .score-num {
  position: absolute;
  inset: 0;
  display: flex; flex-direction: column;
  align-items: center; justify-content: center;
  font-size: 2rem; font-weight: 900; color: #0f172a;
  line-height: 1;
}
.score-ring .score-num small { font-size: 0.7rem; color: #64748b; font-weight: 500; margin-top: 2px; }
.score-summary h3 { font-size: 1.25rem; font-weight: 800; color: #0f172a; margin-bottom: 0.5rem; }
.score-summary p  { color: #64748b; font-size: 0.9rem; }

/* Check Items */
.check-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
  gap: 1rem;
  margin-bottom: 1.5rem;
}
.check-item {
  display: flex;
  align-items: flex-start;
  gap: 0.75rem;
  padding: 1rem;
  border-radius: 0.75rem;
  border: 1.5px solid transparent;
  background: #f8fafc;
}
.check-item.pass  { border-color: #bbf7d0; background: #f0fdf4; }
.check-item.warn  { border-color: #fde68a; background: #fffbeb; }
.check-item.fail  { border-color: #fecaca; background: #fef2f2; }
.check-item.info  { border-color: #bfdbfe; background: #eff6ff; }
.check-icon { font-size: 1.25rem; flex-shrink: 0; margin-top: 1px; }
.check-item .check-label { font-weight: 700; font-size: 0.875rem; color: #0f172a; display: block; }
.check-item .check-val   { font-size: 0.8rem; color: #64748b; margin-top: 0.1rem; display: block; }

/* Content Analysis */
.content-stats-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
  gap: 1rem;
  margin-bottom: 1.5rem;
}
.stat-box {
  background: #f8fafc;
  border: 1.5px solid #e2e8f0;
  border-radius: 0.875rem;
  padding: 1rem;
  text-align: center;
}
.stat-box .stat-num { font-size: 2rem; font-weight: 900; color: var(--gold); display: block; }
.stat-box .stat-lbl { font-size: 0.75rem; color: #64748b; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em; }

/* Keyword Table */
.keyword-table {
  width: 100%;
  border-collapse: collapse;
  font-size: 0.875rem;
  margin-bottom: 1.5rem;
}
.keyword-table th {
  text-align: left;
  padding: 0.625rem 0.875rem;
  background: #f1f5f9;
  color: #475569;
  font-weight: 700;
  font-size: 0.75rem;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  border-bottom: 1px solid #e2e8f0;
}
.keyword-table td {
  padding: 0.625rem 0.875rem;
  border-bottom: 1px solid #f1f5f9;
  color: #0f172a;
  vertical-align: middle;
}
.keyword-table tr:hover td { background: #f8fafc; }
.kw-bar-wrap { background: #e2e8f0; border-radius: 999px; height: 6px; width: 100px; overflow: hidden; }
.kw-bar      { background: linear-gradient(90deg, hsl(43,78%,47%), hsl(43,78%,57%)); border-radius: 999px; height: 6px; transition: width 0.6s; }

/* Suggestions */
.suggestion-list { list-style: none; margin: 0; padding: 0; }
.suggestion-list li {
  display: flex; gap: 0.75rem; align-items: flex-start;
  padding: 0.875rem 1rem;
  border-radius: 0.75rem;
  margin-bottom: 0.5rem;
  background: #f8fafc;
}
.suggestion-list li.critical { background: #fef2f2; }
.suggestion-list li.warning  { background: #fffbeb; }
.suggestion-list li.good     { background: #f0fdf4; }
.suggestion-list li .sug-icon { font-size: 1.15rem; flex-shrink: 0; margin-top: 2px; }
.suggestion-list li .sug-text { font-size: 0.9rem; color: #334155; }
.suggestion-list li .sug-text strong { display: block; color: #0f172a; font-weight: 700; font-size: 0.875rem; }

/* Loading spinner */
.audit-loading {
  display: none;
  text-align: center;
  padding: 2.5rem 0;
  color: #64748b;
}
.audit-loading.show { display: block; }
.spin {
  width: 48px; height: 48px;
  border: 4px solid #e2e8f0;
  border-top-color: hsl(43,78%,47%);
  border-radius: 50%;
  margin: 0 auto 1rem;
  animation: spin 0.8s linear infinite;
}
@keyframes spin { to { transform: rotate(360deg); } }

/* Export btn */
.audit-export-row {
  display: flex; gap: 0.75rem; flex-wrap: wrap;
  margin-top: 1.5rem; padding-top: 1.5rem;
  border-top: 1px solid #e2e8f0;
}
.btn-export {
  padding: 0.625rem 1.25rem;
  border-radius: var(--radius);
  font-weight: 700;
  font-size: 0.875rem;
  border: 1.5px solid #e2e8f0;
  background: #fff;
  color: #0f172a;
  cursor: pointer;
  transition: background 0.2s;
}
.btn-export:hover { background: #f1f5f9; }
.btn-export.gold {
  background: linear-gradient(135deg, hsl(43,78%,47%), hsl(43,78%,57%));
  color: #fff; border-color: transparent;
}
.btn-export.gold:hover { opacity: 0.9; }

@media (max-width: 640px) {
  .audit-card-body { padding: 1.25rem; }
  .score-ring-wrap { flex-direction: column; align-items: flex-start; gap: 1rem; }
}
</style>

<!-- ── Hero ── -->
<section class="audit-hero">
  <div class="container">
    <h1>⚡ Site <span>Audit Tools</span></h1>
    <p>Two powerful tools to analyse your website's health and content quality — instantly, for free.</p>

    <div class="audit-tabs">
      <button class="audit-tab-btn active" onclick="switchTab('seo')">🔍 Site Audit</button>
      <button class="audit-tab-btn" onclick="switchTab('content')">📝 Content Analyzer</button>
    </div>
  </div>
</section>

<!-- ── Tools ── -->
<section class="audit-section">
  <div class="container">

    <!-- ════ TOOL 1: SITE AUDIT ════ -->
    <div class="audit-panel active" id="panel-seo">
      <div class="audit-card">
        <div class="audit-card-header">
          <div class="icon">🔍</div>
          <div>
            <h2>Site Audit & SEO Checker</h2>
            <p>Check meta tags, headings, performance signals, mobile-friendliness & more</p>
          </div>
        </div>
        <div class="audit-card-body">
          <div class="audit-input-row">
            <input type="url" id="audit-url" placeholder="https://yourwebsite.com" />
            <button class="audit-run-btn" id="run-audit-btn" onclick="runSiteAudit()">Run Audit →</button>
          </div>
          <p style="margin-top:0.75rem;font-size:0.8rem;color:#94a3b8;">
            ℹ️ We analyse the URL you provide. Results are powered by AI based on your site's public data.
          </p>

          <div class="audit-loading" id="audit-loading">
            <div class="spin"></div>
            <p>Analysing your website… This takes about 15 seconds.</p>
          </div>

          <div class="audit-results" id="audit-results">
            <!-- Score Ring -->
            <div class="score-ring-wrap">
              <div class="score-ring">
                <svg width="130" height="130" viewBox="0 0 130 130">
                  <circle cx="65" cy="65" r="54" fill="none" stroke="#e2e8f0" stroke-width="12"/>
                  <circle id="score-circle" cx="65" cy="65" r="54" fill="none" stroke="hsl(43,78%,47%)" stroke-width="12"
                          stroke-linecap="round" stroke-dasharray="339.3" stroke-dashoffset="339.3"/>
                </svg>
                <div class="score-num"><span id="score-val">—</span><small>/ 100</small></div>
              </div>
              <div class="score-summary">
                <h3 id="score-title">Running audit…</h3>
                <p id="score-desc">Please wait while we check your site.</p>
              </div>
            </div>

            <!-- Check Grid -->
            <div class="check-grid" id="check-grid"></div>

            <!-- Suggestions -->
            <h3 style="font-weight:800;margin-bottom:0.75rem;">💡 Recommendations</h3>
            <ul class="suggestion-list" id="suggestion-list"></ul>

            <!-- Export -->
            <div class="audit-export-row">
              <button class="btn-export gold" onclick="exportAuditPDF()">⬇ Export PDF Report</button>
              <button class="btn-export" onclick="copyAuditText()">📋 Copy Summary</button>
            </div>
          </div>
        </div>
      </div>
    </div><!-- /panel-seo -->


    <!-- ════ TOOL 2: CONTENT ANALYZER ════ -->
    <div class="audit-panel" id="panel-content">
      <div class="audit-card">
        <div class="audit-card-header">
          <div class="icon">📝</div>
          <div>
            <h2>Content Analyzer</h2>
            <p>Paste any text to get readability score, keyword density, SEO suggestions & tone analysis</p>
          </div>
        </div>
        <div class="audit-card-body">
          <div style="margin-bottom:0.75rem;">
            <input type="text" id="content-focus-kw" placeholder="Focus Keyword (optional, e.g. ecommerce marketing)" style="width:100%;padding:0.75rem 1rem;border:1.5px solid #e2e8f0;border-radius:var(--radius);font-size:0.95rem;color:#0f172a;background:#f8fafc;font-family:inherit;outline:none;box-sizing:border-box;" />
          </div>
          <div class="audit-input-row" style="align-items:flex-end;">
            <textarea id="content-text" placeholder="Paste your blog post, page content or any text here (min. 100 words recommended)…"></textarea>
          </div>
          <div style="margin-top:0.75rem;display:flex;gap:0.75rem;align-items:center;flex-wrap:wrap;">
            <button class="audit-run-btn" id="run-content-btn" onclick="runContentAnalyzer()">Analyze Content →</button>
            <span style="font-size:0.8rem;color:#94a3b8;" id="word-counter">0 words</span>
          </div>

          <div class="audit-loading" id="content-loading">
            <div class="spin"></div>
            <p>Analysing your content… This takes about 10 seconds.</p>
          </div>

          <div class="audit-results" id="content-results">
            <!-- Stats boxes -->
            <div class="content-stats-grid" id="content-stats"></div>

            <!-- Keyword Table -->
            <h3 style="font-weight:800;margin-bottom:0.75rem;">🔑 Top Keywords</h3>
            <div style="overflow-x:auto;">
              <table class="keyword-table" id="kw-table">
                <thead>
                  <tr>
                    <th>#</th><th>Keyword</th><th>Count</th><th>Density</th><th>Frequency</th>
                  </tr>
                </thead>
                <tbody id="kw-tbody"></tbody>
              </table>
            </div>

            <!-- Tone -->
            <h3 style="font-weight:800;margin:1.25rem 0 0.75rem;">🎭 Tone & Readability</h3>
            <div id="tone-result" style="padding:1rem;background:#f8fafc;border-radius:0.75rem;font-size:0.9rem;color:#334155;line-height:1.7;"></div>

            <!-- AI Suggestions -->
            <h3 style="font-weight:800;margin:1.25rem 0 0.75rem;">💡 Improvement Suggestions</h3>
            <ul class="suggestion-list" id="content-suggestion-list"></ul>

            <div class="audit-export-row">
              <button class="btn-export gold" onclick="exportContentPDF()">⬇ Export PDF Report</button>
              <button class="btn-export" onclick="copyContentText()">📋 Copy Summary</button>
            </div>
          </div>

        </div>
      </div>
    </div><!-- /panel-content -->

  </div>
</section>

<script>
/* ──────────────────────────────────────────
   TAB SWITCH
────────────────────────────────────────── */
function switchTab(tab) {
  document.querySelectorAll('.audit-panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.audit-tab-btn').forEach(b => b.classList.remove('active'));
  document.getElementById('panel-' + tab).classList.add('active');
  event.currentTarget.classList.add('active');
}

/* ──────────────────────────────────────────
   WORD COUNTER (live)
────────────────────────────────────────── */
document.getElementById('content-text').addEventListener('input', function() {
  const words = this.value.trim().split(/\s+/).filter(w => w.length > 0).length;
  document.getElementById('word-counter').textContent = words + ' words';
});

/* ──────────────────────────────────────────
   TOOL 1 — SITE AUDIT
────────────────────────────────────────── */
async function runSiteAudit() {
  const url = document.getElementById('audit-url').value.trim();
  if (!url) { alert('Please enter a website URL.'); return; }
  let cleanUrl = url;
  if (!/^https?:\/\//i.test(cleanUrl)) cleanUrl = 'https://' + cleanUrl;

  const btn = document.getElementById('run-audit-btn');
  btn.disabled = true; btn.textContent = 'Analysing…';
  document.getElementById('audit-loading').classList.add('show');
  document.getElementById('audit-results').classList.remove('show');

  const prompt = `You are an expert SEO and website auditor. Perform a comprehensive website audit for the URL: ${cleanUrl}

Based on general SEO best practices, common website patterns, and what you know about this domain (if anything), return a JSON object with EXACTLY this structure:

{
  "score": <integer 0-100 overall SEO health score>,
  "scoreTitle": "<one-line title like 'Good - Needs Improvements'>",
  "scoreDesc": "<2-sentence summary of overall health>",
  "checks": [
    {"label": "Title Tag", "status": "pass|warn|fail|info", "value": "<what you found or expected>"},
    {"label": "Meta Description", "status": "pass|warn|fail", "value": "<present/missing/length issue>"},
    {"label": "H1 Heading", "status": "pass|warn|fail", "value": "<present and descriptive / missing>"},
    {"label": "Heading Structure", "status": "pass|warn|fail", "value": "<H1>H2>H3 logical / issues>"},
    {"label": "Page Speed", "status": "pass|warn|fail", "value": "<expected fast/slow based on tech>"},
    {"label": "Mobile Friendly", "status": "pass|warn|fail", "value": "<responsive / not responsive>"},
    {"label": "SSL / HTTPS", "status": "pass|fail", "value": "<secure / not secure>"},
    {"label": "Robots.txt", "status": "pass|warn|info", "value": "<likely present / check needed>"},
    {"label": "Sitemap", "status": "pass|warn|info", "value": "<likely present / needs checking>"},
    {"label": "Image Alt Text", "status": "pass|warn|fail", "value": "<likely present / often missing>"},
    {"label": "Internal Links", "status": "pass|warn|fail", "value": "<good linking / needs improvement>"},
    {"label": "Canonical Tags", "status": "pass|warn|info", "value": "<present / check needed>"},
    {"label": "Structured Data", "status": "pass|warn|fail", "value": "<schema.org detected / not found>"},
    {"label": "Open Graph Tags", "status": "pass|warn|fail", "value": "<social sharing tags status>"}
  ],
  "suggestions": [
    {"level": "critical|warning|good", "title": "<short title>", "detail": "<actionable explanation>"},
    {"level": "critical|warning|good", "title": "<short title>", "detail": "<actionable explanation>"},
    {"level": "critical|warning|good", "title": "<short title>", "detail": "<actionable explanation>"},
    {"level": "warning", "title": "<short title>", "detail": "<actionable explanation>"},
    {"level": "good", "title": "<short title>", "detail": "<what they are doing well>"}
  ]
}

Return ONLY valid JSON. No markdown fences. No extra text.`;

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 1000,
        messages: [{ role: "user", content: prompt }]
      })
    });
    const data = await response.json();
    const text = data.content.map(i => i.text || '').join('');
    const clean = text.replace(/```json|```/g, '').trim();
    const result = JSON.parse(clean);
    renderSiteAudit(result, cleanUrl);
  } catch(e) {
    alert('Could not complete audit. Please try again.');
    console.error(e);
  } finally {
    btn.disabled = false; btn.textContent = 'Run Audit →';
    document.getElementById('audit-loading').classList.remove('show');
  }
}

function renderSiteAudit(data, url) {
  // Score ring animation
  const score = Math.min(100, Math.max(0, data.score || 50));
  const circumference = 339.3;
  const offset = circumference - (score / 100) * circumference;
  const circle = document.getElementById('score-circle');
  circle.style.strokeDashoffset = offset;
  // Color
  const color = score >= 75 ? '#22c55e' : score >= 50 ? 'hsl(43,78%,47%)' : '#ef4444';
  circle.style.stroke = color;

  document.getElementById('score-val').textContent = score;
  document.getElementById('score-title').textContent = data.scoreTitle || 'Audit Complete';
  document.getElementById('score-desc').textContent = data.scoreDesc || '';

  // Checks
  const statusIcon = { pass: '✅', warn: '⚠️', fail: '❌', info: 'ℹ️' };
  const grid = document.getElementById('check-grid');
  grid.innerHTML = (data.checks || []).map(c => `
    <div class="check-item ${c.status}">
      <span class="check-icon">${statusIcon[c.status] || 'ℹ️'}</span>
      <div>
        <span class="check-label">${c.label}</span>
        <span class="check-val">${c.value}</span>
      </div>
    </div>
  `).join('');

  // Suggestions
  const levelIcon = { critical: '🔴', warning: '🟡', good: '🟢' };
  const levelClass = { critical: 'critical', warning: 'warning', good: 'good' };
  const sugList = document.getElementById('suggestion-list');
  sugList.innerHTML = (data.suggestions || []).map(s => `
    <li class="${levelClass[s.level] || ''}">
      <span class="sug-icon">${levelIcon[s.level] || '💡'}</span>
      <span class="sug-text"><strong>${s.title}</strong>${s.detail}</span>
    </li>
  `).join('');

  // Store for export
  window._lastAuditData = data;
  window._lastAuditUrl  = url;

  document.getElementById('audit-results').classList.add('show');
  document.getElementById('audit-results').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

/* ──────────────────────────────────────────
   TOOL 2 — CONTENT ANALYZER
────────────────────────────────────────── */
async function runContentAnalyzer() {
  const text = document.getElementById('content-text').value.trim();
  const focusKw = document.getElementById('content-focus-kw').value.trim();
  if (text.length < 30) { alert('Please paste at least some content to analyse.'); return; }

  const btn = document.getElementById('run-content-btn');
  btn.disabled = true; btn.textContent = 'Analysing…';
  document.getElementById('content-loading').classList.add('show');
  document.getElementById('content-results').classList.remove('show');

  // Local keyword analysis
  const localKw = analyzeKeywordsLocally(text);
  const words = text.trim().split(/\s+/).filter(w => w.length > 0);
  const wordCount = words.length;
  const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 3);
  const sentenceCount = sentences.length;
  const avgWordsPerSentence = sentenceCount > 0 ? Math.round(wordCount / sentenceCount) : 0;
  const paragraphs = text.split(/\n\n+/).filter(p => p.trim().length > 10).length;
  const readingTime = Math.ceil(wordCount / 238);
  const fleschScore = calcFleschScore(words, sentences);

  const prompt = `You are a professional content strategist and SEO expert. Analyse this content${focusKw ? ' for the focus keyword "' + focusKw + '"' : ''}.

CONTENT:
"""
${text.substring(0, 3000)}
"""

STATS: ${wordCount} words, ${sentenceCount} sentences, avg ${avgWordsPerSentence} words/sentence, Flesch score: ${fleschScore}
${focusKw ? 'Focus keyword: "' + focusKw + '"' : ''}

Return ONLY a JSON object (no markdown, no extra text):
{
  "readabilityLabel": "<Easy/Moderate/Difficult>",
  "readabilityNote": "<1 sentence about reading level>",
  "toneDescription": "<2-3 sentences describing tone, voice, and style>",
  "seoReadabilityScore": <integer 0-100>,
  "focusKwFound": <true/false if focus keyword present>,
  "focusKwDensity": "<e.g. 1.2%>",
  "suggestions": [
    {"level": "critical|warning|good", "title": "<short title>", "detail": "<specific actionable tip>"},
    {"level": "critical|warning|good", "title": "<short title>", "detail": "<specific actionable tip>"},
    {"level": "critical|warning|good", "title": "<short title>", "detail": "<specific actionable tip>"},
    {"level": "warning", "title": "<short title>", "detail": "<specific actionable tip>"},
    {"level": "good", "title": "<what they did well>", "detail": "<positive reinforcement>"}
  ]
}`;

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 1000,
        messages: [{ role: "user", content: prompt }]
      })
    });
    const data = await response.json();
    const rawText = data.content.map(i => i.text || '').join('');
    const clean = rawText.replace(/```json|```/g, '').trim();
    const result = JSON.parse(clean);
    renderContentAnalysis(result, { wordCount, sentenceCount, avgWordsPerSentence, paragraphs, readingTime, fleschScore }, localKw, focusKw);
  } catch(e) {
    alert('Could not complete analysis. Please try again.');
    console.error(e);
  } finally {
    btn.disabled = false; btn.textContent = 'Analyze Content →';
    document.getElementById('content-loading').classList.remove('show');
  }
}

function analyzeKeywordsLocally(text) {
  const stopWords = new Set(['the','a','an','and','or','but','in','on','at','to','for','of','with','by','from','is','are','was','were','be','been','being','have','has','had','do','does','did','will','would','could','should','may','might','this','that','these','those','it','its','i','you','he','she','we','they','them','their','our','your','my','his','her','not','no','so','if','as','up','out','all','can','just','more','about','than','into','also']);
  const words = text.toLowerCase().replace(/[^a-z\s]/g, ' ').split(/\s+/).filter(w => w.length > 3 && !stopWords.has(w));
  const freq = {};
  words.forEach(w => freq[w] = (freq[w] || 0) + 1);
  const total = words.length;
  return Object.entries(freq)
    .sort((a,b) => b[1]-a[1])
    .slice(0,10)
    .map(([kw, count]) => ({ kw, count, density: total > 0 ? ((count/total)*100).toFixed(2) : '0.00' }));
}

function calcFleschScore(words, sentences) {
  if (!sentences.length || !words.length) return 60;
  const syllables = words.reduce((acc, w) => acc + countSyllables(w), 0);
  const score = 206.835 - 1.015*(words.length/sentences.length) - 84.6*(syllables/words.length);
  return Math.min(100, Math.max(0, Math.round(score)));
}
function countSyllables(word) {
  word = word.toLowerCase().replace(/[^a-z]/g,'');
  if (word.length <= 3) return 1;
  const m = word.match(/[aeiouy]+/g);
  return m ? m.length : 1;
}

function renderContentAnalysis(ai, stats, keywords, focusKw) {
  // Stats
  const fleschLabel = stats.fleschScore >= 70 ? '🟢 Easy' : stats.fleschScore >= 50 ? '🟡 Moderate' : '🔴 Difficult';
  const statsEl = document.getElementById('content-stats');
  statsEl.innerHTML = [
    { num: stats.wordCount,             lbl: 'Words' },
    { num: stats.sentenceCount,         lbl: 'Sentences' },
    { num: stats.paragraphs,            lbl: 'Paragraphs' },
    { num: stats.readingTime + ' min',  lbl: 'Read Time' },
    { num: stats.fleschScore,           lbl: 'Flesch Score' },
    { num: (ai.seoReadabilityScore||0) + '/100', lbl: 'SEO Score' },
  ].map(s => `<div class="stat-box"><span class="stat-num">${s.num}</span><span class="stat-lbl">${s.lbl}</span></div>`).join('');

  // Keyword table
  const maxCount = keywords[0]?.count || 1;
  const tbody = document.getElementById('kw-tbody');
  tbody.innerHTML = keywords.map((k,i) => `
    <tr>
      <td style="color:#94a3b8;font-weight:700;">${i+1}</td>
      <td><strong>${k.kw}</strong></td>
      <td>${k.count}</td>
      <td>${k.density}%</td>
      <td><div class="kw-bar-wrap"><div class="kw-bar" style="width:${Math.round((k.count/maxCount)*100)}%"></div></div></td>
    </tr>
  `).join('');

  // Tone
  const toneEl = document.getElementById('tone-result');
  toneEl.innerHTML = `
    <strong>Readability:</strong> ${ai.readabilityLabel || fleschLabel} — ${ai.readabilityNote || ''}<br>
    <strong>Tone:</strong> ${ai.toneDescription || ''}
    ${focusKw ? `<br><strong>Focus keyword "${focusKw}":</strong> ${ai.focusKwFound ? '✅ Found' : '❌ Not found'} ${ai.focusKwDensity ? '— density: ' + ai.focusKwDensity : ''}` : ''}
  `;

  // Suggestions
  const levelIcon  = { critical: '🔴', warning: '🟡', good: '🟢' };
  const levelClass = { critical: 'critical', warning: 'warning', good: 'good' };
  const sugList = document.getElementById('content-suggestion-list');
  sugList.innerHTML = (ai.suggestions || []).map(s => `
    <li class="${levelClass[s.level] || ''}">
      <span class="sug-icon">${levelIcon[s.level] || '💡'}</span>
      <span class="sug-text"><strong>${s.title}</strong>${s.detail}</span>
    </li>
  `).join('');

  window._lastContentData  = ai;
  window._lastContentStats = stats;

  document.getElementById('content-results').classList.add('show');
  document.getElementById('content-results').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

/* ──────────────────────────────────────────
   EXPORT / COPY
────────────────────────────────────────── */
function exportAuditPDF() {
  if (!window._lastAuditData) return;
  const d = window._lastAuditData;
  const html = `<html><head><title>Site Audit — Advertza</title>
  <style>body{font-family:sans-serif;padding:2rem;color:#0f172a}h1{color:#b45309}table{width:100%;border-collapse:collapse}td,th{padding:8px;border:1px solid #e2e8f0;font-size:13px}th{background:#f1f5f9}</style></head>
  <body>
  <h1>Site Audit Report — ${window._lastAuditUrl}</h1>
  <p><strong>Score: ${d.score}/100</strong> — ${d.scoreTitle}</p><p>${d.scoreDesc}</p>
  <h2>Checks</h2><table><tr><th>Check</th><th>Status</th><th>Finding</th></tr>
  ${(d.checks||[]).map(c=>`<tr><td>${c.label}</td><td>${c.status.toUpperCase()}</td><td>${c.value}</td></tr>`).join('')}
  </table>
  <h2>Recommendations</h2>
  ${(d.suggestions||[]).map(s=>`<p><strong>[${s.level.toUpperCase()}] ${s.title}:</strong> ${s.detail}</p>`).join('')}
  <hr><p style="font-size:11px;color:#64748b">Generated by Advertza Site Audit Tool</p>
  </body></html>`;
  const w = window.open(''); w.document.write(html); w.document.close(); setTimeout(()=>w.print(), 500);
}

function copyAuditText() {
  if (!window._lastAuditData) return;
  const d = window._lastAuditData;
  const txt = `SITE AUDIT REPORT — ${window._lastAuditUrl}\nScore: ${d.score}/100 — ${d.scoreTitle}\n${d.scoreDesc}\n\nCHECKS:\n`
    + (d.checks||[]).map(c=>`${c.status.toUpperCase()} | ${c.label}: ${c.value}`).join('\n')
    + '\n\nRECOMMENDATIONS:\n'
    + (d.suggestions||[]).map(s=>`[${s.level.toUpperCase()}] ${s.title}: ${s.detail}`).join('\n');
  navigator.clipboard.writeText(txt).then(()=>alert('Copied to clipboard!'));
}

function exportContentPDF() {
  if (!window._lastContentData) return;
  const d = window._lastContentData; const s = window._lastContentStats;
  const html = `<html><head><title>Content Analysis — Advertza</title>
  <style>body{font-family:sans-serif;padding:2rem;color:#0f172a}h1{color:#b45309}</style></head>
  <body>
  <h1>Content Analysis Report</h1>
  <p><strong>Words:</strong> ${s.wordCount} | <strong>Reading Time:</strong> ${s.readingTime} min | <strong>Flesch:</strong> ${s.fleschScore} | <strong>SEO Score:</strong> ${d.seoReadabilityScore}/100</p>
  <p><strong>Readability:</strong> ${d.readabilityLabel} — ${d.readabilityNote}</p>
  <p><strong>Tone:</strong> ${d.toneDescription}</p>
  <h2>Suggestions</h2>
  ${(d.suggestions||[]).map(sg=>`<p><strong>[${sg.level.toUpperCase()}] ${sg.title}:</strong> ${sg.detail}</p>`).join('')}
  <hr><p style="font-size:11px;color:#64748b">Generated by Advertza Content Analyzer</p>
  </body></html>`;
  const w = window.open(''); w.document.write(html); w.document.close(); setTimeout(()=>w.print(), 500);
}

function copyContentText() {
  if (!window._lastContentData) return;
  const d = window._lastContentData; const s = window._lastContentStats;
  const txt = `CONTENT ANALYSIS REPORT\nWords: ${s.wordCount} | Reading Time: ${s.readingTime}min | SEO Score: ${d.seoReadabilityScore}/100\nReadability: ${d.readabilityLabel} — ${d.readabilityNote}\nTone: ${d.toneDescription}\n\nSUGGESTIONS:\n`
    + (d.suggestions||[]).map(sg=>`[${sg.level.toUpperCase()}] ${sg.title}: ${sg.detail}`).join('\n');
  navigator.clipboard.writeText(txt).then(()=>alert('Copied to clipboard!'));
}
</script>

<?php get_footer(); ?>
