<?php
/**
 * Template Name: Privacy Policy
 */
get_header();
?>
<main>
    <section style="padding:3rem 0 5rem;">
        <div class="container">
            <div class="legal-page">
                <h1>Privacy Policy</h1>
                <p><em>Last updated: <?php echo date('F Y'); ?></em></p>

                <h2>1. Introduction</h2>
                <p>Advertza ("we", "our", "us") is committed to protecting your privacy. This Privacy Policy explains how we collect, use, and safeguard your personal information when you visit our website or use our services.</p>

                <h2>2. Information We Collect</h2>
                <p>We collect information you provide directly to us, including:</p>
                <ul>
                    <li>Name, email address, phone number, and website URL when you fill out our contact or consultation form</li>
                    <li>Business information such as monthly ad budget and marketing goals</li>
                    <li>Communications you send us via email or contact forms</li>
                </ul>
                <p>We also automatically collect certain technical data including IP address, browser type, pages visited, and time spent on pages through standard analytics tools.</p>

                <h2>3. How We Use Your Information</h2>
                <p>We use the information we collect to:</p>
                <ul>
                    <li>Respond to your enquiries and provide requested services</li>
                    <li>Send you marketing communications (with your consent)</li>
                    <li>Improve our website and services</li>
                    <li>Comply with legal obligations</li>
                </ul>

                <h2>4. Data Sharing</h2>
                <p>We do not sell, trade, or rent your personal information to third parties. We may share your data with trusted service providers who assist us in operating our website or conducting our business, subject to confidentiality agreements.</p>

                <h2>5. Data Retention</h2>
                <p>We retain your personal data for as long as necessary to fulfil the purposes for which it was collected, including satisfying legal, accounting, or reporting requirements.</p>

                <h2>6. Your Rights</h2>
                <p>Under applicable data protection law, you have the right to access, correct, delete, or object to the processing of your personal data. To exercise these rights, contact us at <a href="mailto:hello@advertza.com" style="color:var(--gold);">hello@advertza.com</a>.</p>

                <h2>7. Cookies</h2>
                <p>Our website uses cookies to enhance your browsing experience and analyse traffic. You can control cookie settings through your browser.</p>

                <h2>8. Contact Us</h2>
                <p>If you have questions about this Privacy Policy, please contact us at <a href="mailto:hello@advertza.com" style="color:var(--gold);">hello@advertza.com</a>.</p>
            </div>
        </div>
    </section>
</main>
<?php get_footer(); ?>
