<?php
/**
 * 404 Not Found Page
 */
get_header();
?>
<main>
    <div class="container">
        <div class="not-found">
            <h1>404</h1>
            <h2>Page Not Found</h2>
            <p>Oops! The page you're looking for doesn't exist or has been moved.</p>
            <a href="<?php echo home_url('/'); ?>" class="btn-primary">← Back to Home</a>
        </div>
    </div>
</main>
<?php get_footer(); ?>
