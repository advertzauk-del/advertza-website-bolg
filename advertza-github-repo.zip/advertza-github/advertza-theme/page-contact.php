<?php
/**
 * Template Name: Contact Page
 */
global $post;
if ( ! is_object($post) ) $post = get_queried_object();
setup_postdata($post);
get_header();
?>
<main>
    <!-- Hero -->
    <section style="padding:3.5rem 0 2.5rem;background:var(--surface-warm);text-align:center;">
        <div class="container">
            <span class="section-label">Contact Us</span>
            <h1 style="font-size:clamp(2rem,5vw,3rem);font-weight:800;margin-bottom:0.75rem;">
                Let's <span class="text-gradient-gold">Grow Together</span>
            </h1>
            <p style="color:var(--muted-foreground);max-width:34rem;margin:0 auto;">
                Get your free, no-obligation audit. We'll respond within 24 hours.
            </p>
        </div>
    </section>

    <section style="padding:3rem 0 5rem;">
        <div class="container">
            <div class="contact-grid">

                <!-- Left: Form -->
                <div>
                    <?php get_template_part( 'template-parts/consultation-form' ); ?>
                </div>

                <!-- Right: Info -->
                <div style="display:flex;flex-direction:column;gap:1.5rem;">

                    <!-- Contact Details -->
                    <div class="contact-info-card">
                        <h3 style="font-size:1.1rem;font-weight:800;margin-bottom:1.5rem;padding-bottom:0.75rem;border-bottom:2px solid var(--gold);">Get In Touch</h3>

                        <div class="contact-info-item" style="margin-bottom:1.25rem;">
                            <span class="ci-icon" style="font-size:1.1rem;">📍</span>
                            <div>
                                <strong style="display:block;font-size:0.8rem;font-weight:700;color:var(--foreground);margin-bottom:0.25rem;">India Office</strong>
                                <span style="font-size:0.875rem;color:var(--muted-foreground);">1-74 Ambe Village Near Chikhodra Chokdi Anand, Gujarat 388001</span>
                            </div>
                        </div>

                        <div class="contact-info-item" style="margin-bottom:1.25rem;">
                            <span class="ci-icon" style="font-size:1.1rem;">📍</span>
                            <div>
                                <strong style="display:block;font-size:0.8rem;font-weight:700;color:var(--foreground);margin-bottom:0.25rem;">UK Office</strong>
                                <span style="font-size:0.875rem;color:var(--muted-foreground);">United Kingdom — Serving UK &amp; European clients</span>
                            </div>
                        </div>

                        <div class="contact-info-item" style="margin-bottom:1.25rem;">
                            <span class="ci-icon" style="font-size:1.1rem;">📞</span>
                            <div>
                                <strong style="display:block;font-size:0.8rem;font-weight:700;color:var(--foreground);margin-bottom:0.25rem;">Phone / WhatsApp</strong>
                                <a href="tel:+919725487887" style="display:block;font-size:0.875rem;color:var(--muted-foreground);margin-bottom:0.25rem;transition:color 0.2s;" onmouseover="this.style.color='var(--gold)'" onmouseout="this.style.color='var(--muted-foreground)'">
                                    🇮🇳 <?php echo esc_html( advertza_opt('phone_india', '+91 97254 87887') ); ?>
                                </a>
                                <a href="tel:+447442193744" style="display:block;font-size:0.875rem;color:var(--muted-foreground);transition:color 0.2s;" onmouseover="this.style.color='var(--gold)'" onmouseout="this.style.color='var(--muted-foreground)'">
                                    🇬🇧 <?php echo esc_html( advertza_opt('phone_uk', '+44 7442 193744') ); ?>
                                </a>
                            </div>
                        </div>

                        <div class="contact-info-item" style="margin-bottom:1.25rem;">
                            <span class="ci-icon" style="font-size:1.1rem;">✉️</span>
                            <div>
                                <strong style="display:block;font-size:0.8rem;font-weight:700;color:var(--foreground);margin-bottom:0.25rem;">Email</strong>
                                <a href="mailto:hello@advertza.net" style="font-size:0.875rem;color:var(--muted-foreground);transition:color 0.2s;" onmouseover="this.style.color='var(--gold)'" onmouseout="this.style.color='var(--muted-foreground)'">
                                    <?php echo esc_html( advertza_opt('email', 'hello@advertza.net') ); ?>
                                </a>
                            </div>
                        </div>

                        <div class="contact-info-item">
                            <span class="ci-icon" style="font-size:1.1rem;">💬</span>
                            <div>
                                <strong style="display:block;font-size:0.8rem;font-weight:700;color:var(--foreground);margin-bottom:0.25rem;">WhatsApp</strong>
                                <a href="https://wa.me/<?php echo esc_attr( advertza_opt('whatsapp', '919725487887') ); ?>?text=Hi! I'd like to get a free marketing audit."
                                   target="_blank" rel="noopener"
                                   style="font-size:0.875rem;color:#25D366;font-weight:600;transition:opacity 0.2s;" onmouseover="this.style.opacity='0.8'" onmouseout="this.style.opacity='1'">
                                    Chat with us on WhatsApp →
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- Office Hours -->
                    <div style="border:1.5px solid var(--border);border-radius:var(--radius);padding:1.5rem;">
                        <h3 style="font-size:1rem;font-weight:800;margin-bottom:1.25rem;">Office Hours</h3>
                        <?php $hours = [['Mon – Fri','9:00 AM – 6:00 PM IST'],['Saturday','10:00 AM – 4:00 PM IST'],['Sunday','Closed']];
                        foreach($hours as $h): ?>
                        <div style="display:flex;justify-content:space-between;padding:0.5rem 0;border-bottom:1px solid var(--border);font-size:0.875rem;">
                            <span style="color:var(--foreground);font-weight:600;"><?php echo $h[0]; ?></span>
                            <span style="color:var(--muted-foreground);"><?php echo $h[1]; ?></span>
                        </div>
                        <?php endforeach; ?>
                    </div>

                    <!-- Audit Includes -->
                    <div class="audit-card">
                        <h3 style="font-size:1rem;font-weight:800;color:#fff;margin-bottom:1.25rem;">✅ Free Audit Includes:</h3>
                        <ul style="display:flex;flex-direction:column;gap:0.625rem;">
                            <?php $items = ['Campaign performance review','Competitor analysis','Growth opportunity report','Custom strategy recommendations','30-minute consultation call'];
                            foreach($items as $item): ?>
                            <li style="font-size:0.875rem;color:rgba(255,255,255,0.75);display:flex;gap:0.5rem;align-items:center;">
                                <span style="color:var(--gold);font-weight:700;">✓</span> <?php echo $item; ?>
                            </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>

                </div>
            </div>
        </div>
    </section>
</main>
<?php get_footer(); ?>
