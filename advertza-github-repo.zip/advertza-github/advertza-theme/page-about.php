<?php
/**
 * Template Name: About Page
 */
global $post;
if ( ! is_object($post) ) $post = get_queried_object();
setup_postdata($post);
get_header();
?>
?>
<main>
    <!-- Hero -->
    <section style="padding:4rem 0 3rem;background:linear-gradient(135deg,#1C2333 0%,#2a3245 100%);">
        <div class="container" style="text-align:center;">
            <span class="section-label">About Us</span>
            <h1 style="font-size:clamp(2rem,5vw,3rem);font-weight:800;color:#fff;margin-bottom:1rem;">
                We're <span class="text-gradient-gold">Advertza</span>
            </h1>
            <p style="color:rgba(255,255,255,0.7);max-width:42rem;margin:0 auto;font-size:1.1rem;line-height:1.8;">
                A performance marketing agency built by marketers who got tired of seeing brands waste money on agencies that prioritize vanity metrics over real business growth. We operate from both the UK and India, combining global strategy with cost-effective execution.
            </p>
        </div>
    </section>

    <!-- Stats -->
    <section style="padding:3rem 0;background:#fff;border-bottom:1px solid var(--border);">
        <div class="container">
            <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:2rem;text-align:center;">
                <?php $stats = [['100+','Campaigns Managed'],['3.8x','Average ROAS'],['10+','Happy Clients']];
                foreach($stats as $s): ?>
                <div>
                    <p style="font-size:2.5rem;font-weight:800;color:var(--gold);"><?php echo $s[0]; ?></p>
                    <p style="font-size:0.85rem;color:var(--muted-foreground);margin-top:0.25rem;"><?php echo $s[1]; ?></p>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- Our Story -->
    <section style="padding:4rem 0;">
        <div class="container">
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:4rem;align-items:center;">
                <div>
                    <span class="section-label">Our Story</span>
                    <h2 class="section-title">Built by Marketers, for Businesses</h2>
                    <p style="color:var(--muted-foreground);line-height:1.8;margin-bottom:1.25rem;">
                        Advertza was founded with a simple mission: help brands grow profitably without wasting money on agencies that care more about their own margin than your results.
                    </p>
                    <p style="color:var(--muted-foreground);line-height:1.8;margin-bottom:1.25rem;">
                        Our team has managed millions in ad spend across Google, Meta, TikTok, and Amazon — and we've seen every mistake in the book. We built Advertza to do things differently.
                    </p>
                    <p style="color:var(--muted-foreground);line-height:1.8;">
                        With offices in Surat, India and presence in the UK, we serve eCommerce brands that want to scale globally without overpaying for execution.
                    </p>
                    <a href="<?php echo home_url('/contact'); ?>" class="btn-primary" style="display:inline-flex;margin-top:1.75rem;">Work With Us →</a>
                </div>
                <div>
                    <div style="background:var(--charcoal);border-radius:1rem;padding:2.5rem;">
                        <?php
                        $points = [
                            ['🎯','Revenue-First','Every decision tied to your bottom line — ROAS, CPA, profit margins.'],
                            ['📊','Data-Driven','Real-time dashboards, weekly calls, full transparency always.'],
                            ['🌍','Global Expertise','UK + India presence gives unique global perspective.'],
                            ['🤝','No Lock-in Contracts','Month-to-month. We earn your business every month.'],
                        ];
                        foreach($points as $p): ?>
                        <div style="display:flex;gap:1rem;margin-bottom:1.5rem;">
                            <span style="font-size:1.5rem;flex-shrink:0;"><?php echo $p[0]; ?></span>
                            <div>
                                <h4 style="color:#fff;font-weight:700;font-size:0.95rem;"><?php echo $p[1]; ?></h4>
                                <p style="color:rgba(255,255,255,0.6);font-size:0.85rem;margin-top:0.25rem;"><?php echo $p[2]; ?></p>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Values -->
    <section style="padding:4rem 0;background:var(--surface-warm);">
        <div class="container">
            <div class="text-center" style="margin-bottom:3rem;">
                <span class="section-label">Our Values</span>
                <h2 class="section-title">What Drives Us</h2>
            </div>
            <div class="values-grid">
                <?php
                $values = [
                    ['🎯','Results-Driven','Every decision backed by data and aimed at growing your bottom line.'],
                    ['🌍','Global Reach','With offices in UK and India, we bring global perspective with local expertise.'],
                    ['🤝','Client-First','We treat your business like our own. Your growth is our growth.'],
                    ['🏆','Certified Experts','Our team holds certifications across Google, Meta, TikTok, and Amazon.'],
                ];
                foreach($values as $v): ?>
                <div class="value-card">
                    <div class="value-icon"><?php echo $v[0]; ?></div>
                    <h3 class="value-title"><?php echo $v[1]; ?></h3>
                    <p class="value-desc"><?php echo $v[2]; ?></p>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- Offices -->
    <section style="padding:4rem 0;">
        <div class="container" style="text-align:center;">
            <span class="section-label">Where We Are</span>
            <h2 class="section-title">Two Countries, One Mission</h2>
            <div class="offices-grid" style="max-width:42rem;">
                <div class="office-card">
                    <div class="office-flag">🇮🇳</div>
                    <h3 class="office-title">India Office</h3>
                    <p class="office-addr">1-74 Ambe Village Near Chikhodra Chokdi Anand, Gujarat 388001</p>
                    <p class="office-phone"><?php echo esc_html( advertza_opt('phone_india', '+91 97254 87887') ); ?></p>
                </div>
                <div class="office-card">
                    <div class="office-flag">🇬🇧</div>
                    <h3 class="office-title">UK Office</h3>
                    <p class="office-addr">United Kingdom</p>
                    <p class="office-phone"><?php echo esc_html( advertza_opt('phone_uk', '+44 7442 193744') ); ?></p>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA -->
    <section class="cta-section">
        <div class="container">
            <div class="cta-inner">
                <h2>Ready to Work Together?</h2>
                <p>Get a free audit and discover your brand's growth potential.</p>
                <div class="cta-btns">
                    <a href="<?php echo home_url('/contact'); ?>" class="btn-primary">Get Your Free Audit →</a>
                </div>
            </div>
        </div>
    </section>
</main>
<?php get_footer(); ?>
