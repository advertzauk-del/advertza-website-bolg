/**
 * ADVERTZA — Google Sheets Integration
 * =====================================
 * SETUP STEPS:
 *
 * 1. Open your Google Sheet:
 *    https://docs.google.com/spreadsheets/d/1LuBv7DYxxBNrVdf2wBNs8YuqNzV-9iuns_oOQr8Lmp8/edit
 *
 * 2. Click Extensions > Apps Script
 *
 * 3. Delete any existing code and paste ALL of this file's content
 *
 * 4. Click Save (floppy disk icon)
 *
 * 5. Click Deploy > New Deployment
 *    - Type: Web App
 *    - Execute as: Me
 *    - Who has access: Anyone
 *    - Click Deploy
 *
 * 6. Copy the Web App URL shown (looks like:
 *    https://script.google.com/macros/s/AKfy.../exec )
 *
 * 7. In WordPress Admin go to:
 *    Settings > Advertza Settings
 *    Paste the URL and click Save Settings
 *
 * 8. Done! Every form submission will now appear in your sheet.
 */

var SHEET_NAME = 'Form Leads'; // Name of the sheet tab (will be created if missing)

function doPost(e) {
  try {
    var ss     = SpreadsheetApp.getActiveSpreadsheet();
    var sheet  = ss.getSheetByName(SHEET_NAME);

    // Create sheet with headers if it doesn't exist
    if (!sheet) {
      sheet = ss.insertSheet(SHEET_NAME);
      sheet.appendRow([
        'Timestamp',
        'Full Name',
        'Email',
        'Phone / WhatsApp',
        'Website',
        'Monthly Budget',
        'Service Interested',
        'Marketing Goals'
      ]);

      // Style header row
      var headerRange = sheet.getRange(1, 1, 1, 8);
      headerRange.setBackground('#C9A84C');
      headerRange.setFontColor('#ffffff');
      headerRange.setFontWeight('bold');
      sheet.setFrozenRows(1);

      // Set column widths
      sheet.setColumnWidth(1, 150); // Timestamp
      sheet.setColumnWidth(2, 160); // Name
      sheet.setColumnWidth(3, 200); // Email
      sheet.setColumnWidth(4, 150); // Phone
      sheet.setColumnWidth(5, 200); // Website
      sheet.setColumnWidth(6, 180); // Budget
      sheet.setColumnWidth(7, 180); // Service
      sheet.setColumnWidth(8, 280); // Message
    }

    // Parse incoming JSON from WordPress
    var data = JSON.parse(e.postData.contents);

    // Append the new row
    sheet.appendRow([
      data.timestamp      || new Date().toLocaleString('en-IN', {timeZone: 'Asia/Kolkata'}),
      data.name           || '',
      data.email          || '',
      data.phone          || '',
      data.website        || '',
      data.budget         || '',
      data.services       || '',
      data.message        || ''
    ]);

    // Auto-resize rows for readability
    sheet.autoResizeRows(sheet.getLastRow(), 1);

    return ContentService
      .createTextOutput(JSON.stringify({ status: 'success' }))
      .setMimeType(ContentService.MimeType.JSON);

  } catch (err) {
    return ContentService
      .createTextOutput(JSON.stringify({ status: 'error', message: err.toString() }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

// Test function — run this manually in Apps Script to verify sheet works
function testSheet() {
  var ss    = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName(SHEET_NAME);
  if (!sheet) {
    Logger.log('Sheet not found — it will be created on first form submission.');
  } else {
    Logger.log('Sheet found! Last row: ' + sheet.getLastRow());
  }
}
