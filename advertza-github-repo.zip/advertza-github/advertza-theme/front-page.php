<?php
/**
 * Template Name: Home Page
 * The front page of the Advertza site.
 */
get_header();
?>

<!-- ============================
     HERO SECTION
     ============================ -->
<section class="hero-section">
    <div class="hero-bg-pattern"></div>
    <div class="container">
        <div class="hero-grid">
            <!-- Left: Copy -->
            <div class="hero-copy">
                <div class="hero-badge">
                    <span class="hero-badge-dot"></span>
                    Digital Marketing Agency &bull; UK &amp; India
                </div>
                <h1 class="hero-title">
                    <?php echo esc_html( advertza_opt('hero_headline', 'Scale Your Revenue') ); ?><br>
                    <span class="text-gradient-gold"><?php echo esc_html( advertza_opt('hero_subline', 'Not Just Your Ad Spend') ); ?></span>
                </h1>
                <p class="hero-desc">
                    <?php echo esc_html( advertza_opt('hero_desc', 'We help eCommerce and D2C brands generate profitable growth through data-driven advertising across Google, Meta, TikTok, Amazon & more.') ); ?>
                </p>
                <div class="hero-btns">
                    <a href="<?php echo home_url('/contact'); ?>" class="btn-primary">
                        Get Your Free Audit →
                    </a>
                    <a href="<?php echo home_url('/services'); ?>" class="btn-outline">
                        Our Services
                    </a>
                </div>

                <!-- Stats -->
                <div class="hero-stats">
                    <div>
                        <p class="stat-value">100+</p>
                        <p class="stat-label">Campaigns Managed</p>
                    </div>
                    <!--<div>-->
                    <!--    <p class="stat-value">£12M+</p>-->
                    <!--    <p class="stat-label">Ad Spend Managed</p>-->
                    <!--</div>-->
                    <div>
                        <p class="stat-value">3.8x</p>
                        <p class="stat-label">Average ROAS</p>
                    </div>
                    <div>
                        <p class="stat-value">10+</p>
                        <p class="stat-label">Happy Clients</p>
                    </div>
                </div>
            </div>

            <!-- Right: Consultation Form -->
            <div>
                <?php get_template_part( 'template-parts/consultation-form' ); ?>
            </div>
        </div>
    </div>
</section>

<!-- ============================
     PROBLEM / SOLUTION SECTION
     ============================ -->
<section class="problem-section">
    <div class="container">
        <div class="problem-grid">
            <div>
                <span class="section-label">The Problem</span>
                <h2 class="section-title">Most Agencies Focus on the Wrong Metrics</h2>
                <div class="problem-items">
                    <?php
                    $problems = array(
                        array( 'title' => 'Vanity Metrics Over Revenue', 'desc' => 'Agencies brag about impressions and clicks, but your bank account tells a different story.' ),
                        array( 'title' => 'No Real Strategy', 'desc' => 'Cookie-cutter campaigns that ignore your unique brand, audience, and growth goals.' ),
                        array( 'title' => 'Poor Communication', 'desc' => 'You\'re left in the dark with monthly PDF reports that mean nothing.' ),
                        array( 'title' => 'Wasted Ad Spend', 'desc' => 'Budget burned on campaigns that don\'t target the right people at the right time.' ),
                    );
                    foreach ( $problems as $p ) : ?>
                    <div class="problem-item">
                        <div class="problem-icon">✕</div>
                        <div>
                            <h4><?php echo esc_html( $p['title'] ); ?></h4>
                            <p><?php echo esc_html( $p['desc'] ); ?></p>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <div>
                <div class="solution-card">
                    <h3>The Advertza Difference</h3>
                    <?php
                    $solutions = array(
                        array( 'title' => 'Revenue-First Approach', 'desc' => 'Every decision is tied to your bottom line — ROAS, CPA, and profit margins.' ),
                        array( 'title' => 'Custom Growth Strategy', 'desc' => 'Tailored campaigns built around your brand, customers, and competitive landscape.' ),
                        array( 'title' => 'Transparent Reporting', 'desc' => 'Real-time dashboards and weekly calls so you always know what\'s happening.' ),
                        array( 'title' => 'Full-Funnel Coverage', 'desc' => 'From awareness to retention — we manage every channel your brand needs.' ),
                    );
                    foreach ( $solutions as $s ) : ?>
                    <div class="solution-item">
                        <span class="solution-check">✓</span>
                        <div>
                            <h4><?php echo esc_html( $s['title'] ); ?></h4>
                            <p><?php echo esc_html( $s['desc'] ); ?></p>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ============================
     SERVICES GRID
     ============================ -->
<section class="services-section">
    <div class="container">
        <div class="text-center">
            <span class="section-label">What We Do</span>
            <h2 class="section-title">Full-Funnel Digital Marketing</h2>
            <p class="section-desc">From awareness to conversion, we manage every channel your brand needs to grow profitably.</p>
        </div>
        <div class="services-grid">
            <?php
            $services = array(
                array( 'icon' => '🔍', 'title' => 'Google Ads', 'desc' => 'Search, Shopping, PMax, YouTube & Display campaigns that drive profitable conversions.', 'href' => '/services/google-ads' ),
                array( 'icon' => '👥', 'title' => 'Meta Ads', 'desc' => 'Facebook & Instagram advertising with advanced targeting and creative strategy.', 'href' => '/services/meta-ads' ),
                array( 'icon' => '🎬', 'title' => 'TikTok Ads', 'desc' => 'Engage new audiences with scroll-stopping creative on the fastest-growing platform.', 'href' => '/services/tiktok-ads' ),
                array( 'icon' => '🛍️', 'title' => 'Amazon Ads', 'desc' => 'Sponsored Products, Brands & DSP campaigns to dominate marketplace results.', 'href' => '/services/amazon-ads' ),
                array( 'icon' => '📊', 'title' => 'Analytics & CRO', 'desc' => 'Data-driven optimization to increase conversion rates and maximize your ROI.', 'href' => '/services/analytics' ),
                array( 'icon' => '✉️', 'title' => 'Email & SMS', 'desc' => 'Retention marketing that turns one-time buyers into loyal, repeat customers.', 'href' => '/services/email-marketing' ),
            );
            foreach ( $services as $s ) : ?>
            <a href="<?php echo home_url( $s['href'] ); ?>" class="service-card">
                <div class="service-icon"><?php echo $s['icon']; ?></div>
                <h3 class="service-title"><?php echo esc_html( $s['title'] ); ?></h3>
                <p class="service-desc"><?php echo esc_html( $s['desc'] ); ?></p>
                <span class="service-link">Learn More →</span>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ============================
     PROCESS SECTION
     ============================ -->
<section class="process-section">
    <div class="container">
        <div class="text-center">
            <span class="section-label">How We Work</span>
            <h2 class="section-title">Our Proven Process</h2>
            <p class="section-desc">A structured approach that delivers consistent results.</p>
        </div>
        <div class="process-grid">
            <?php
            $steps = array(
                array( 'num' => '1', 'title' => 'Audit & Discovery', 'desc' => 'Deep dive into your current performance, competitors, and growth opportunities.' ),
                array( 'num' => '2', 'title' => 'Strategy & Setup', 'desc' => 'Custom growth roadmap with channel mix, budget allocation, and creative brief.' ),
                array( 'num' => '3', 'title' => 'Launch & Optimise', 'desc' => 'Launch campaigns and optimize daily based on real-time performance data.' ),
                array( 'num' => '4', 'title' => 'Scale & Report', 'desc' => 'Scale what works, report transparently, and continuously improve results.' ),
            );
            foreach ( $steps as $step ) : ?>
            <div class="process-step">
                <div class="process-num"><?php echo esc_html( $step['num'] ); ?></div>
                <h3><?php echo esc_html( $step['title'] ); ?></h3>
                <p><?php echo esc_html( $step['desc'] ); ?></p>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ============================
     TESTIMONIALS
     ============================ -->
<section class="testimonials-section">
    <div class="container">
        <div class="text-center">
            <span class="section-label">Testimonials</span>
            <h2 class="section-title">Trusted by Growing Brands</h2>
            <p class="section-desc">We've helped businesses across industries scale profitably. Here's what our partners say.</p>
        </div>
        <div class="testimonials-grid">
            <?php
            $testimonials = array(
                array( 'name' => 'Brainwave61', 'role' => 'Tech & Digital Solutions', 'quote' => 'Advertza transformed our digital presence completely. Their data-driven approach to Google and Meta ads helped us achieve a 4.2x ROAS within just 3 months. The team is incredibly responsive and strategic.' ),
                array( 'name' => 'The Yellow Lens Accessories', 'role' => 'Fashion Accessories Brand', 'quote' => 'Working with Advertza has been a game-changer for our brand. They scaled our Meta and TikTok campaigns beautifully, bringing in high-quality traffic that actually converts. Our revenue has grown 280% year-over-year.' ),
                array( 'name' => 'TYL Visuals', 'role' => 'Creative & Visual Studio', 'quote' => 'The Advertza team truly understands performance marketing. They don\'t just run ads — they build growth engines. Our lead generation costs dropped by 60% while volume tripled. Highly recommended!' ),
            );
            // If testimonials CPT has posts, use those. Otherwise use defaults.
            $tposts = get_posts( array( 'post_type' => 'testimonial', 'posts_per_page' => 3 ) );
            if ( ! empty( $tposts ) ) {
                foreach ( $tposts as $t ) :
                    $role = get_post_meta( $t->ID, 'role', true );
            ?>
            <div class="testimonial-card">
                <div class="quote-icon">"</div>
                <div class="stars"><span>★</span><span>★</span><span>★</span><span>★</span><span>★</span></div>
                <p class="testimonial-text">"<?php echo esc_html( $t->post_content ); ?>"</p>
                <div class="testimonial-author">
                    <p class="testimonial-name"><?php echo esc_html( $t->post_title ); ?></p>
                    <p class="testimonial-role"><?php echo esc_html( $role ); ?></p>
                </div>
            </div>
            <?php
                endforeach;
            } else {
                foreach ( $testimonials as $t ) : ?>
            <div class="testimonial-card">
                <div class="quote-icon">"</div>
                <div class="stars"><span>★</span><span>★</span><span>★</span><span>★</span><span>★</span></div>
                <p class="testimonial-text">"<?php echo esc_html( $t['quote'] ); ?>"</p>
                <div class="testimonial-author">
                    <p class="testimonial-name"><?php echo esc_html( $t['name'] ); ?></p>
                    <p class="testimonial-role"><?php echo esc_html( $t['role'] ); ?></p>
                </div>
            </div>
            <?php endforeach; } ?>
        </div>
    </div>
</section>

<!-- ============================
     FAQ SECTION
     ============================ -->
<section class="faq-section">
    <div class="container">
        <div class="text-center">
            <span class="section-label">FAQ</span>
            <h2 class="section-title">Frequently Asked Questions</h2>
        </div>
        <div class="faq-list">
            <?php
            $faqs = array(
                array( 'q' => 'What industries do you specialize in?', 'a' => 'We work primarily with eCommerce, D2C brands, SaaS companies, and lead generation businesses across both UK and Indian markets.' ),
                array( 'q' => 'How much do your services cost?', 'a' => 'Our pricing is tailored to each client\'s needs and budget. We offer flexible packages starting from custom monthly retainers. Contact us for a free proposal.' ),
                array( 'q' => 'How quickly can I see results?', 'a' => 'Most clients see meaningful improvements within the first 30 days. Significant ROI improvements typically occur within 60-90 days of optimization.' ),
                array( 'q' => 'Do you require long-term contracts?', 'a' => 'No. We work on month-to-month agreements. We believe in earning your business every month through results, not contracts.' ),
                array( 'q' => 'Which platforms do you advertise on?', 'a' => 'We manage campaigns across Google, Meta (Facebook/Instagram), TikTok, Amazon, Walmart, eBay, and other major platforms.' ),
                array( 'q' => 'How do you measure success?', 'a' => 'We focus on business-critical metrics: ROAS, CPA, revenue growth, and profit margins — not vanity metrics like impressions or clicks.' ),
                array( 'q' => 'Do you offer creative services?', 'a' => 'Yes! Our in-house creative team produces ad creatives, landing pages, and video content optimized for performance across all platforms.' ),
                array( 'q' => 'What makes Advertza different?', 'a' => 'We combine data-driven strategy with creative excellence, and we operate across UK and India giving us unique global perspective and cost-effective solutions.' ),
            );
            foreach ( $faqs as $i => $faq ) : ?>
            <div class="faq-item<?php echo $i === 0 ? ' open' : ''; ?>">
                <button class="faq-question" aria-expanded="<?php echo $i === 0 ? 'true' : 'false'; ?>">
                    <span><?php echo esc_html( $faq['q'] ); ?></span>
                    <span class="faq-arrow">▼</span>
                </button>
                <p class="faq-answer"><?php echo esc_html( $faq['a'] ); ?></p>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ============================
     BLOG PREVIEW
     ============================ -->
<?php
$recent_posts = get_posts( array( 'numberposts' => 3, 'post_status' => 'publish' ) );
if ( ! empty( $recent_posts ) ) : ?>
<section class="blog-section">
    <div class="container">
        <div class="text-center">
            <span class="section-label">Blog</span>
            <h2 class="section-title">Latest Insights</h2>
            <p class="section-desc">Expert tips and strategies to grow your eCommerce brand.</p>
        </div>
        <div class="blog-grid">
            <?php foreach ( $recent_posts as $post ) :
                setup_postdata( $post );
                $cats      = get_the_category( $post->ID );
                $cat_name  = ! empty( $cats ) ? $cats[0]->name : 'Marketing';
                $read_time = ceil( str_word_count( strip_tags( $post->post_content ) ) / 200 );
                $date_fmt  = get_the_date( 'M j, Y', $post->ID );
                $thumb_url = get_the_post_thumbnail_url( $post->ID, 'advertza-blog-thumb' );
                $full_html = apply_filters( 'the_content', $post->post_content );
                $full_html_enc = esc_attr( wp_json_encode( $full_html ) );
                $title_enc = esc_attr( $post->post_title );
                $cat_enc   = esc_attr( $cat_name );
                $date_enc  = esc_attr( $date_fmt );
                $time_enc  = esc_attr( $read_time );
                $img_enc   = esc_attr( $thumb_url );
            ?>
            <div class="blog-card"
                 style="cursor:pointer;"
                 onclick="advertzaOpenBlog(this)"
                 data-title="<?php echo $title_enc; ?>"
                 data-cat="<?php echo $cat_enc; ?>"
                 data-date="<?php echo $date_enc; ?>"
                 data-time="<?php echo $time_enc; ?>"
                 data-img="<?php echo $img_enc; ?>"
                 data-content="<?php echo $full_html_enc; ?>">
                <?php if ( $thumb_url ) : ?>
                <div class="blog-card-img" style="background:none;">
                    <img src="<?php echo esc_url( $thumb_url ); ?>" alt="<?php echo esc_attr( $post->post_title ); ?>" style="width:100%;height:200px;object-fit:cover;">
                </div>
                <?php else : ?>
                <div class="blog-card-img">
                    <div class="blog-card-img-placeholder">
                        <svg viewBox="0 0 24 24" fill="none" stroke="rgba(201,168,76,0.5)" stroke-width="1.5"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9"/></svg>
                        <span>Advertza</span>
                    </div>
                </div>
                <?php endif; ?>
                <div class="blog-card-body">
                    <div style="display:flex;align-items:center;gap:0.6rem;margin-bottom:0.5rem;flex-wrap:wrap;">
                        <p class="blog-category" style="margin-bottom:0;"><?php echo esc_html( $cat_name ); ?></p>
                        <span style="font-size:0.7rem;color:var(--muted-foreground);">· <?php echo esc_html( $date_fmt ); ?> · <?php echo esc_html( $read_time ); ?> min read</span>
                    </div>
                    <h3 class="blog-card-title"><?php echo esc_html( $post->post_title ); ?></h3>
                    <p class="blog-card-excerpt"><?php echo esc_html( wp_trim_words( $post->post_excerpt ?: $post->post_content, 18 ) ); ?></p>
                    <span class="blog-read-more">Read More →</span>
                </div>
            </div>
            <?php endforeach; wp_reset_postdata(); ?>
        </div>
    </div>
</section>

<!-- ============================
     BLOG MODAL OVERLAY
     ============================ -->
<div id="advertza-blog-modal" style="
    display:none;
    position:fixed;
    top:0;left:0;right:0;bottom:0;
    z-index:99999;
    background:rgba(0,0,0,0.7);
    padding:1rem;
    overflow-y:auto;
    -webkit-overflow-scrolling:touch;
" onclick="if(event.target===this)advertzaCloseBlog()">
    <div id="advertza-blog-inner" style="
        background:var(--background,#fff);
        border-radius:var(--radius,12px);
        max-width:52rem;
        margin:2rem auto;
        padding:2.5rem 2rem;
        position:relative;
        box-shadow:0 24px 80px -12px rgba(0,0,0,0.35);
    ">
        <!-- Close button -->
        <button onclick="advertzaCloseBlog()" aria-label="Close" style="
            position:absolute;
            top:1.25rem;
            right:1.25rem;
            background:var(--surface-warm,#f5f5f0);
            border:1.5px solid var(--border,#e5e5e5);
            border-radius:50%;
            width:2.25rem;height:2.25rem;
            font-size:1rem;
            cursor:pointer;
            display:flex;align-items:center;justify-content:center;
            color:var(--foreground,#111);
            z-index:10;
            flex-shrink:0;
        ">✕</button>

        <!-- Category + date + time -->
        <div style="margin-bottom:0.6rem;display:flex;align-items:center;gap:0.75rem;flex-wrap:wrap;">
            <span id="bm-cat" class="blog-category" style="margin-bottom:0;display:inline-block;"></span>
            <span id="bm-meta" style="font-size:0.8rem;color:var(--muted-foreground,#888);"></span>
        </div>

        <!-- Title -->
        <h2 id="bm-title" style="font-size:clamp(1.4rem,4vw,2.2rem);font-weight:800;line-height:1.25;margin-bottom:1.5rem;color:var(--foreground,#111);"></h2>

        <!-- Featured image -->
        <div id="bm-img-wrap" style="margin-bottom:1.75rem;border-radius:var(--radius,12px);overflow:hidden;display:none;">
            <img id="bm-img" src="" alt="" style="width:100%;height:auto;display:block;">
        </div>

        <!-- Full content -->
        <div id="bm-content" class="post-content" style="font-size:1rem;line-height:1.85;color:var(--muted-foreground,#555);"></div>

        <!-- Bottom close -->
        <div style="margin-top:2.5rem;text-align:center;">
            <button onclick="advertzaCloseBlog()" style="
                background:var(--gold,#C9A84C);
                color:#fff;
                border:none;
                padding:0.65rem 2rem;
                border-radius:6px;
                font-weight:700;
                font-size:0.9rem;
                cursor:pointer;
            ">Close Article</button>
        </div>
    </div>
</div>

<script>
function advertzaOpenBlog(card) {
    var data    = card.dataset;
    var modal   = document.getElementById('advertza-blog-modal');
    var content = JSON.parse(data.content);

    document.getElementById('bm-title').textContent   = data.title;
    document.getElementById('bm-cat').textContent     = data.cat;
    document.getElementById('bm-meta').textContent    = data.date + ' · ' + data.time + ' min read';
    document.getElementById('bm-content').innerHTML   = content;

    var imgWrap = document.getElementById('bm-img-wrap');
    var img     = document.getElementById('bm-img');
    if (data.img && data.img !== 'false') {
        img.src = data.img;
        img.alt = data.title;
        imgWrap.style.display = 'block';
    } else {
        imgWrap.style.display = 'none';
    }

    modal.style.display = 'block';
    document.body.style.overflow = 'hidden';

    // Scroll modal inner to top
    document.getElementById('advertza-blog-inner').scrollTop = 0;
    modal.scrollTop = 0;
}

function advertzaCloseBlog() {
    document.getElementById('advertza-blog-modal').style.display = 'none';
    document.body.style.overflow = '';
}

// ESC key close
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') advertzaCloseBlog();
});
</script>

<?php endif; ?>

<!-- ============================
     CTA SECTION
     ============================ -->
<section class="cta-section">
    <div class="container">
        <div class="cta-inner">
            <h2>Ready to Scale Your Brand?</h2>
            <p>Get your free marketing audit today. No commitments, just real insights on how to grow your business.</p>
            <div class="cta-btns">
                <a href="<?php echo home_url('/contact'); ?>" class="btn-primary">Get Your Free Audit →</a>
                <a href="tel:<?php echo preg_replace('/[^0-9+]/', '', advertza_opt('phone_india', '+919725487887')); ?>" class="btn-outline-light">
                    Call Us Now
                </a>
            </div>
        </div>
    </div>
</section>

<?php get_footer(); ?>
