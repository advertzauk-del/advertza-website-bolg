<?php
/**
 * Template Name: Web Development
 * Standalone page for Web Development service with pricing plans
 */
global $post;
if (!is_object($post)) $post = get_queried_object();
setup_postdata($post);
get_header();
?>
<main>

<!-- ── HERO ─────────────────────────────────────────────────────────────────── -->
<section style="padding:4rem 0 3rem;background:var(--charcoal);">
  <div class="container">
    <div style="max-width:44rem;">
      <a href="<?php echo home_url('/services'); ?>"
         style="font-size:0.8rem;color:rgba(255,255,255,0.5);display:inline-flex;align-items:center;gap:0.4rem;margin-bottom:1.5rem;transition:color 0.2s;"
         onmouseover="this.style.color='var(--gold)'"
         onmouseout="this.style.color='rgba(255,255,255,0.5)'">
        ← Back to All Services
      </a>
      <div style="font-size:3.5rem;margin-bottom:1rem;">💻</div>
      <h1 style="font-size:clamp(2rem,5vw,3rem);font-weight:800;color:#fff;margin-bottom:1rem;">
        Web Development
      </h1>
      <p style="color:rgba(255,255,255,0.7);font-size:1.1rem;line-height:1.7;margin-bottom:2rem;">
        High-performance, conversion-optimised websites and eCommerce stores built to rank, load fast, and turn visitors into customers.
      </p>
      <a href="<?php echo home_url('/contact'); ?>" class="btn-primary">Get a Free Quote →</a>
    </div>
  </div>
</section>

<!-- ── WHAT'S INCLUDED ──────────────────────────────────────────────────────── -->
<section style="padding:4rem 0;background:var(--surface-warm);">
  <div class="container">
    <div class="text-center" style="margin-bottom:2.5rem;">
      <span class="section-label">What's Included</span>
      <h2 class="section-title">Everything You Get</h2>
    </div>
    <div class="features-grid">
      <?php
      $features = [
        ['⚡','Fast & Lightweight','Pages optimised for Core Web Vitals — fast load times on every device.'],
        ['📱','Mobile-First Design','Pixel-perfect on all screen sizes — desktop, tablet, and mobile.'],
        ['🔍','SEO-Ready Structure','Clean code, proper schema, sitemaps and meta tags built in from day one.'],
        ['🛒','eCommerce Ready','WooCommerce, Shopify, or custom cart — we build stores that sell.'],
        ['🔒','Secure & Reliable','SSL, regular backups, security hardening, and uptime monitoring.'],
        ['🎨','Custom Design','Bespoke designs tailored to your brand — no cookie-cutter templates.'],
      ];
      foreach($features as $f): ?>
      <div class="feature-card">
        <div class="feature-icon"><?php echo $f[0]; ?></div>
        <h3 class="feature-title"><?php echo esc_html($f[1]); ?></h3>
        <p class="feature-desc"><?php echo esc_html($f[2]); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ── PRICING PLANS ────────────────────────────────────────────────────────── -->
<section style="padding:5rem 0;">
  <div class="container">
    <div class="text-center" style="margin-bottom:3rem;">
      <span class="section-label">Pricing</span>
      <h2 class="section-title">Choose Your Plan</h2>
      <p class="section-desc">Transparent pricing with no hidden fees. All plans include free consultation.</p>
    </div>

    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:2rem;max-width:62rem;margin:0 auto;">

      <!-- STARTER -->
      <div style="border:2px solid var(--border);border-radius:1.25rem;padding:2.5rem;background:#fff;display:flex;flex-direction:column;transition:box-shadow 0.2s;"
           onmouseover="this.style.boxShadow='0 12px 40px rgba(0,0,0,0.1)'"
           onmouseout="this.style.boxShadow='none'">
        <div style="margin-bottom:1.5rem;">
          <p style="font-size:0.75rem;font-weight:700;text-transform:uppercase;letter-spacing:0.1em;color:var(--muted-foreground);margin-bottom:0.5rem;">Starter</p>
          <p style="font-size:2.5rem;font-weight:800;color:var(--foreground);line-height:1;">£499
            <span style="font-size:1rem;font-weight:500;color:var(--muted-foreground);">/one-time</span>
          </p>
          <p style="font-size:0.85rem;color:var(--muted-foreground);margin-top:0.5rem;">Perfect for small businesses & startups</p>
        </div>
        <hr style="border:none;border-top:1px solid var(--border);margin-bottom:1.5rem;">
        <ul style="display:flex;flex-direction:column;gap:0.75rem;flex:1;">
          <?php $starter = [
            'Up to 5 pages','Mobile responsive design','Contact form integration',
            'Basic SEO setup','Google Analytics setup','SSL certificate',
            '3 rounds of revisions','30 days post-launch support',
          ];
          foreach($starter as $item): ?>
          <li style="display:flex;gap:0.625rem;align-items:flex-start;font-size:0.875rem;color:var(--muted-foreground);">
            <span style="color:var(--gold);font-weight:700;flex-shrink:0;margin-top:1px;">✓</span>
            <?php echo esc_html($item); ?>
          </li>
          <?php endforeach; ?>
        </ul>
        <a href="<?php echo home_url('/contact'); ?>"
           style="display:block;text-align:center;margin-top:2rem;padding:0.875rem;border:2px solid var(--gold);border-radius:var(--radius);font-weight:700;font-size:0.95rem;color:var(--gold);transition:all 0.2s;"
           onmouseover="this.style.background='var(--gold)';this.style.color='#fff'"
           onmouseout="this.style.background='transparent';this.style.color='var(--gold)'">
          Get Started →
        </a>
      </div>

      <!-- PREMIUM — HIGHLIGHTED -->
      <div style="border:2px solid var(--gold);border-radius:1.25rem;padding:2.5rem;background:var(--charcoal);display:flex;flex-direction:column;position:relative;transform:scale(1.03);box-shadow:0 20px 60px -10px rgba(196,154,26,0.35);">
        <div style="position:absolute;top:-14px;left:50%;transform:translateX(-50%);background:linear-gradient(135deg,hsl(43,78%,47%),hsl(43,78%,57%));color:#fff;padding:0.35rem 1.25rem;border-radius:9999px;font-size:0.75rem;font-weight:700;white-space:nowrap;">
          ⭐ Most Popular
        </div>
        <div style="margin-bottom:1.5rem;">
          <p style="font-size:0.75rem;font-weight:700;text-transform:uppercase;letter-spacing:0.1em;color:var(--gold);margin-bottom:0.5rem;">Premium</p>
          <p style="font-size:2.5rem;font-weight:800;color:#fff;line-height:1;">£999
            <span style="font-size:1rem;font-weight:500;color:rgba(255,255,255,0.6);">/one-time</span>
          </p>
          <p style="font-size:0.85rem;color:rgba(255,255,255,0.6);margin-top:0.5rem;">For growing brands that want to stand out</p>
        </div>
        <hr style="border:none;border-top:1px solid rgba(255,255,255,0.15);margin-bottom:1.5rem;">
        <ul style="display:flex;flex-direction:column;gap:0.75rem;flex:1;">
          <?php $premium = [
            'Up to 15 pages','Custom UI/UX design','eCommerce / WooCommerce ready',
            'Advanced SEO (schema, speed opt.)','Blog / CMS integration',
            'WhatsApp & live chat integration','Email marketing integration',
            'Google & Meta Pixel setup','5 rounds of revisions','60 days post-launch support',
          ];
          foreach($premium as $item): ?>
          <li style="display:flex;gap:0.625rem;align-items:flex-start;font-size:0.875rem;color:rgba(255,255,255,0.75);">
            <span style="color:var(--gold);font-weight:700;flex-shrink:0;margin-top:1px;">✓</span>
            <?php echo esc_html($item); ?>
          </li>
          <?php endforeach; ?>
        </ul>
        <a href="<?php echo home_url('/contact'); ?>"
           class="btn-primary"
           style="display:block;text-align:center;margin-top:2rem;padding:0.875rem;">
          Get Started →
        </a>
      </div>

      <!-- AS YOU WANT (CUSTOM) -->
      <div style="border:2px solid var(--border);border-radius:1.25rem;padding:2.5rem;background:#fff;display:flex;flex-direction:column;transition:box-shadow 0.2s;"
           onmouseover="this.style.boxShadow='0 12px 40px rgba(0,0,0,0.1)'"
           onmouseout="this.style.boxShadow='none'">
        <div style="margin-bottom:1.5rem;">
          <p style="font-size:0.75rem;font-weight:700;text-transform:uppercase;letter-spacing:0.1em;color:var(--muted-foreground);margin-bottom:0.5rem;">As You Want</p>
          <p style="font-size:2.5rem;font-weight:800;color:var(--foreground);line-height:1;">Custom
          </p>
          <p style="font-size:0.85rem;color:var(--muted-foreground);margin-top:0.5rem;">Enterprise & fully custom projects</p>
        </div>
        <hr style="border:none;border-top:1px solid var(--border);margin-bottom:1.5rem;">
        <ul style="display:flex;flex-direction:column;gap:0.75rem;flex:1;">
          <?php $custom = [
            'Unlimited pages','Fully bespoke design & development',
            'Custom functionality & integrations','API & third-party integrations',
            'Multi-language / multi-currency','Advanced security & performance',
            'Dedicated project manager','Ongoing maintenance retainer available',
            'Unlimited revisions during build','90 days post-launch support',
          ];
          foreach($custom as $item): ?>
          <li style="display:flex;gap:0.625rem;align-items:flex-start;font-size:0.875rem;color:var(--muted-foreground);">
            <span style="color:var(--gold);font-weight:700;flex-shrink:0;margin-top:1px;">✓</span>
            <?php echo esc_html($item); ?>
          </li>
          <?php endforeach; ?>
        </ul>
        <a href="<?php echo home_url('/contact'); ?>"
           style="display:block;text-align:center;margin-top:2rem;padding:0.875rem;border:2px solid var(--gold);border-radius:var(--radius);font-weight:700;font-size:0.95rem;color:var(--gold);transition:all 0.2s;"
           onmouseover="this.style.background='var(--gold)';this.style.color='#fff'"
           onmouseout="this.style.background='transparent';this.style.color='var(--gold)'">
          Request a Quote →
        </a>
      </div>

    </div><!-- /pricing grid -->

    <!-- All plans note -->
    <p style="text-align:center;margin-top:2.5rem;font-size:0.85rem;color:var(--muted-foreground);">
      💬 All prices are starting from. Final quote depends on project requirements.<br>
      <a href="<?php echo home_url('/contact'); ?>" style="color:var(--gold);font-weight:600;">Contact us</a> for a free consultation and detailed proposal.
    </p>
  </div>
</section>

<!-- ── PROCESS ───────────────────────────────────────────────────────────────── -->
<section style="padding:4rem 0;background:var(--surface-warm);">
  <div class="container">
    <div class="text-center" style="margin-bottom:2.5rem;">
      <span class="section-label">How We Work</span>
      <h2 class="section-title">Our Development Process</h2>
    </div>
    <div class="process-grid">
      <?php $steps = [
        ['1','Discovery','We understand your business, goals, target audience, and competitors.'],
        ['2','Design','Wireframes → mockups → your approval before we write a single line of code.'],
        ['3','Build','Clean, fast, secure development with regular progress updates.'],
        ['4','Launch & Support','Testing, launch, and ongoing support to keep your site performing.'],
      ];
      foreach($steps as $s): ?>
      <div class="process-step">
        <div class="process-num"><?php echo $s[0]; ?></div>
        <h3><?php echo esc_html($s[1]); ?></h3>
        <p><?php echo esc_html($s[2]); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ── FAQ ──────────────────────────────────────────────────────────────────── -->
<section style="padding:4rem 0;">
  <div class="container">
    <div class="text-center" style="margin-bottom:2.5rem;">
      <span class="section-label">FAQ</span>
      <h2 class="section-title">Common Questions</h2>
    </div>
    <div class="faq-list" style="margin-top:0;">
      <?php $faqs = [
        ['How long does it take?','Starter sites: 2–3 weeks. Premium: 4–6 weeks. Custom projects: timeline agreed upfront. We always hit our deadlines.'],
        ['Do I own the website?','100%. Once the project is complete and payment is made, you own everything — the code, design, and content.'],
        ['Can you redesign my existing site?','Absolutely. We can redesign and rebuild your existing site while keeping your SEO rankings and content.'],
        ['What platform do you build on?','We mainly build on WordPress (WooCommerce), Shopify, and custom HTML/CSS/JS. We recommend based on your needs.'],
        ['Is hosting included?','Hosting is not included in the one-time fee but we can help you set up fast, reliable hosting at the best price.'],
        ['What if I need changes after launch?','All plans include post-launch support. After that, we offer affordable maintenance retainers.'],
      ];
      foreach($faqs as $i => $faq): ?>
      <div class="faq-item<?php echo $i===0?' open':''; ?>">
        <button class="faq-question" aria-expanded="<?php echo $i===0?'true':'false'; ?>">
          <span><?php echo esc_html($faq[0]); ?></span>
          <span class="faq-arrow">▼</span>
        </button>
        <p class="faq-answer"><?php echo esc_html($faq[1]); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ── CTA ──────────────────────────────────────────────────────────────────── -->
<section class="cta-section">
  <div class="container">
    <div class="cta-inner">
      <h2>Ready to Build Your Website?</h2>
      <p>Get a free consultation and quote. We'll respond within 24 hours.</p>
      <div class="cta-btns">
        <a href="<?php echo home_url('/contact'); ?>" class="btn-primary">Get a Free Quote →</a>
        <a href="<?php echo home_url('/services'); ?>" class="btn-outline-light">View All Services</a>
      </div>
    </div>
  </div>
</section>

</main>

<!-- Pricing cards responsive -->
<style>
@media (max-width: 900px) {
  .pricing-grid-3 { grid-template-columns: 1fr !important; max-width: 420px !important; }
}
</style>

<?php get_footer(); ?>
