<?php
/**
 * Template Name: Terms of Service
 */
get_header();
?>
<main>
    <section style="padding:3rem 0 5rem;">
        <div class="container">
            <div class="legal-page">
                <h1>Terms of Service</h1>
                <p><em>Last updated: <?php echo date('F Y'); ?></em></p>

                <h2>1. Agreement to Terms</h2>
                <p>By accessing or using the Advertza website and services, you agree to be bound by these Terms of Service. If you do not agree to these terms, please do not use our services.</p>

                <h2>2. Services</h2>
                <p>Advertza provides digital marketing services including but not limited to: paid advertising management (Google, Meta, TikTok, Amazon), SEO, email marketing, and creative services. Specific services, deliverables, and fees will be outlined in individual service agreements or proposals.</p>

                <h2>3. Client Responsibilities</h2>
                <p>Clients are responsible for:</p>
                <ul>
                    <li>Providing accurate and timely information required for service delivery</li>
                    <li>Granting necessary access to advertising accounts, analytics, and platforms</li>
                    <li>Ensuring all content and creative assets comply with applicable laws and platform policies</li>
                    <li>Timely payment of invoices as agreed</li>
                </ul>

                <h2>4. Payment Terms</h2>
                <p>Payment terms are outlined in individual client proposals. All invoices are due within 14 days of issue unless otherwise agreed. Late payments may result in service suspension.</p>

                <h2>5. Intellectual Property</h2>
                <p>Upon full payment, clients own the creative assets and campaign materials produced specifically for them. Advertza retains ownership of proprietary tools, methodologies, and processes used in service delivery.</p>

                <h2>6. Confidentiality</h2>
                <p>Both parties agree to keep confidential any proprietary business information shared during the engagement. This obligation survives the termination of the service agreement.</p>

                <h2>7. Results Disclaimer</h2>
                <p>While we strive for excellent results, Advertza cannot guarantee specific outcomes as digital advertising performance is influenced by many factors including market conditions, competition, and platform algorithm changes.</p>

                <h2>8. Limitation of Liability</h2>
                <p>To the maximum extent permitted by law, Advertza's liability shall be limited to the fees paid in the month in which the issue arose. We are not liable for indirect, incidental, or consequential damages.</p>

                <h2>9. Termination</h2>
                <p>Either party may terminate services with 30 days' written notice unless otherwise agreed. Advertza reserves the right to terminate immediately for non-payment or breach of these terms.</p>

                <h2>10. Governing Law</h2>
                <p>These Terms are governed by the laws of England & Wales. Any disputes shall be resolved in the courts of England & Wales.</p>

                <h2>11. Contact</h2>
                <p>For questions about these Terms, contact us at <a href="mailto:hello@advertza.com" style="color:var(--gold);">hello@advertza.com</a>.</p>
            </div>
        </div>
    </section>
</main>
<?php get_footer(); ?>
