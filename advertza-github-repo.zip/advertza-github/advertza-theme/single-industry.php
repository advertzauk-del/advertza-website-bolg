<?php
/**
 * Single Industry Page — works for CPT posts AND pages under /industries/
 */
get_header();

global $post;
if ( ! is_object($post) ) {
    $post = get_queried_object();
}
if ( have_posts() ) {
    the_post();
} else {
    setup_postdata($post);
}

$slug  = get_post_field( 'post_name', get_the_ID() );
$title = get_the_title();

$industry_data = array(
    'fashion'        => array('icon'=>'👗','tagline'=>'Scale your fashion brand with targeted ads and conversion-focused campaigns.','color'=>'#EC4899'),
    'beauty'         => array('icon'=>'💄','tagline'=>'Grow your beauty brand with creative storytelling and precision-targeted marketing.','color'=>'#F472B6'),
    'home-garden'    => array('icon'=>'🏡','tagline'=>'Drive qualified buyers to your home & garden products through strategic marketing.','color'=>'#10B981'),
    'electronics'    => array('icon'=>'📱','tagline'=>'Navigate competitive tech markets with data-driven advertising that converts.','color'=>'#3B82F6'),
    'health-wellness'=> array('icon'=>'💪','tagline'=>'Build trust and drive conversions in the health & wellness space.','color'=>'#22C55E'),
    'food-beverage'  => array('icon'=>'🍕','tagline'=>'Grow your F&B brand with appetite-inducing creative that converts.','color'=>'#F59E0B'),
    'pet-supplies'   => array('icon'=>'🐾','tagline'=>'Tap into the passionate pet owner market with targeted campaigns.','color'=>'#8B5CF6'),
    'jewelry'        => array('icon'=>'💍','tagline'=>'Showcase your jewelry with stunning creative and targeted campaigns.','color'=>'#FBBF24'),
    'sporting-goods' => array('icon'=>'⚽','tagline'=>'Reach active consumers and drive sales for sporting goods brands.','color'=>'#14B8A6'),
    'custom'         => array('icon'=>'✨','tagline'=>'Custom marketing solutions for any eCommerce vertical.','color'=>'var(--gold)'),
);

$data    = isset($industry_data[$slug]) ? $industry_data[$slug] : array('icon'=>'🏭','tagline'=>'Specialized performance marketing for your industry.','color'=>'var(--gold)');
$icon    = get_post_meta( get_the_ID(), 'icon', true ) ?: $data['icon'];
$tagline = get_post_meta( get_the_ID(), 'tagline', true ) ?: $data['tagline'];
?>
<main>
    <!-- Hero -->
    <section style="padding:4rem 0 3rem;background:var(--charcoal);">
        <div class="container">
            <div style="max-width:42rem;">
                <a href="<?php echo home_url('/industries'); ?>" style="font-size:0.8rem;color:rgba(255,255,255,0.5);display:inline-flex;align-items:center;gap:0.4rem;margin-bottom:1.5rem;transition:color 0.2s;" onmouseover="this.style.color='var(--gold)'" onmouseout="this.style.color='rgba(255,255,255,0.5)'">
                    ← All Industries
                </a>
                <div style="font-size:3.5rem;margin-bottom:1rem;"><?php echo esc_html($icon); ?></div>
                <h1 style="font-size:clamp(2rem,5vw,3rem);font-weight:800;color:#fff;margin-bottom:1rem;"><?php the_title(); ?></h1>
                <p style="color:rgba(255,255,255,0.7);font-size:1.1rem;margin-bottom:2rem;"><?php echo esc_html($tagline); ?></p>
                <a href="<?php echo home_url('/contact'); ?>" class="btn-primary">Get Industry Strategy →</a>
            </div>
        </div>
    </section>

    <!-- Editor content if any -->
    <?php if ( get_the_content() ) : ?>
    <section style="padding:3.5rem 0;">
        <div class="container">
            <div style="max-width:48rem;margin:0 auto;font-size:1rem;line-height:1.8;color:var(--muted-foreground);">
                <?php the_content(); ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <!-- Challenges & Solutions -->
    <section style="padding:4rem 0;background:var(--surface-warm);">
        <div class="container">
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:3rem;align-items:start;">
                <div>
                    <span class="section-label">Industry Challenges</span>
                    <h2 class="section-title">What <?php the_title(); ?> Brands Face</h2>
                    <div style="display:flex;flex-direction:column;gap:1.25rem;margin-top:1.5rem;">
                        <?php
                        $challenges_map = array(
                            'fashion'     => ['High competition and rising CPCs in clothing categories','Seasonal demand fluctuations require agile budget management','Creative fatigue — ads need constant refresh to stay effective','Returns & size issues affecting real ROAS calculations'],
                            'beauty'      => ['Strict advertising policies on health claims across platforms','High competition from both global brands and indie DTC labels','Influencer-driven market requires integrated paid + creator strategy','Subscription and LTV models need smart retention marketing'],
                            'electronics' => ['Razor-thin margins demand highly efficient CPA targets','Fast product cycles require agile campaign management','High-research buyers need full-funnel nurturing','Counterfeit competition on marketplace platforms'],
                            'default'     => ['Rising advertising costs and increased competition','Difficulty standing out in a crowded marketplace','Converting browsers into buyers across multiple touchpoints','Maintaining profitable ROAS while scaling ad spend'],
                        );
                        $challenges = isset($challenges_map[$slug]) ? $challenges_map[$slug] : $challenges_map['default'];
                        foreach($challenges as $c): ?>
                        <div style="display:flex;gap:0.75rem;align-items:flex-start;">
                            <span style="color:#ef4444;font-size:1.1rem;flex-shrink:0;margin-top:2px;">✗</span>
                            <p style="font-size:0.9rem;color:var(--muted-foreground);line-height:1.6;"><?php echo esc_html($c); ?></p>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div style="background:var(--charcoal);border-radius:1rem;padding:2.5rem;">
                    <h3 style="color:#fff;font-size:1.25rem;font-weight:800;margin-bottom:1.5rem;">The Advertza Solution</h3>
                    <?php
                    $solutions = ['Industry-specific campaign structures proven to reduce CPA','Creative strategy tailored to your customer\'s buying journey','Full-funnel approach from awareness to post-purchase retention','Transparent reporting focused on real revenue — not vanity metrics'];
                    foreach($solutions as $s): ?>
                    <div style="display:flex;gap:0.75rem;margin-bottom:1.25rem;">
                        <span style="color:var(--gold);font-size:1.1rem;flex-shrink:0;">✓</span>
                        <p style="font-size:0.875rem;color:rgba(255,255,255,0.7);line-height:1.6;"><?php echo esc_html($s); ?></p>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </section>

    <!-- Services for this industry -->
    <section style="padding:4rem 0;">
        <div class="container">
            <div class="text-center" style="margin-bottom:2.5rem;">
                <span class="section-label">What We Offer</span>
                <h2 class="section-title">Marketing Services for <?php the_title(); ?></h2>
            </div>
            <div class="services-grid">
                <?php
                $services = [
                    ['🔍','Google Ads','/services/google-ads','Search & Shopping campaigns that capture buyers at peak intent.'],
                    ['👥','Meta Ads','/services/meta-ads','Facebook & Instagram campaigns with stunning creative and precise targeting.'],
                    ['🎬','TikTok Ads','/services/tiktok-ads','Reach new audiences with authentic, high-performing TikTok content.'],
                    ['✉️','Email & SMS','/services/email-marketing','Retention flows that turn first-time buyers into loyal repeat customers.'],
                    ['📊','Analytics & CRO','/services/analytics','Optimize your store for higher conversion rates and better ROI.'],
                    ['🎨','Creative Services','/services/creative','High-converting ad creatives tailored for your industry audience.'],
                ];
                foreach($services as $s): ?>
                <a href="<?php echo home_url($s[2]); ?>" class="service-card">
                    <div class="service-icon"><?php echo $s[0]; ?></div>
                    <h3 class="service-title"><?php echo esc_html($s[1]); ?></h3>
                    <p class="service-desc"><?php echo esc_html($s[3]); ?></p>
                    <span class="service-link">Learn More →</span>
                </a>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- Stats -->
    <section style="padding:4rem 0;background:var(--surface-warm);">
        <div class="container" style="text-align:center;">
            <span class="section-label">Proven Results</span>
            <h2 class="section-title">What We've Achieved for <?php the_title(); ?> Brands</h2>
            <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:2rem;margin-top:2.5rem;max-width:56rem;margin-left:auto;margin-right:auto;">
                <?php $stats = [['3.8x','Average ROAS'],['280%','Revenue Growth'],['60%','Lower CPA'],['200+','Happy Clients']];
                foreach($stats as $s): ?>
                <div style="background:#fff;border:1.5px solid var(--border);border-radius:var(--radius);padding:1.75rem;">
                    <p style="font-size:2.25rem;font-weight:800;color:var(--gold);"><?php echo $s[0]; ?></p>
                    <p style="font-size:0.8rem;color:var(--muted-foreground);margin-top:0.25rem;"><?php echo $s[1]; ?></p>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- CTA -->
    <section class="cta-section">
        <div class="container">
            <div class="cta-inner">
                <h2>Ready to Grow Your <?php the_title(); ?> Brand?</h2>
                <p>Get a free audit and a custom strategy built specifically for your industry.</p>
                <div class="cta-btns">
                    <a href="<?php echo home_url('/contact'); ?>" class="btn-primary">Get Your Free Audit →</a>
                    <a href="<?php echo home_url('/industries'); ?>" class="btn-outline-light">All Industries</a>
                </div>
            </div>
        </div>
    </section>
</main>
<?php get_footer(); ?>
