<?php
/**
 * Single Service Page — works for CPT posts AND pages under /services/
 */
get_header();

// Setup post data properly for both pages and CPT
global $post;
if ( ! is_object($post) ) {
    $post = get_queried_object();
}
if ( have_posts() ) {
    the_post();
} else {
    setup_postdata($post);
}

$icon    = get_post_meta( get_the_ID(), 'icon', true );
$tagline = get_post_meta( get_the_ID(), 'tagline', true );

// Service-specific data based on slug
$slug = get_post_field( 'post_name', get_the_ID() );
$title = get_the_title();

$service_data = array(
    'google-ads'      => array('icon'=>'🔍','tagline'=>'Profitable search, shopping & YouTube campaigns that convert.','color'=>'#4285F4'),
    'meta-ads'        => array('icon'=>'👥','tagline'=>'Facebook & Instagram ads that build brand and drive sales.','color'=>'#1877F2'),
    'tiktok-ads'      => array('icon'=>'🎬','tagline'=>'Scroll-stopping TikTok creative that reaches new audiences.','color'=>'#010101'),
    'amazon-ads'      => array('icon'=>'🛍️','tagline'=>'Dominate Amazon search results and grow marketplace revenue.','color'=>'#FF9900'),
    'analytics'       => array('icon'=>'📊','tagline'=>'Turn your data into decisions that increase ROI.','color'=>'#E8710A'),
    'email-marketing' => array('icon'=>'✉️','tagline'=>'Retention flows that turn buyers into loyal repeat customers.','color'=>'#6366F1'),
    'shopify'         => array('icon'=>'🛒','tagline'=>'End-to-end marketing for Shopify stores that scales.','color'=>'#96BF48'),
    'woocommerce'     => array('icon'=>'🔧','tagline'=>'Growth marketing tailored for WooCommerce stores.','color'=>'#7F54B3'),
    'creative'        => array('icon'=>'🎨','tagline'=>'High-converting creatives and landing pages that perform.','color'=>'#EC4899'),
    'influencer'      => array('icon'=>'🌟','tagline'=>'Authentic influencer partnerships that drive real sales.','color'=>'#F59E0B'),
    'marketplace-ads' => array('icon'=>'🏪','tagline'=>'Multi-marketplace advertising across eBay, Walmart & more.','color'=>'#10B981'),
    'bigcommerce'     => array('icon'=>'⚡','tagline'=>'Enterprise marketing solutions for BigCommerce platforms.','color'=>'#121118'),
    'cro'             => array('icon'=>'🔄','tagline'=>'Convert more visitors without spending more on ads.','color'=>'#EF4444'),
    'magento'         => array('icon'=>'🧲','tagline'=>'Complex catalog marketing for Magento enterprise stores.','color'=>'#EE672F'),
);

$data = isset($service_data[$slug]) ? $service_data[$slug] : array('icon'=>'📊','tagline'=>'Performance marketing that drives real business results.','color'=>'var(--gold)');
if (!$icon) $icon = $data['icon'];
if (!$tagline) $tagline = $data['tagline'];
?>
<main>
    <!-- Hero -->
    <section style="padding:4rem 0 3rem;background:var(--charcoal);">
        <div class="container">
            <div style="max-width:42rem;">
                <a href="<?php echo home_url('/services'); ?>" style="font-size:0.8rem;color:rgba(255,255,255,0.5);display:inline-flex;align-items:center;gap:0.4rem;margin-bottom:1.5rem;transition:color 0.2s;" onmouseover="this.style.color='var(--gold)'" onmouseout="this.style.color='rgba(255,255,255,0.5)'">
                    ← Back to All Services
                </a>
                <div style="font-size:3.5rem;margin-bottom:1rem;"><?php echo esc_html($icon); ?></div>
                <h1 style="font-size:clamp(2rem,5vw,3rem);font-weight:800;color:#fff;margin-bottom:1rem;"><?php the_title(); ?></h1>
                <p style="color:rgba(255,255,255,0.7);font-size:1.1rem;margin-bottom:2rem;"><?php echo esc_html($tagline); ?></p>
                <a href="<?php echo home_url('/contact'); ?>" class="btn-primary">Get Started for Free →</a>
            </div>
        </div>
    </section>

    <!-- Content (if any from WP editor) -->
    <?php if ( get_the_content() ) : ?>
    <section style="padding:3.5rem 0;">
        <div class="container">
            <div style="max-width:48rem;margin:0 auto;font-size:1rem;line-height:1.8;color:var(--muted-foreground);">
                <?php the_content(); ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <!-- What We Do for this service -->
    <section style="padding:4rem 0;background:var(--surface-warm);">
        <div class="container">
            <div class="text-center" style="margin-bottom:2.5rem;">
                <span class="section-label">What's Included</span>
                <h2 class="section-title">Everything You Get</h2>
            </div>
            <div class="features-grid">
                <?php
                $features_map = array(
                    'google-ads' => [
                        ['🔍','Search Campaigns','High-intent keyword targeting that captures buyers at the moment of purchase.'],
                        ['🛒','Shopping & PMax','Product listing ads and Performance Max campaigns for maximum reach.'],
                        ['▶️','YouTube Ads','Video advertising that builds brand awareness and retargets warm audiences.'],
                        ['📊','Conversion Tracking','Accurate attribution setup so every click and conversion is accounted for.'],
                        ['🔄','Ongoing Optimisation','Daily bid management, negative keywords, and ad copy testing.'],
                        ['📋','Monthly Reporting','Clear reports showing ROAS, CPA, revenue, and actionable next steps.'],
                    ],
                    'meta-ads' => [
                        ['🎯','Audience Targeting','Laser-focused targeting using custom audiences, lookalikes, and interest stacks.'],
                        ['🎨','Creative Strategy','Scroll-stopping ad creative and copy tested across multiple formats.'],
                        ['🛒','Catalogue Ads','Dynamic product ads that show the right product to the right person.'],
                        ['🔄','Retargeting Funnels','Multi-stage retargeting sequences that nurture prospects to purchase.'],
                        ['📊','Pixel Setup','Complete Meta Pixel and CAPI implementation for accurate tracking.'],
                        ['📋','Weekly Reports','Performance dashboards with ROAS, CPA, and revenue breakdowns.'],
                    ],
                    'default' => [
                        ['🎯','Strategy & Setup','Custom strategy built around your brand, goals, and target audience.'],
                        ['🚀','Campaign Launch','Professional setup and launch across all relevant placements.'],
                        ['🔄','Ongoing Optimisation','Continuous testing and optimisation to improve results week over week.'],
                        ['📊','Analytics & Tracking','Full tracking setup so you know exactly what\'s working and why.'],
                        ['📋','Transparent Reporting','Regular reports showing real business metrics — not vanity numbers.'],
                        ['🤝','Dedicated Support','Direct access to your account manager with regular strategy calls.'],
                    ],
                );
                $features = isset($features_map[$slug]) ? $features_map[$slug] : $features_map['default'];
                foreach($features as $f): ?>
                <div class="feature-card">
                    <div class="feature-icon"><?php echo $f[0]; ?></div>
                    <h3 class="feature-title"><?php echo esc_html($f[1]); ?></h3>
                    <p class="feature-desc"><?php echo esc_html($f[2]); ?></p>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- Results / Stats -->
    <section style="padding:4rem 0;">
        <div class="container">
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:3rem;align-items:center;">
                <div>
                    <span class="section-label">Results We Deliver</span>
                    <h2 class="section-title">Real Numbers from Real Clients</h2>
                    <p style="color:var(--muted-foreground);margin-bottom:2rem;line-height:1.8;">
                        Our <?php the_title(); ?> campaigns consistently outperform industry benchmarks. Here's what our clients have achieved working with us.
                    </p>
                    <a href="<?php echo home_url('/contact'); ?>" class="btn-primary">Get Your Free Audit →</a>
                </div>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:1.5rem;">
                    <?php $stats = [['3.8x','Average ROAS'],['60%','Lower CPA'],['280%','Revenue Growth'],['30 Days','First Results']];
                    foreach($stats as $s): ?>
                    <div style="background:var(--surface-warm);border:1.5px solid var(--border);border-radius:var(--radius);padding:1.5rem;text-align:center;">
                        <p style="font-size:2rem;font-weight:800;color:var(--gold);"><?php echo $s[0]; ?></p>
                        <p style="font-size:0.8rem;color:var(--muted-foreground);margin-top:0.25rem;"><?php echo $s[1]; ?></p>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA -->
    <section class="cta-section">
        <div class="container">
            <div class="cta-inner">
                <h2>Ready to Start with <?php the_title(); ?>?</h2>
                <p>Book a free audit and let's discuss your growth goals today.</p>
                <div class="cta-btns">
                    <a href="<?php echo home_url('/contact'); ?>" class="btn-primary">Get Your Free Audit →</a>
                    <a href="<?php echo home_url('/services'); ?>" class="btn-outline-light">View All Services</a>
                </div>
            </div>
        </div>
    </section>
</main>
<?php get_footer(); ?>
