<div class="consultation-card">
    <h3>Get Your Free Audit</h3>
    <p>Tell us about your business and we'll prepare a custom growth plan.</p>

    <div id="consult-form-msg" style="display:none;padding:0.75rem 1rem;border-radius:0.5rem;margin-bottom:1rem;font-size:0.875rem;font-weight:600;"></div>

    <form id="consultation-form" novalidate>
        <?php wp_nonce_field( 'advertza_nonce', 'nonce' ); ?>
        <div class="form-row">
            <div class="form-group">
                <label for="cf-name">Full Name *</label>
                <input type="text" id="cf-name" name="name" placeholder="John Smith" required>
            </div>
            <div class="form-group">
                <label for="cf-email">Email Address *</label>
                <input type="email" id="cf-email" name="email" placeholder="john@brand.com" required>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label for="cf-phone">Phone / WhatsApp</label>
                <input type="tel" id="cf-phone" name="phone" placeholder="+44 or +91...">
            </div>
            <div class="form-group">
                <label for="cf-website">Website URL</label>
                <input type="url" id="cf-website" name="website" placeholder="https://yourstore.com">
            </div>
        </div>
        <div class="form-group">
            <label for="cf-budget">Monthly Ad Budget</label>
            <select id="cf-budget" name="budget">
                <option value="">Select budget range</option>
                <optgroup label="India (INR)">
                    <option value="Under ₹10,000/mo">Under ₹10,000/mo</option>
                    <option value="₹10,000 - ₹50,000/mo">₹10,000 – ₹50,000/mo</option>
                    <option value="₹50,000 - ₹1,00,000/mo">₹50,000 – ₹1,00,000/mo</option>
                    <option value="₹1,00,000 - ₹5,00,000/mo">₹1,00,000 – ₹5,00,000/mo</option>
                    <option value="₹5,00,000+/mo">₹5,00,000+/mo</option>
                </optgroup>
                <optgroup label="UK (GBP)">
                    <option value="Under £1,000/mo">Under £1,000/mo</option>
                    <option value="£1,000 - £5,000/mo">£1,000 – £5,000/mo</option>
                    <option value="£5,000 - £10,000/mo">£5,000 – £10,000/mo</option>
                    <option value="£10,000 - £25,000/mo">£10,000 – £25,000/mo</option>
                    <option value="£25,000+/mo">£25,000+/mo</option>
                </optgroup>
                <optgroup label="USD">
                    <option value="Under $1,000/mo">Under $1,000/mo</option>
                    <option value="$1,000 - $5,000/mo">$1,000 – $5,000/mo</option>
                    <option value="$5,000 - $10,000/mo">$5,000 – $10,000/mo</option>
                    <option value="$10,000+/mo">$10,000+/mo</option>
                </optgroup>
            </select>
        </div>
        <div class="form-group">
            <label for="cf-services">Services Interested In</label>
            <select id="cf-services" name="services">
                <option value="">Select a service</option>
                <option value="Google Ads">Google Ads</option>
                <option value="Meta Ads">Meta Ads (Facebook / Instagram)</option>
                <option value="TikTok Ads">TikTok Ads</option>
                <option value="Amazon Ads">Amazon Ads</option>
                <option value="Email Marketing">Email Marketing</option>
                <option value="Web Development">Web Development</option>
                <option value="Shopify">Shopify</option>
                <option value="WooCommerce">WooCommerce</option>
                <option value="Analytics &amp; CRO">Analytics &amp; CRO</option>
                <option value="Creative &amp; Content">Creative &amp; Content</option>
                <option value="Influencer Marketing">Influencer Marketing</option>
                <option value="Marketplace Ads">Marketplace Ads</option>
            </select>
        </div>
        <div class="form-group">
            <label for="cf-message">What are your main marketing goals?</label>
            <textarea id="cf-message" name="message" placeholder="E.g. Increase ROAS, launch on new platforms, scale to UK market..."></textarea>
        </div>
        <button type="submit" class="btn-primary form-submit" id="consult-submit">
            <span id="consult-btn-text">Request Free Audit &rarr;</span>
        </button>
    </form>
</div>
