<?php
/**
 * Single Blog Post Template - Advertza
 */
get_header();
the_post();

$cats      = get_the_category();
$cat_name  = ! empty($cats) ? $cats[0]->name : 'Marketing';
$read_time = ceil( str_word_count( strip_tags( get_the_content() ) ) / 200 ) ?: 1;
$author_id = get_the_author_meta('ID');
?>
<main>

    <!-- Hero / Title Banner -->
    <section style="background:linear-gradient(135deg,hsl(220,20%,10%) 0%,hsl(220,20%,16%) 100%);padding:4rem 0 3.5rem;position:relative;overflow:hidden;">
        <div style="position:absolute;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,var(--gold),var(--gold-light),var(--gold));"></div>
        <div class="container">
            <div style="max-width:52rem;margin:0 auto;">

                <!-- Breadcrumb -->
                <nav style="font-size:0.78rem;color:rgba(255,255,255,0.45);margin-bottom:1.5rem;display:flex;align-items:center;gap:0.4rem;flex-wrap:wrap;">
                    <a href="<?php echo home_url('/'); ?>" style="color:var(--gold);text-decoration:none;">Home</a>
                    <span>›</span>
                    <a href="<?php echo home_url('/blog'); ?>" style="color:var(--gold);text-decoration:none;">Blog</a>
                    <span>›</span>
                    <span style="color:rgba(255,255,255,0.6);"><?php echo esc_html( wp_trim_words( get_the_title(), 8 ) ); ?></span>
                </nav>

                <!-- Category badge -->
                <span style="display:inline-block;background:rgba(201,168,76,0.15);border:1px solid rgba(201,168,76,0.4);color:var(--gold);font-size:0.7rem;font-weight:700;text-transform:uppercase;letter-spacing:0.08em;padding:0.3rem 0.85rem;border-radius:100px;margin-bottom:1.1rem;"><?php echo esc_html($cat_name); ?></span>

                <!-- Title -->
                <h1 style="font-size:clamp(1.75rem,4.5vw,2.75rem);font-weight:800;color:#fff;line-height:1.2;margin-bottom:1.5rem;"><?php the_title(); ?></h1>

                <!-- Meta row -->
                <div style="display:flex;align-items:center;gap:0.75rem;flex-wrap:wrap;color:rgba(255,255,255,0.5);font-size:0.82rem;">
                    <?php echo get_avatar($author_id, 28, '', '', array('style'=>'border-radius:50%;border:2px solid rgba(201,168,76,0.4);')); ?>
                    <span style="color:rgba(255,255,255,0.8);"><?php the_author(); ?></span>
                    <span>·</span>
                    <span><?php echo get_the_date('M j, Y'); ?></span>
                    <span>·</span>
                    <span><?php echo $read_time; ?> min read</span>
                </div>

            </div>
        </div>
    </section>

    <!-- Featured Image -->
    <?php if ( has_post_thumbnail() ) : ?>
    <div style="background:hsl(220,20%,13%);">
        <div class="container">
            <div style="max-width:52rem;margin:0 auto;">
                <div style="border-radius:0 0 var(--radius) var(--radius);overflow:hidden;max-height:420px;">
                    <?php the_post_thumbnail('large', array('style'=>'width:100%;height:420px;object-fit:cover;object-position:center;display:block;')); ?>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Article Content -->
    <article style="padding:3.5rem 0 2rem;">
        <div class="container">
            <div style="max-width:52rem;margin:0 auto;">

                <div class="post-content adv-prose">
                    <?php the_content(); ?>
                </div>

                <!-- Tags -->
                <?php if ( has_tag() ) : ?>
                <div style="margin-top:2.5rem;padding-top:1.75rem;border-top:1px solid var(--border);display:flex;align-items:center;gap:0.5rem;flex-wrap:wrap;">
                    <span style="font-size:0.8rem;font-weight:700;color:var(--foreground);">Tags:</span>
                    <?php foreach ( get_the_tags() as $tag ) : ?>
                    <span style="font-size:0.75rem;background:var(--surface-warm,#f5f3ee);color:var(--muted-foreground);padding:0.25rem 0.75rem;border-radius:100px;border:1px solid var(--border);"><?php echo esc_html($tag->name); ?></span>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>

                <!-- Prev / Next -->
                <div style="margin-top:2.5rem;padding-top:1.75rem;border-top:1px solid var(--border);display:flex;justify-content:space-between;gap:1rem;flex-wrap:wrap;">
                    <?php $prev = get_previous_post(); $next = get_next_post(); ?>
                    <?php if ($prev) : ?><a href="<?php echo get_permalink($prev->ID); ?>" style="font-size:0.85rem;color:var(--gold);font-weight:700;text-decoration:none;">← <?php echo esc_html( wp_trim_words($prev->post_title,6) ); ?></a><?php else: ?><span></span><?php endif; ?>
                    <?php if ($next) : ?><a href="<?php echo get_permalink($next->ID); ?>" style="font-size:0.85rem;color:var(--gold);font-weight:700;text-decoration:none;text-align:right;"><?php echo esc_html( wp_trim_words($next->post_title,6) ); ?> →</a><?php endif; ?>
                </div>

            </div>
        </div>
    </article>

    <!-- Author Box -->
    <section style="padding:0 0 3.5rem;">
        <div class="container">
            <div style="max-width:52rem;margin:0 auto;">
                <div style="background:var(--surface-warm,#f9f8f4);border:1.5px solid var(--border);border-radius:var(--radius);padding:1.5rem;display:flex;gap:1.25rem;align-items:flex-start;">
                    <?php echo get_avatar($author_id, 64, '', '', array('style'=>'border-radius:50%;flex-shrink:0;border:2px solid var(--gold);')); ?>
                    <div>
                        <p style="font-weight:800;font-size:1rem;margin-bottom:0.25rem;"><?php the_author(); ?></p>
                        <p style="font-size:0.85rem;color:var(--muted-foreground);line-height:1.6;"><?php echo esc_html( get_the_author_meta('description') ?: 'Performance Marketing Expert at Advertza — helping brands scale profitably across Google, Meta, TikTok & Amazon.' ); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Related Posts -->
    <?php
    $related = get_posts( array(
        'category__in'   => wp_get_post_categories( get_the_ID() ),
        'post__not_in'   => array( get_the_ID() ),
        'posts_per_page' => 3,
        'post_status'    => 'publish',
    ) );
    if ( ! empty($related) ) : ?>
    <section style="background:var(--surface-warm,#f9f8f4);padding:4rem 0;">
        <div class="container">
            <div style="max-width:52rem;margin:0 auto;">
                <h3 style="font-size:1.35rem;font-weight:800;margin-bottom:1.75rem;">Related Articles</h3>
                <div class="adv-related-grid">
                    <?php foreach ( $related as $r ) :
                        $r_cats = get_the_category($r->ID);
                        $r_cat  = ! empty($r_cats) ? $r_cats[0]->name : 'Marketing';
                        $r_img  = get_the_post_thumbnail_url($r->ID, 'medium');
                    ?>
                    <a href="<?php echo get_permalink($r->ID); ?>" class="adv-related-card">
                        <?php if ($r_img) : ?>
                        <div style="height:120px;overflow:hidden;"><img src="<?php echo esc_url($r_img); ?>" alt="" style="width:100%;height:100%;object-fit:cover;display:block;"></div>
                        <?php else : ?>
                        <div style="height:70px;background:linear-gradient(135deg,hsl(220,20%,14%),hsl(220,20%,22%));display:flex;align-items:center;justify-content:center;"><span style="font-size:0.6rem;font-weight:800;letter-spacing:0.1em;color:rgba(201,168,76,0.6);text-transform:uppercase;">Advertza</span></div>
                        <?php endif; ?>
                        <div style="padding:1rem;">
                            <span style="font-size:0.65rem;font-weight:700;color:var(--gold);text-transform:uppercase;letter-spacing:0.06em;"><?php echo esc_html($r_cat); ?></span>
                            <p style="font-size:0.875rem;font-weight:700;color:var(--foreground);line-height:1.4;margin-top:0.3rem;"><?php echo esc_html($r->post_title); ?></p>
                            <span style="font-size:0.75rem;color:var(--gold);font-weight:700;display:inline-block;margin-top:0.65rem;">Read More →</span>
                        </div>
                    </a>
                    <?php endforeach; wp_reset_postdata(); ?>
                </div>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <!-- CTA -->
    <section class="cta-section" style="padding-top:0;">
        <div class="container">
            <div class="cta-inner">
                <h2>Want to Grow Your Brand?</h2>
                <p>Get a free marketing audit and discover your growth potential.</p>
                <div class="cta-btns">
                    <a href="<?php echo home_url('/contact'); ?>" class="btn-primary">Get Your Free Audit →</a>
                </div>
            </div>
        </div>
    </section>

</main>
<?php get_footer(); ?>
