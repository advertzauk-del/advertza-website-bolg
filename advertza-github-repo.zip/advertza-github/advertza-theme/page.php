<?php
/**
 * Generic Page Template — Auto-detects slug and loads right content
 */

// Detect which template to use based on page slug and template meta
$template = get_post_meta( get_the_ID(), '_wp_page_template', true );
$slug     = get_post_field( 'post_name', get_the_ID() );
$parent   = wp_get_post_parent_id( get_the_ID() );
$parent_slug = $parent ? get_post_field( 'post_name', $parent ) : '';

// Route to correct template file
if ( $template === 'page-about.php' || $slug === 'about' ) {
    include( locate_template('page-about.php') );
    exit;
}
if ( $template === 'page-contact.php' || $slug === 'contact' ) {
    include( locate_template('page-contact.php') );
    exit;
}
if ( $template === 'page-privacy-policy.php' || $slug === 'privacy-policy' ) {
    include( locate_template('page-privacy-policy.php') );
    exit;
}
if ( $template === 'page-terms-of-service.php' || $slug === 'terms-of-service' ) {
    include( locate_template('page-terms-of-service.php') );
    exit;
}
if ( $template === 'page-web-development.php' || $slug === 'web-development' ) {
    include( locate_template('page-web-development.php') );
    exit;
}
if ( $template === 'single-service.php' || $parent_slug === 'services' ) {
    include( locate_template('single-service.php') );
    exit;
}
if ( $template === 'single-industry.php' || $parent_slug === 'industries' ) {
    include( locate_template('single-industry.php') );
    exit;
}
if ( $slug === 'services' ) {
    include( locate_template('archive-service.php') );
    exit;
}
if ( $slug === 'industries' ) {
    include( locate_template('archive-industry.php') );
    exit;
}

// Default generic page
get_header();
the_post();
?>
<main>
    <section class="page-hero" style="background:var(--surface-warm);padding:3rem 0 2.5rem;">
        <div class="container">
            <h1><?php the_title(); ?></h1>
        </div>
    </section>
    <section style="padding:2.5rem 0 5rem;">
        <div class="container">
            <div class="legal-page" style="margin:0;max-width:56rem;">
                <?php the_content(); ?>
            </div>
        </div>
    </section>
</main>
<?php get_footer(); ?>
