/**
 * Advertza Theme — Main JavaScript
 */

document.addEventListener('DOMContentLoaded', function () {

  // ─── Mobile Menu Toggle ─────────────────────────────────────────────────────
  const toggle   = document.getElementById('menu-toggle');
  const mobileNav = document.getElementById('mobile-nav');

  if (toggle && mobileNav) {
    toggle.addEventListener('click', function () {
      const isOpen = mobileNav.classList.toggle('open');
      toggle.setAttribute('aria-expanded', isOpen);
    });
  }

  // ─── FAQ Accordion ──────────────────────────────────────────────────────────
  document.querySelectorAll('.faq-question').forEach(function (btn) {
    btn.addEventListener('click', function () {
      const item     = btn.closest('.faq-item');
      const isOpen   = item.classList.contains('open');

      // Close all
      document.querySelectorAll('.faq-item').forEach(function (el) {
        el.classList.remove('open');
        el.querySelector('.faq-question').setAttribute('aria-expanded', 'false');
      });

      // Open clicked (if it was closed)
      if (!isOpen) {
        item.classList.add('open');
        btn.setAttribute('aria-expanded', 'true');
      }
    });
  });

  // ─── Consultation Form AJAX Submit ─────────────────────────────────────────
  const form    = document.getElementById('consultation-form');
  const msgBox  = document.getElementById('consult-form-msg');
  const btnText = document.getElementById('consult-btn-text');

  if (form && typeof advertza_ajax !== 'undefined') {
    form.addEventListener('submit', function (e) {
      e.preventDefault();

      // Basic validation
      const name  = form.querySelector('[name="name"]').value.trim();
      const email = form.querySelector('[name="email"]').value.trim();

      if (!name || !email) {
        showMsg('error', 'Please fill in your name and email.');
        return;
      }

      if (!isValidEmail(email)) {
        showMsg('error', 'Please enter a valid email address.');
        return;
      }

      // Loading state
      btnText.textContent = 'Sending…';
      form.querySelector('#consult-submit').disabled = true;

      const data = new FormData(form);
      data.append('action', 'advertza_contact');
      data.append('nonce', advertza_ajax.nonce);

      fetch(advertza_ajax.ajax_url, {
        method: 'POST',
        body: data,
      })
        .then(function (res) { return res.json(); })
        .then(function (res) {
          if (res.success) {
            showMsg('success', res.data.message || 'Thank you! We will contact you within 24 hours.');
            form.reset();
          } else {
            showMsg('error', res.data.message || 'Something went wrong. Please try again.');
          }
        })
        .catch(function () {
          showMsg('error', 'Network error. Please email us at hello@advertza.com');
        })
        .finally(function () {
          btnText.textContent = 'Request Free Audit →';
          form.querySelector('#consult-submit').disabled = false;
        });
    });
  }

  function showMsg(type, message) {
    if (!msgBox) return;
    msgBox.style.display = 'block';
    msgBox.textContent   = message;
    msgBox.style.background = type === 'success' ? '#d1fae5' : '#fee2e2';
    msgBox.style.color      = type === 'success' ? '#065f46' : '#991b1b';
    msgBox.style.border     = type === 'success' ? '1px solid #6ee7b7' : '1px solid #fca5a5';
    // Scroll to message
    msgBox.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  function isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  }

  // ─── Sticky Header Shadow ───────────────────────────────────────────────────
  const header = document.getElementById('site-header');
  if (header) {
    window.addEventListener('scroll', function () {
      if (window.scrollY > 10) {
        header.style.boxShadow = '0 2px 20px rgba(0,0,0,0.08)';
      } else {
        header.style.boxShadow = 'none';
      }
    }, { passive: true });
  }

  // ─── Scroll-reveal (simple fade-in) ────────────────────────────────────────
  const revealEls = document.querySelectorAll(
    '.service-card, .testimonial-card, .value-card, .process-step, .blog-card'
  );

  if ('IntersectionObserver' in window && revealEls.length) {
    const observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.style.opacity  = '1';
          entry.target.style.transform = 'translateY(0)';
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1 });

    revealEls.forEach(function (el) {
      el.style.opacity   = '0';
      el.style.transform = 'translateY(20px)';
      el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
      observer.observe(el);
    });
  }

  // ─── Active nav link highlight ──────────────────────────────────────────────
  const currentPath = window.location.pathname;
  document.querySelectorAll('.main-nav a, .mobile-nav a').forEach(function (link) {
    const href = link.getAttribute('href');
    if (href && href !== '/' && currentPath.startsWith(href)) {
      link.classList.add('active');
    }
  });

});

/* ── Custom Multi-Select Dropdown ─────────────────────────────────────────── */
(function () {
    function initMultiSelect(wrap) {
        const trigger  = wrap.querySelector('.cms-trigger');
        const dropdown = wrap.querySelector('.cms-dropdown');
        const tagsEl   = document.getElementById('cf-services-tags');
        const placeholder = trigger.querySelector('.cms-placeholder');
        if (!trigger || !dropdown) return;

        function getChecked() {
            return Array.from(wrap.querySelectorAll('input[type="checkbox"]:checked'));
        }

        function updateTrigger() {
            const checked = getChecked();
            // Update placeholder text
            if (checked.length === 0) {
                placeholder.textContent = 'Select services\u2026';
                trigger.classList.remove('has-selection');
                // Remove count badge if exists
                const badge = trigger.querySelector('.cms-count');
                if (badge) badge.remove();
            } else {
                placeholder.textContent = checked.length === 1
                    ? checked[0].value
                    : checked.length + ' services selected';
                trigger.classList.add('has-selection');
                // Update or add count badge
                let badge = trigger.querySelector('.cms-count');
                if (!badge) {
                    badge = document.createElement('span');
                    badge.className = 'cms-count';
                    trigger.insertBefore(badge, trigger.querySelector('.cms-arrow'));
                }
                badge.textContent = checked.length;
            }
        }

        function updateTags() {
            if (!tagsEl) return;
            tagsEl.innerHTML = '';
            getChecked().forEach(function (cb) {
                const label = cb.closest('.cms-option').querySelector('.cms-label').textContent;
                const tag = document.createElement('span');
                tag.className = 'cms-tag';
                tag.innerHTML = label + '<button type="button" class="cms-tag-remove" aria-label="Remove ' + label + '">&times;</button>';
                tag.querySelector('.cms-tag-remove').addEventListener('click', function (e) {
                    e.stopPropagation();
                    cb.checked = false;
                    updateTrigger();
                    updateTags();
                    updateOptionHighlight(cb.closest('.cms-option'));
                });
                tagsEl.appendChild(tag);
            });
        }

        function updateOptionHighlight(option) {
            // No extra action needed — CSS handles :checked state
        }

        function openDropdown() {
            dropdown.classList.add('open');
            trigger.classList.add('open');
            trigger.setAttribute('aria-expanded', 'true');
        }

        function closeDropdown() {
            dropdown.classList.remove('open');
            trigger.classList.remove('open');
            trigger.setAttribute('aria-expanded', 'false');
        }

        // Toggle on trigger click
        trigger.addEventListener('click', function (e) {
            e.stopPropagation();
            dropdown.classList.contains('open') ? closeDropdown() : openDropdown();
        });

        // Keyboard: Enter/Space to open
        trigger.addEventListener('keydown', function (e) {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                dropdown.classList.contains('open') ? closeDropdown() : openDropdown();
            }
            if (e.key === 'Escape') closeDropdown();
        });

        // Handle checkbox changes
        dropdown.querySelectorAll('input[type="checkbox"]').forEach(function (cb) {
            cb.addEventListener('change', function () {
                updateTrigger();
                updateTags();
            });
        });

        // Close on outside click
        document.addEventListener('click', function (e) {
            if (!wrap.contains(e.target)) closeDropdown();
        });

        // Init
        updateTrigger();
        updateTags();
    }

    function init() {
        document.querySelectorAll('.custom-multiselect').forEach(initMultiSelect);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
