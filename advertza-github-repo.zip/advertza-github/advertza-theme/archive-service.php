<?php
/**
 * Services Archive — Lists all services in card format
 */
get_header();

$services = array(
    array( 'icon'=>'🔍', 'title'=>'Google Ads Management',     'desc'=>'Search, Shopping, PMax, YouTube & Display campaigns that drive profitable conversions at the lowest CPA.',          'href'=>'/services/google-ads',      'slug'=>'google-ads' ),
    array( 'icon'=>'👥', 'title'=>'Meta Ads Management',       'desc'=>'Facebook & Instagram advertising with advanced targeting, creative strategy, and full-funnel ROAS focus.',         'href'=>'/services/meta-ads',        'slug'=>'meta-ads' ),
    array( 'icon'=>'🎬', 'title'=>'TikTok Ads Management',     'desc'=>'Engage new audiences with scroll-stopping creative on the fastest-growing platform for eCommerce brands.',        'href'=>'/services/tiktok-ads',      'slug'=>'tiktok-ads' ),
    array( 'icon'=>'🛍️', 'title'=>'Amazon Ads Management',    'desc'=>'Sponsored Products, Brands & DSP campaigns to dominate marketplace results and increase organic rank.',           'href'=>'/services/amazon-ads',      'slug'=>'amazon-ads' ),
    array( 'icon'=>'📊', 'title'=>'Analytics & CRO',           'desc'=>'Data-driven optimization to increase conversion rates, reduce bounce rates, and maximize your overall ROI.',      'href'=>'/services/analytics',       'slug'=>'analytics' ),
    array( 'icon'=>'✉️', 'title'=>'Email & SMS Marketing',     'desc'=>'Retention marketing flows that turn one-time buyers into loyal, repeat customers with high lifetime value.',      'href'=>'/services/email-marketing', 'slug'=>'email-marketing' ),
    array( 'icon'=>'🛒', 'title'=>'Shopify Marketing',         'desc'=>'Full-service performance marketing for Shopify stores — from traffic acquisition to checkout optimization.',      'href'=>'/services/shopify',         'slug'=>'shopify' ),
    array( 'icon'=>'🔧', 'title'=>'WooCommerce Marketing',     'desc'=>'Growth marketing across all channels for WooCommerce stores, tailored to your product range and audience.',      'href'=>'/services/woocommerce',     'slug'=>'woocommerce' ),
    array( 'icon'=>'🎨', 'title'=>'Creative Services',         'desc'=>'High-converting ad creatives, landing pages, video content, and copy optimized for performance across platforms.','href'=>'/services/creative',        'slug'=>'creative' ),
    array( 'icon'=>'🌟', 'title'=>'Influencer Marketing',      'desc'=>'Authentic influencer partnerships at scale that drive brand awareness, trust, and direct sales.',                 'href'=>'/services/influencer',      'slug'=>'influencer' ),
    array( 'icon'=>'🏪', 'title'=>'Marketplace Advertising',  'desc'=>'Advertising across eBay, Walmart, Etsy, and other marketplaces to expand your revenue channels.',               'href'=>'/services/marketplace-ads', 'slug'=>'marketplace-ads' ),
    array( 'icon'=>'⚡', 'title'=>'BigCommerce Marketing',    'desc'=>'Performance marketing tailored for BigCommerce platforms to accelerate growth at every stage.',                   'href'=>'/services/bigcommerce',     'slug'=>'bigcommerce' ),
    array( 'icon'=>'🔄', 'title'=>'Conversion Rate Optimization','desc'=>'Systematic A/B testing and UX improvements to turn more visitors into buyers without increasing ad spend.',  'href'=>'/services/cro',             'slug'=>'cro' ),
    array( 'icon'=>'💻', 'title'=>'Web Development',      'desc'=>'High-performance websites & eCommerce stores built to rank, load fast, and convert visitors.',           'href'=>'/services/web-development', 'slug'=>'web-development' ),
    array( 'icon'=>'🧲', 'title'=>'Magento Marketing',        'desc'=>'Enterprise-level marketing solutions for Magento stores with complex catalogs and high-volume requirements.',     'href'=>'/services/magento',         'slug'=>'magento' ),
);
?>
<main>
    <!-- Hero -->
    <section style="padding:4rem 0 3rem;background:var(--charcoal);text-align:center;">
        <div class="container">
            <span class="section-label">What We Do</span>
            <h1 style="font-size:clamp(2rem,5vw,3rem);font-weight:800;color:#fff;margin-bottom:1rem;">
                Our <span class="text-gradient-gold">Services</span>
            </h1>
            <p style="color:rgba(255,255,255,0.7);max-width:36rem;margin:0 auto;">
                Full-funnel digital marketing across every major channel — built to drive real revenue growth for eCommerce and D2C brands.
            </p>
        </div>
    </section>

    <!-- Channel Services -->
    <section style="padding:4rem 0;background:var(--surface-warm);">
        <div class="container">
            <div style="margin-bottom:2.5rem;">
                <span class="section-label">Channel Services</span>
                <h2 class="section-title" style="margin-bottom:0.5rem;">Advertising Platforms</h2>
                <p style="color:var(--muted-foreground);">We manage campaigns across every major paid advertising platform.</p>
            </div>
            <div class="services-grid">
                <?php foreach( array_slice($services, 0, 6) as $s ):
                    // Check if a WP page exists with this slug
                    $page = get_page_by_path( 'services/' . $s['slug'] );
                    $url  = $page ? get_permalink($page->ID) : home_url( $s['href'] );
                    // Also check service CPT
                    $cpt  = get_page_by_path( $s['slug'], OBJECT, 'service' );
                    if ($cpt) $url = get_permalink($cpt->ID);
                ?>
                <a href="<?php echo esc_url($url); ?>" class="service-card">
                    <div class="service-icon"><?php echo $s['icon']; ?></div>
                    <h3 class="service-title"><?php echo esc_html($s['title']); ?></h3>
                    <p class="service-desc"><?php echo esc_html($s['desc']); ?></p>
                    <span class="service-link">Learn More →</span>
                </a>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- Platform Services -->
    <section style="padding:4rem 0;">
        <div class="container">
            <div style="margin-bottom:2.5rem;">
                <span class="section-label">Platform Services</span>
                <h2 class="section-title" style="margin-bottom:0.5rem;">eCommerce Platforms</h2>
                <p style="color:var(--muted-foreground);">Platform-specific marketing built for your tech stack.</p>
            </div>
            <div class="services-grid">
                <?php foreach( array_slice($services, 6, 5) as $s ):
                    $page = get_page_by_path( 'services/' . $s['slug'] );
                    $url  = $page ? get_permalink($page->ID) : home_url( $s['href'] );
                    $cpt  = get_page_by_path( $s['slug'], OBJECT, 'service' );
                    if ($cpt) $url = get_permalink($cpt->ID);
                ?>
                <a href="<?php echo esc_url($url); ?>" class="service-card">
                    <div class="service-icon"><?php echo $s['icon']; ?></div>
                    <h3 class="service-title"><?php echo esc_html($s['title']); ?></h3>
                    <p class="service-desc"><?php echo esc_html($s['desc']); ?></p>
                    <span class="service-link">Learn More →</span>
                </a>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- Specialized -->
    <section style="padding:4rem 0;background:var(--surface-warm);">
        <div class="container">
            <div style="margin-bottom:2.5rem;">
                <span class="section-label">Specialized Services</span>
                <h2 class="section-title" style="margin-bottom:0.5rem;">Growth Accelerators</h2>
                <p style="color:var(--muted-foreground);">Specialized services to accelerate every stage of your funnel.</p>
            </div>
            <div class="services-grid">
                <?php foreach( array_slice($services, 11) as $s ):
                    $page = get_page_by_path( 'services/' . $s['slug'] );
                    $url  = $page ? get_permalink($page->ID) : home_url( $s['href'] );
                    $cpt  = get_page_by_path( $s['slug'], OBJECT, 'service' );
                    if ($cpt) $url = get_permalink($cpt->ID);
                ?>
                <a href="<?php echo esc_url($url); ?>" class="service-card">
                    <div class="service-icon"><?php echo $s['icon']; ?></div>
                    <h3 class="service-title"><?php echo esc_html($s['title']); ?></h3>
                    <p class="service-desc"><?php echo esc_html($s['desc']); ?></p>
                    <span class="service-link">Learn More →</span>
                </a>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- CTA -->
    <section class="cta-section">
        <div class="container">
            <div class="cta-inner">
                <h2>Ready to Grow Your Brand?</h2>
                <p>Get a free audit and custom strategy from our certified experts.</p>
                <div class="cta-btns">
                    <a href="<?php echo home_url('/contact'); ?>" class="btn-primary">Get Your Free Audit →</a>
                </div>
            </div>
        </div>
    </section>
</main>
<?php get_footer(); ?>
