<?php
/**
 * Advertza Theme Functions
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ─── Theme Setup ────────────────────────────────────────────────────────────
function advertza_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption' ) );
    add_theme_support( 'custom-logo', array( 'height' => 60, 'width' => 200, 'flex-width' => true ) );

    register_nav_menus( array(
        'primary' => __( 'Primary Menu', 'advertza' ),
        'footer'  => __( 'Footer Menu', 'advertza' ),
    ) );
}
add_action( 'after_setup_theme', 'advertza_setup' );

// ─── Enqueue Scripts & Styles ────────────────────────────────────────────────
function advertza_scripts() {
    wp_enqueue_style( 'advertza-style', get_stylesheet_uri(), array(), '2.0.0' );
    wp_enqueue_script( 'advertza-main', get_template_directory_uri() . '/js/main.js', array(), '2.0.0', true );

    // Pass AJAX URL to JS
    wp_localize_script( 'advertza-main', 'advertza_ajax', array(
        'ajax_url' => admin_url( 'admin-ajax.php' ),
        'nonce'    => wp_create_nonce( 'advertza_nonce' ),
    ) );
}
add_action( 'wp_enqueue_scripts', 'advertza_scripts' );

// ─── Register Custom Post Types ──────────────────────────────────────────────
function advertza_register_post_types() {
    // Services CPT
    register_post_type( 'service', array(
        'labels'      => array(
            'name'          => __( 'Services', 'advertza' ),
            'singular_name' => __( 'Service', 'advertza' ),
            'add_new_item'  => __( 'Add New Service', 'advertza' ),
        ),
        'public'      => true,
        'has_archive' => true,
        'rewrite'     => array( 'slug' => 'services' ),
        'supports'    => array( 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields' ),
        'menu_icon'   => 'dashicons-megaphone',
        'show_in_rest' => true,
    ) );

    // Industry CPT
    register_post_type( 'industry', array(
        'labels'      => array(
            'name'          => __( 'Industries', 'advertza' ),
            'singular_name' => __( 'Industry', 'advertza' ),
            'add_new_item'  => __( 'Add New Industry', 'advertza' ),
        ),
        'public'      => true,
        'has_archive' => true,
        'rewrite'     => array( 'slug' => 'industries' ),
        'supports'    => array( 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields' ),
        'menu_icon'   => 'dashicons-building',
        'show_in_rest' => true,
    ) );

    // Testimonials CPT
    register_post_type( 'testimonial', array(
        'labels'      => array(
            'name'          => __( 'Testimonials', 'advertza' ),
            'singular_name' => __( 'Testimonial', 'advertza' ),
            'add_new_item'  => __( 'Add New Testimonial', 'advertza' ),
        ),
        'public'      => false,
        'show_ui'     => true,
        'supports'    => array( 'title', 'editor', 'custom-fields' ),
        'menu_icon'   => 'dashicons-format-quote',
    ) );
}
add_action( 'init', 'advertza_register_post_types' );

// ─── Register Widgets / Sidebars ─────────────────────────────────────────────
function advertza_widgets_init() {
    register_sidebar( array(
        'name'          => __( 'Blog Sidebar', 'advertza' ),
        'id'            => 'blog-sidebar',
        'before_widget' => '<div class="widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );
}
add_action( 'widgets_init', 'advertza_widgets_init' );

// ─── Theme Options (customizer) ──────────────────────────────────────────────
function advertza_customizer( $wp_customize ) {
    // Contact Info Section
    $wp_customize->add_section( 'advertza_contact', array(
        'title'    => __( 'Contact Info', 'advertza' ),
        'priority' => 30,
    ) );

    $fields = array(
        'phone_india'  => array( 'label' => 'India Phone', 'default' => '+91 97254 87887' ),
        'phone_uk'     => array( 'label' => 'UK Phone',    'default' => '+44 7442 193744' ),
        'email'        => array( 'label' => 'Email',       'default' => 'hello@advertza.com' ),
        'whatsapp'     => array( 'label' => 'WhatsApp Number (digits only)', 'default' => '919725487887' ),
    );

    foreach ( $fields as $key => $data ) {
        $wp_customize->add_setting( 'advertza_' . $key, array( 'default' => $data['default'], 'sanitize_callback' => 'sanitize_text_field' ) );
        $wp_customize->add_control( 'advertza_' . $key, array( 'label' => $data['label'], 'section' => 'advertza_contact', 'type' => 'text' ) );
    }

    // Hero Section
    $wp_customize->add_section( 'advertza_hero', array( 'title' => __( 'Hero Section', 'advertza' ), 'priority' => 25 ) );
    foreach ( array(
        'hero_headline' => array( 'label' => 'Hero Headline', 'default' => 'Scale Your Revenue' ),
        'hero_subline'  => array( 'label' => 'Hero Sub-headline (Gold)', 'default' => 'Not Just Your Ad Spend' ),
        'hero_desc'     => array( 'label' => 'Hero Description', 'default' => 'We help eCommerce and D2C brands generate profitable growth through data-driven advertising across Google, Meta, TikTok, Amazon & more.' ),
    ) as $key => $data ) {
        $wp_customize->add_setting( 'advertza_' . $key, array( 'default' => $data['default'], 'sanitize_callback' => 'sanitize_text_field' ) );
        $wp_customize->add_control( 'advertza_' . $key, array( 'label' => $data['label'], 'section' => 'advertza_hero', 'type' => 'text' ) );
    }
}
add_action( 'customize_register', 'advertza_customizer' );

// ─── Helper: get theme option ─────────────────────────────────────────────────
function advertza_opt( $key, $fallback = '' ) {
    return get_theme_mod( 'advertza_' . $key, $fallback );
}

// ─── Contact Form AJAX Handler ────────────────────────────────────────────────
function advertza_handle_contact() {
    check_ajax_referer( 'advertza_nonce', 'nonce' );

    $name     = sanitize_text_field( $_POST['name'] ?? '' );
    $email    = sanitize_email( $_POST['email'] ?? '' );
    $phone    = sanitize_text_field( $_POST['phone'] ?? '' );
    $website  = esc_url_raw( $_POST['website'] ?? '' );
    $budget   = sanitize_text_field( $_POST['budget'] ?? '' );
    $message  = sanitize_textarea_field( $_POST['message'] ?? '' );
    $services = sanitize_text_field( $_POST['services'] ?? '' );

    if ( empty( $name ) || empty( $email ) ) {
        wp_send_json_error( array( 'message' => 'Name and email are required.' ) );
    }

    $to      = get_option( 'admin_email' );
    $subject = "New Consultation Request from $name - Advertza";
    $body    = "Name: $name\nEmail: $email\nPhone: $phone\nWebsite: $website\nBudget: $budget\nServices Interested: $services\n\nMarketing Goals:\n$message";
    $headers = array( 'Content-Type: text/plain; charset=UTF-8', "Reply-To: $name <$email>" );

    $sent = wp_mail( $to, $subject, $body, $headers );

    // ─── Send to Google Sheets via Apps Script Web App ───────────────────────
    $sheet_webhook = get_option( 'advertza_sheets_webhook', '' );
    if ( ! empty( $sheet_webhook ) ) {
        $sheet_data = array(
            'timestamp' => current_time( 'Y-m-d H:i:s' ),
            'name'      => $name,
            'email'     => $email,
            'phone'     => $phone,
            'website'   => $website,
            'budget'    => $budget,
            'services'  => $services,
            'message'   => $message,
        );
        wp_remote_post( $sheet_webhook, array(
            'timeout'  => 10,
            'blocking' => false,
            'headers'  => array( 'Content-Type' => 'application/json' ),
            'body'     => wp_json_encode( $sheet_data ),
        ) );
    }

    if ( $sent ) {
        wp_send_json_success( array( 'message' => 'Thank you! We will contact you within 24 hours.' ) );
    } else {
        wp_send_json_error( array( 'message' => 'Failed to send. Please email us directly at hello@advertza.com' ) );
    }
}
add_action( 'wp_ajax_advertza_contact',        'advertza_handle_contact' );
add_action( 'wp_ajax_nopriv_advertza_contact', 'advertza_handle_contact' );

// ─── Flush rewrite rules on theme activation ──────────────────────────────────
function advertza_flush_rewrite() {
    advertza_register_post_types();
    flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'advertza_flush_rewrite' );

// Also flush on init if needed (once)
function advertza_maybe_flush() {
    // Version bump forces a rewrite flush when rules change
    $flush_version = '2';
    if ( get_option('advertza_flushed') !== $flush_version ) {
        flush_rewrite_rules();
        update_option('advertza_flushed', $flush_version);
    }
}
add_action('init', 'advertza_maybe_flush', 99);

// ─── Template loader: load single-service / single-industry for pages ─────────
function advertza_page_template_loader( $template ) {
    global $post;
    if ( ! $post ) return $template;

    $uri = trim( $_SERVER['REQUEST_URI'], '/' );

    // /services/{slug} → single-service.php
    if ( preg_match( '#^services/([a-z0-9-]+)/?$#', $uri ) ) {
        $t = locate_template( 'single-service.php' );
        if ( $t ) return $t;
    }
    // /industries/{slug} → single-industry.php
    if ( preg_match( '#^industries/([a-z0-9-]+)/?$#', $uri ) ) {
        $t = locate_template( 'single-industry.php' );
        if ( $t ) return $t;
    }
    return $template;
}
add_filter( 'page_template', 'advertza_page_template_loader' );
add_filter( 'single_template', 'advertza_page_template_loader' );

// ─── Rewrite rules for /services/{slug} and /industries/{slug} pages ──────────
function advertza_add_rewrite_rules() {
    // Services sub-pages
    $services = array('google-ads','meta-ads','tiktok-ads','amazon-ads','analytics','email-marketing','shopify','woocommerce','creative','influencer','marketplace-ads','bigcommerce','cro','magento','web-development');
    foreach ( $services as $s ) {
        add_rewrite_rule( 'services/' . $s . '/?$', 'index.php?pagename=services/' . $s, 'top' );
    }
    // Industries sub-pages
    $industries = array('fashion','beauty','home-garden','electronics','health-wellness','food-beverage','pet-supplies','jewelry','sporting-goods','custom');
    foreach ( $industries as $i ) {
        add_rewrite_rule( 'industries/' . $i . '/?$', 'index.php?pagename=industries/' . $i, 'top' );
    }
}
add_action( 'init', 'advertza_add_rewrite_rules' );

// ─── Excerpt length ───────────────────────────────────────────────────────────
function advertza_excerpt_length( $length ) { return 20; }
add_filter( 'excerpt_length', 'advertza_excerpt_length' );

function advertza_excerpt_more( $more ) { return '…'; }
add_filter( 'excerpt_more', 'advertza_excerpt_more' );

// ─── Clean up WordPress <!--more--> "Continue reading" link text ──────────────
function advertza_more_link_text( $link ) {
    return str_replace( 'Continue reading', 'Read More', $link );
}
add_filter( 'the_content_more_link', 'advertza_more_link_text' );

// ─── Add custom image sizes ───────────────────────────────────────────────────
add_image_size( 'advertza-blog-thumb', 600, 400, true );
add_image_size( 'advertza-service-thumb', 800, 500, true );

// ─── Template redirect: force correct template for child pages ────────────────
function advertza_template_redirect( $template ) {
    if ( ! is_page() ) return $template;

    $slug        = get_post_field( 'post_name', get_the_ID() );
    $parent_id   = wp_get_post_parent_id( get_the_ID() );
    $parent_slug = $parent_id ? get_post_field( 'post_name', $parent_id ) : '';
    $meta_tpl    = get_post_meta( get_the_ID(), '_wp_page_template', true );

    $map = array(
        'about'           => 'page-about.php',
        'contact'         => 'page-contact.php',
        'privacy-policy'  => 'page-privacy-policy.php',
        'terms-of-service'=> 'page-terms-of-service.php',
        'web-development' => 'page-web-development.php',
        'services'        => 'archive-service.php',
        'industries'      => 'archive-industry.php',
        'site-audit'      => 'page-site-audit.php',
        'site-audit-tools'=> 'page-site-audit.php',
        'audit'           => 'page-site-audit.php',
    );

    // Direct slug match
    if ( isset( $map[ $slug ] ) ) {
        $t = locate_template( $map[ $slug ] );
        if ( $t ) return $t;
    }

    // Child of services
    if ( $parent_slug === 'services' || $meta_tpl === 'single-service.php' ) {
        $t = locate_template( 'single-service.php' );
        if ( $t ) return $t;
    }

    // Child of industries
    if ( $parent_slug === 'industries' || $meta_tpl === 'single-industry.php' ) {
        $t = locate_template( 'single-industry.php' );
        if ( $t ) return $t;
    }

    return $template;
}
add_filter( 'page_template', 'advertza_template_redirect', 99 );


// ─── AI Blog Generator (Admin) ───────────────────────────────────────────────
/**
 * AI Blog Generator — WordPress Admin → Posts → AI Blog Generator
 * Enter a topic/keyword → Claude AI writes a full SEO blog post → Publish/Schedule
 */

add_action( 'admin_menu', function() {
    add_submenu_page(
        'edit.php',
        'AI Blog Generator',
        '✨ AI Blog Generator',
        'publish_posts',
        'advertza-ai-blog',
        'advertza_ai_blog_page'
    );
});

function advertza_ai_blog_page() {
    if ( ! current_user_can('publish_posts') ) wp_die('Access denied');
    $categories = get_categories( array('hide_empty' => false, 'orderby' => 'name') );
    $api_key_set = ! empty(get_option('advertza_claude_api_key',''));
    ?>
    <div class="wrap" style="max-width:960px;">
    <h1 style="display:flex;align-items:center;gap:10px;">✨ AI Blog Generator
        <span style="font-size:13px;font-weight:400;background:#f0fdf4;color:#16a34a;border:1px solid #bbf7d0;padding:3px 10px;border-radius:99px;">Powered by Claude AI</span>
    </h1>
    <?php if(!$api_key_set): ?>
    <div class="notice notice-warning"><p>⚠️ Claude API key set nahi hai. <a href="<?php echo admin_url('options-general.php?page=advertza-ai-settings'); ?>"><strong>Settings → Advertza AI Settings</strong></a> mein key daalo pehle.</p></div>
    <?php endif; ?>
    <p style="color:#64748b;margin-top:-4px;">Topic ya keyword dena — AI poora SEO-optimized blog post likhega aur directly WordPress mein save karega.</p>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-top:16px;">

      <div style="background:#fff;border:1px solid #e2e8f0;border-radius:12px;padding:22px;">
        <h2 style="font-size:15px;margin-top:0;margin-bottom:16px;">📝 Blog Settings</h2>
        <table class="form-table" style="margin:0;">
          <tr><th style="width:130px;padding:8px 10px;"><label>Topic / Title</label></th>
              <td style="padding:8px 10px;"><input type="text" id="ai_topic" class="regular-text" style="width:100%;" placeholder="e.g. How to run Google Ads for eCommerce in 2026" /></td></tr>
          <tr><th style="padding:8px 10px;"><label>Focus Keyword</label></th>
              <td style="padding:8px 10px;"><input type="text" id="ai_keyword" class="regular-text" style="width:100%;" placeholder="e.g. google ads ecommerce" /></td></tr>
          <tr><th style="padding:8px 10px;"><label>Tone</label></th>
              <td style="padding:8px 10px;"><select id="ai_tone" style="min-width:200px;">
                <option value="professional and informative">Professional &amp; Informative</option>
                <option value="friendly and conversational">Friendly &amp; Conversational</option>
                <option value="authoritative and expert">Authoritative &amp; Expert</option>
                <option value="casual and engaging">Casual &amp; Engaging</option>
                <option value="persuasive and sales-focused">Persuasive &amp; Sales-focused</option>
              </select></td></tr>
          <tr><th style="padding:8px 10px;"><label>Word Count</label></th>
              <td style="padding:8px 10px;"><select id="ai_length" style="min-width:200px;">
                <option value="600-800">Short (~600-800 words)</option>
                <option value="900-1100" selected>Medium (~900-1100 words)</option>
                <option value="1300-1600">Long (~1300-1600 words)</option>
                <option value="1800-2200">Detailed (~1800-2200 words)</option>
              </select></td></tr>
          <tr><th style="padding:8px 10px;"><label>Category</label></th>
              <td style="padding:8px 10px;"><select id="ai_category" style="min-width:200px;">
                <option value="">— Select Category —</option>
                <?php foreach($categories as $cat): ?>
                  <option value="<?php echo esc_attr($cat->term_id); ?>"><?php echo esc_html($cat->name); ?></option>
                <?php endforeach; ?>
              </select></td></tr>
          <tr><th style="padding:8px 10px;"><label>Tags</label></th>
              <td style="padding:8px 10px;"><input type="text" id="ai_tags" class="regular-text" style="width:100%;" placeholder="tag1, tag2, tag3" /></td></tr>
          <tr><th style="padding:8px 10px;"><label>Publish Status</label></th>
              <td style="padding:8px 10px;"><select id="ai_status" style="min-width:200px;" onchange="document.getElementById('schedule_row').style.display=this.value==='future'?'':'none';">
                <option value="draft">Save as Draft</option>
                <option value="publish">Publish Immediately</option>
                <option value="future">Schedule</option>
              </select></td></tr>
          <tr id="schedule_row" style="display:none;">
              <th style="padding:8px 10px;"><label>Schedule Date/Time</label></th>
              <td style="padding:8px 10px;"><input type="date" id="ai_schedule_date" style="margin-right:8px;" /><input type="time" id="ai_schedule_time" value="09:00" /></td></tr>
          <tr><th style="padding:8px 10px;"><label>Extra Instructions</label></th>
              <td style="padding:8px 10px;"><textarea id="ai_extra" rows="3" style="width:100%;resize:vertical;" placeholder="Optional: Include case study, mention Advertza, add FAQ section, etc."></textarea></td></tr>
        </table>
        <div style="margin-top:14px;display:flex;gap:10px;flex-wrap:wrap;">
          <button id="ai_generate_btn" class="button button-primary" style="height:36px;padding:0 20px;" onclick="advertzaGenerateBlog()">✨ Generate Blog Post</button>
          <button class="button" onclick="advertzaClearAll()" style="height:36px;">🗑 Clear</button>
        </div>
        <div id="ai_status_msg" style="margin-top:10px;display:none;"></div>
      </div>

      <div style="background:#fff;border:1px solid #e2e8f0;border-radius:12px;padding:22px;display:flex;flex-direction:column;">
        <h2 style="font-size:15px;margin-top:0;margin-bottom:16px;">👁 Preview &amp; Edit</h2>
        <div id="ai_loading" style="display:none;text-align:center;padding:40px 0;">
          <div style="width:44px;height:44px;border:4px solid #e2e8f0;border-top-color:#b45309;border-radius:50%;margin:0 auto 10px;animation:adspin .8s linear infinite;"></div>
          <p id="ai_loading_msg" style="color:#64748b;font-size:14px;">Generating…</p>
        </div>
        <div id="ai_preview_wrap" style="flex:1;display:flex;flex-direction:column;gap:10px;">
          <div><label style="font-size:11px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.05em;">Generated Title</label>
               <input type="text" id="ai_gen_title" style="width:100%;margin-top:4px;padding:7px 10px;border:1.5px solid #e2e8f0;border-radius:6px;font-size:14px;font-weight:600;box-sizing:border-box;" placeholder="Title will appear here…" /></div>
          <div><label style="font-size:11px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.05em;">Meta Description</label>
               <textarea id="ai_gen_meta" rows="2" style="width:100%;margin-top:4px;padding:7px 10px;border:1.5px solid #e2e8f0;border-radius:6px;font-size:12px;resize:vertical;box-sizing:border-box;" placeholder="Meta description…"></textarea></div>
          <div style="flex:1;"><label style="font-size:11px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.05em;">Blog Content (HTML — editable)</label>
               <textarea id="ai_gen_content" rows="15" style="width:100%;margin-top:4px;padding:7px 10px;border:1.5px solid #e2e8f0;border-radius:6px;font-size:12px;font-family:monospace;resize:vertical;box-sizing:border-box;" placeholder="Generated content will appear here. You can edit before saving…"></textarea></div>
          <div style="display:flex;gap:10px;flex-wrap:wrap;">
            <button id="ai_save_btn" class="button button-primary" style="height:36px;padding:0 18px;" onclick="advertzaSaveBlog()" disabled>💾 Save to WordPress</button>
            <button class="button" onclick="advertzaPreviewHtml()" id="ai_preview_btn" style="height:36px;" disabled>👁 Preview</button>
          </div>
          <div id="ai_save_msg" style="display:none;"></div>
        </div>
      </div>
    </div>

    <div style="background:#fff;border:1px solid #e2e8f0;border-radius:12px;padding:22px;margin-top:20px;">
      <h2 style="font-size:15px;margin-top:0;">🚀 Bulk AI Blog Generator</h2>
      <p style="color:#64748b;font-size:13px;margin-top:-4px;">Multiple topics ek saath generate karo — ek line mein ek topic.</p>
      <textarea id="bulk_topics" rows="5" style="width:100%;padding:10px;border:1.5px solid #e2e8f0;border-radius:6px;font-size:13px;resize:vertical;box-sizing:border-box;" placeholder="How to scale Google Ads for eCommerce&#10;Best Meta Ads strategies for D2C brands&#10;TikTok Ads vs Instagram Ads: Which is better?&#10;Email marketing automation guide for Shopify"></textarea>
      <div style="margin-top:10px;display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
        <select id="bulk_status" style="height:32px;"><option value="draft">Save all as Draft</option><option value="publish">Publish all immediately</option></select>
        <button class="button button-primary" style="height:36px;padding:0 18px;" onclick="advertzaBulkGenerate()">⚡ Generate All</button>
        <span id="bulk_progress" style="font-size:13px;color:#64748b;"></span>
      </div>
      <div id="bulk_results" style="margin-top:10px;"></div>
    </div>
    </div>

    <style>@keyframes adspin{to{transform:rotate(360deg)}}</style>
    <script>
    const wpAjaxUrl = '<?php echo esc_js(admin_url("admin-ajax.php")); ?>';
    const wpNonce   = '<?php echo esc_js(wp_create_nonce("advertza_ai_blog_nonce")); ?>';
    const loadMsgs  = ['AI research kar raha hai…','SEO structure bana raha hai…','Headings likh raha hai…','Content polish ho raha hai…','Meta description ban raha hai…','Final touches…'];

    function showMsg(el,msg,type){const c={success:'#f0fdf4|#16a34a|#bbf7d0',error:'#fef2f2|#dc2626|#fecaca',info:'#eff6ff|#2563eb|#bfdbfe'};const[bg,color,border]=(c[type]||c.info).split('|');el.style.cssText='display:block;padding:9px 13px;border-radius:8px;font-size:13px;background:'+bg+';color:'+color+';border:1px solid '+border+';';el.innerHTML=msg;}

    async function advertzaGenerateBlog(){
      const topic=document.getElementById('ai_topic').value.trim();
      if(!topic){alert('Pehle topic/title daalo.');return;}
      const keyword=document.getElementById('ai_keyword').value.trim();
      const tone=document.getElementById('ai_tone').value;
      const length=document.getElementById('ai_length').value;
      const extra=document.getElementById('ai_extra').value.trim();
      const btn=document.getElementById('ai_generate_btn');
      btn.disabled=true;
      document.getElementById('ai_loading').style.display='block';
      document.getElementById('ai_save_btn').disabled=true;
      document.getElementById('ai_preview_btn').disabled=true;
      document.getElementById('ai_status_msg').style.display='none';
      let mi=0;const mel=document.getElementById('ai_loading_msg');
      const mt=setInterval(()=>{mel.textContent=loadMsgs[mi%loadMsgs.length];mi++;},2500);
      const prompt='You are an expert SEO content writer for a digital marketing agency called Advertza.\n\nTopic: '+topic+'\n'+(keyword?'Focus Keyword: '+keyword+'\n':'')+'Tone: '+tone+'\nTarget word count: '+length+' words\n'+(extra?'Extra instructions: '+extra+'\n':'')+'\nRequirements:\n- Write a compelling SEO title (include focus keyword)\n- Use proper HTML: h2, h3, p, ul, ol, li, strong, em tags ONLY\n- Engaging intro, clear subheadings, actionable content, strong CTA mentioning Advertza\n- Sound human, not robotic\n- Naturally include focus keyword in title, intro, 2+ headings, conclusion\n\nReturn ONLY JSON (no markdown fences):\n{"title":"...","meta_description":"150-160 char description with keyword","content":"...HTML content..."}';
      try{
        const fd=new FormData();fd.append('action','advertza_ai_generate_blog');fd.append('nonce',wpNonce);fd.append('prompt',prompt);
        const res=await fetch(wpAjaxUrl,{method:'POST',body:fd});
        const data=await res.json();
        if(data.success&&data.data){
          document.getElementById('ai_gen_title').value=data.data.title||'';
          document.getElementById('ai_gen_meta').value=data.data.meta_description||'';
          document.getElementById('ai_gen_content').value=data.data.content||'';
          document.getElementById('ai_save_btn').disabled=false;
          document.getElementById('ai_preview_btn').disabled=false;
          showMsg(document.getElementById('ai_status_msg'),'✅ Blog post generate ho gaya! Edit karo aur save karo.','success');
        }else{showMsg(document.getElementById('ai_status_msg'),'❌ Error: '+(data.data||'Generation failed.'),'error');}
      }catch(e){showMsg(document.getElementById('ai_status_msg'),'❌ Network error. Please try again.','error');console.error(e);}
      finally{clearInterval(mt);document.getElementById('ai_loading').style.display='none';btn.disabled=false;}
    }

    async function advertzaSaveBlog(){
      const title=document.getElementById('ai_gen_title').value.trim();
      const content=document.getElementById('ai_gen_content').value.trim();
      if(!title||!content){alert('Title aur content chahiye.');return;}
      const btn=document.getElementById('ai_save_btn');btn.disabled=true;btn.textContent='Saving…';
      const fd=new FormData();
      fd.append('action','advertza_ai_save_blog');fd.append('nonce',wpNonce);
      fd.append('title',title);fd.append('content',content);
      fd.append('meta_description',document.getElementById('ai_gen_meta').value.trim());
      fd.append('status',document.getElementById('ai_status').value);
      fd.append('category',document.getElementById('ai_category').value);
      fd.append('tags',document.getElementById('ai_tags').value.trim());
      fd.append('schedule_date',document.getElementById('ai_schedule_date').value);
      fd.append('schedule_time',document.getElementById('ai_schedule_time').value);
      try{
        const res=await fetch(wpAjaxUrl,{method:'POST',body:fd});const data=await res.json();
        const msgEl=document.getElementById('ai_save_msg');
        if(data.success){showMsg(msgEl,'✅ '+data.data.message+' <a href="'+data.data.edit_url+'" target="_blank" style="font-weight:700;">Edit Post →</a> | <a href="'+data.data.view_url+'" target="_blank" style="font-weight:700;">View →</a>','success');}
        else{showMsg(msgEl,'❌ '+(data.data||'Save failed.'),'error');btn.disabled=false;btn.textContent='💾 Save to WordPress';}
      }catch(e){showMsg(document.getElementById('ai_save_msg'),'❌ Network error.','error');btn.disabled=false;btn.textContent='💾 Save to WordPress';}
    }

    function advertzaPreviewHtml(){
      const w=window.open('','_blank');
      w.document.write('<html><head><title>Preview</title><style>body{font-family:sans-serif;max-width:780px;margin:40px auto;padding:0 20px;line-height:1.75;color:#1e293b;}h2{color:#0f172a;margin-top:2rem;}h3{color:#334155;}ul,ol{padding-left:1.5rem;margin-bottom:1rem;}</style></head><body>');
      w.document.write('<h1>'+document.getElementById('ai_gen_title').value+'</h1>');
      w.document.write(document.getElementById('ai_gen_content').value);
      w.document.write('</body></html>');w.document.close();
    }

    function advertzaClearAll(){
      ['ai_topic','ai_keyword','ai_extra','ai_gen_title','ai_gen_meta','ai_gen_content','ai_tags'].forEach(id=>document.getElementById(id).value='');
      ['ai_status_msg','ai_save_msg'].forEach(id=>document.getElementById(id).style.display='none');
      document.getElementById('ai_save_btn').disabled=true;document.getElementById('ai_preview_btn').disabled=true;
    }

    async function advertzaBulkGenerate(){
      const topics=document.getElementById('bulk_topics').value.trim().split('\n').map(t=>t.trim()).filter(t=>t.length>3);
      if(!topics.length){alert('Pehle topics likho.');return;}
      const bulkStatus=document.getElementById('bulk_status').value;
      const progEl=document.getElementById('bulk_progress');const resEl=document.getElementById('bulk_results');resEl.innerHTML='';
      for(let i=0;i<topics.length;i++){
        progEl.textContent='Generating '+(i+1)+'/'+topics.length+': "'+topics[i]+'"…';
        const prompt='Write a complete SEO-optimized blog post for Advertza (digital marketing agency).\nTopic: '+topics[i]+'\nTone: professional\nTarget: 800-1000 words\nUse HTML (h2,h3,p,ul,li,strong,em only). Include intro, subheadings, actionable tips, CTA mentioning Advertza.\nReturn ONLY JSON: {"title":"...","meta_description":"...","content":"...HTML..."}';
        try{
          const fd=new FormData();fd.append('action','advertza_ai_generate_blog');fd.append('nonce',wpNonce);fd.append('prompt',prompt);
          const res=await fetch(wpAjaxUrl,{method:'POST',body:fd});const genData=await res.json();
          if(genData.success&&genData.data){
            const sfd=new FormData();sfd.append('action','advertza_ai_save_blog');sfd.append('nonce',wpNonce);
            sfd.append('title',genData.data.title);sfd.append('content',genData.data.content);
            sfd.append('meta_description',genData.data.meta_description||'');sfd.append('status',bulkStatus);
            sfd.append('category','');sfd.append('tags','');
            const sres=await fetch(wpAjaxUrl,{method:'POST',body:sfd});const sData=await sres.json();
            if(sData.success){resEl.innerHTML+='<div style="padding:7px 12px;background:#f0fdf4;border:1px solid #bbf7d0;border-radius:6px;margin-bottom:6px;font-size:13px;">✅ <strong>'+genData.data.title+'</strong> — <a href="'+sData.data.edit_url+'" target="_blank">Edit</a> | <a href="'+sData.data.view_url+'" target="_blank">View</a></div>';}
            else{resEl.innerHTML+='<div style="padding:7px 12px;background:#fef2f2;border:1px solid #fecaca;border-radius:6px;margin-bottom:6px;font-size:13px;">❌ Save failed: '+topics[i]+'</div>';}
          }else{resEl.innerHTML+='<div style="padding:7px 12px;background:#fef2f2;border:1px solid #fecaca;border-radius:6px;margin-bottom:6px;font-size:13px;">❌ Generation failed: '+topics[i]+'</div>';}
        }catch(e){resEl.innerHTML+='<div style="padding:7px 12px;background:#fef2f2;border:1px solid #fecaca;border-radius:6px;margin-bottom:6px;font-size:13px;">❌ Error: '+topics[i]+'</div>';}
        if(i<topics.length-1)await new Promise(r=>setTimeout(r,1500));
      }
      progEl.textContent='✅ Done! '+topics.length+' posts processed.';
    }
    </script>
    <?php
}

// ── AJAX: Generate Blog via Claude AI ────────────────────────────────────────
add_action( 'wp_ajax_advertza_ai_generate_blog', 'advertza_ajax_generate_blog' );
function advertza_ajax_generate_blog() {
    check_ajax_referer( 'advertza_ai_blog_nonce', 'nonce' );
    if ( ! current_user_can('publish_posts') ) wp_send_json_error('Access denied');

    $prompt = sanitize_textarea_field( $_POST['prompt'] ?? '' );
    if ( empty($prompt) ) wp_send_json_error('No prompt provided');

    $api_key = get_option('advertza_claude_api_key', '');
    if ( empty($api_key) ) {
        wp_send_json_error('Claude API key not set. Go to Settings → Advertza AI Settings.');
    }

    $body = wp_json_encode( array(
        'model'      => 'claude-sonnet-4-20250514',
        'max_tokens' => 4096,
        'messages'   => array( array( 'role' => 'user', 'content' => $prompt ) ),
    ));

    $response = wp_remote_post( 'https://api.anthropic.com/v1/messages', array(
        'timeout' => 90,
        'headers' => array(
            'Content-Type'      => 'application/json',
            'x-api-key'         => $api_key,
            'anthropic-version' => '2023-06-01',
        ),
        'body' => $body,
    ));

    if ( is_wp_error($response) ) wp_send_json_error('API request failed: ' . $response->get_error_message());

    $code = wp_remote_retrieve_response_code($response);
    $raw  = wp_remote_retrieve_body($response);
    $data = json_decode( $raw, true );

    if ( $code !== 200 ) {
        $err = $data['error']['message'] ?? 'API error (code ' . $code . ')';
        wp_send_json_error($err);
    }

    $text = '';
    foreach ( ($data['content'] ?? []) as $block ) {
        if ( ($block['type'] ?? '') === 'text' ) $text .= $block['text'];
    }
    $text   = preg_replace('/^```json\s*|\s*```$/s', '', trim($text));
    $parsed = json_decode($text, true);

    if ( ! $parsed || empty($parsed['title']) || empty($parsed['content']) ) {
        wp_send_json_error('AI returned invalid response. Please try again.');
    }

    wp_send_json_success($parsed);
}

// ── AJAX: Save Generated Blog Post ───────────────────────────────────────────
add_action( 'wp_ajax_advertza_ai_save_blog', 'advertza_ajax_save_blog' );
function advertza_ajax_save_blog() {
    check_ajax_referer( 'advertza_ai_blog_nonce', 'nonce' );
    if ( ! current_user_can('publish_posts') ) wp_send_json_error('Access denied');

    $title    = sanitize_text_field( $_POST['title'] ?? '' );
    $content  = wp_kses_post( $_POST['content'] ?? '' );
    $meta     = sanitize_text_field( $_POST['meta_description'] ?? '' );
    $status   = sanitize_text_field( $_POST['status'] ?? 'draft' );
    $cat_id   = intval( $_POST['category'] ?? 0 );
    $tags_str = sanitize_text_field( $_POST['tags'] ?? '' );
    $sch_date = sanitize_text_field( $_POST['schedule_date'] ?? '' );
    $sch_time = sanitize_text_field( $_POST['schedule_time'] ?? '09:00' );

    if ( empty($title) || empty($content) ) wp_send_json_error('Title and content required.');

    $post_arr = array(
        'post_title'    => $title,
        'post_content'  => $content,
        'post_status'   => in_array($status, ['draft','publish','future']) ? $status : 'draft',
        'post_author'   => get_current_user_id(),
        'post_category' => $cat_id ? array($cat_id) : array(),
    );

    if ( $status === 'future' && $sch_date ) {
        $tz = new DateTimeZone( get_option('timezone_string') ?: 'UTC' );
        try {
            $dt = new DateTime( $sch_date . ' ' . $sch_time, $tz );
            $post_arr['post_date'] = $dt->format('Y-m-d H:i:s');
            $dt->setTimezone( new DateTimeZone('UTC') );
            $post_arr['post_date_gmt'] = $dt->format('Y-m-d H:i:s');
        } catch(Exception $e) { $post_arr['post_status'] = 'draft'; }
    }

    $post_id = wp_insert_post($post_arr, true);
    if ( is_wp_error($post_id) ) wp_send_json_error($post_id->get_error_message());

    if ($tags_str) wp_set_post_tags($post_id, explode(',', $tags_str));
    if ($meta) {
        update_post_meta($post_id, '_yoast_wpseo_metadesc', $meta);
        update_post_meta($post_id, 'rank_math_description', $meta);
        update_post_meta($post_id, '_advertza_meta_desc', $meta);
    }

    $label = $status === 'draft' ? 'Draft saved' : ($status === 'future' ? 'Post scheduled' : 'Post published');
    wp_send_json_success( array(
        'message'  => $label . ' successfully!',
        'post_id'  => $post_id,
        'edit_url' => get_edit_post_link($post_id, 'raw'),
        'view_url' => get_permalink($post_id),
    ));
}

// ── Settings: Claude API Key ──────────────────────────────────────────────────
add_action( 'admin_menu', function() {
    add_options_page(
        'Advertza AI Settings', '✨ Advertza AI Settings', 'manage_options',
        'advertza-ai-settings', 'advertza_ai_settings_page'
    );
});
add_action( 'admin_init', function() {
    register_setting( 'advertza_ai_options', 'advertza_claude_api_key',
        array('sanitize_callback' => 'sanitize_text_field') );
});
function advertza_ai_settings_page() {
    if ( ! current_user_can('manage_options') ) wp_die('Access denied');
    $saved = get_option('advertza_claude_api_key', '');
    ?>
    <div class="wrap" style="max-width:600px;">
    <h1>✨ Advertza AI Settings</h1>
    <p style="color:#64748b;">AI Blog Generator ke liye Claude API key yahan daalo.</p>
    <form method="post" action="options.php">
        <?php settings_fields('advertza_ai_options'); ?>
        <table class="form-table">
          <tr><th><label for="advertza_claude_api_key">Claude API Key</label></th>
              <td><input type="password" id="advertza_claude_api_key" name="advertza_claude_api_key"
                         value="<?php echo esc_attr($saved); ?>" class="regular-text" style="width:100%;"
                         placeholder="sk-ant-api03-…" autocomplete="new-password" />
                   <p class="description">Anthropic Console se key lo: <a href="https://console.anthropic.com/settings/keys" target="_blank">console.anthropic.com/settings/keys</a></p>
                   <?php if($saved): ?><p style="color:#16a34a;font-weight:600;margin-top:4px;">✅ API key saved hai.</p><?php endif; ?>
              </td></tr>
        </table>
        <?php submit_button('Save API Key'); ?>
    </form>
    <hr>
    <h3>API Key kahan se milegi?</h3>
    <ol style="line-height:2.2;">
      <li><a href="https://console.anthropic.com" target="_blank">console.anthropic.com</a> pe account banao</li>
      <li>Settings → API Keys → Create Key</li>
      <li>Key copy karo aur upar paste karo → Save</li>
      <li>Ab Posts → ✨ AI Blog Generator use kar sakte ho!</li>
    </ol>
    </div>
    <?php
}

// ─── Blog Auto-Scheduler (CSV Upload via Admin) ──────────────────────────────
/**
 * Blog Schedule Format (CSV):
 * title, content, category, tags, featured_image_url, publish_date, publish_time
 *
 * Example row:
 * "5 Ways to Scale Your eCommerce","Full blog content here...","Marketing","seo,growth","https://example.com/img.jpg","2026-04-15","09:00"
 *
 * Upload CSV from: WordPress Admin → Tools → Blog Scheduler
 */

// Admin Menu
add_action( 'admin_menu', function() {
    add_management_page(
        'Blog Scheduler',
        'Blog Scheduler',
        'publish_posts',
        'advertza-blog-scheduler',
        'advertza_blog_scheduler_page'
    );
});

// Admin Page UI
function advertza_blog_scheduler_page() {
    if ( ! current_user_can('publish_posts') ) wp_die('Access denied');

    $msg = '';
    if ( isset($_POST['advertza_schedule_nonce']) && wp_verify_nonce($_POST['advertza_schedule_nonce'], 'advertza_schedule') ) {
        if ( ! empty($_FILES['blog_csv']['tmp_name']) ) {
            $result = advertza_process_blog_csv( $_FILES['blog_csv']['tmp_name'] );
            $msg = '<div class="notice notice-success"><p>' . esc_html($result) . '</p></div>';
        }
    }

    echo '<div class="wrap">';
    echo '<h1>📅 Blog Auto-Scheduler</h1>';
    echo $msg;
    echo '
    <p>Upload a CSV file to automatically schedule multiple blog posts.</p>
    <h3>CSV Format (columns in order):</h3>
    <table class="widefat" style="max-width:700px;margin-bottom:1.5rem;">
    <thead><tr><th>Column</th><th>Example</th><th>Notes</th></tr></thead>
    <tbody>
    <tr><td><b>title</b></td><td>5 Ways to Scale Your Brand</td><td>Blog post title</td></tr>
    <tr><td><b>content</b></td><td>Your full blog content here...</td><td>Supports HTML</td></tr>
    <tr><td><b>excerpt</b></td><td>Short summary of the post</td><td>Optional (leave blank)</td></tr>
    <tr><td><b>category</b></td><td>Marketing</td><td>Category name (created if not exists)</td></tr>
    <tr><td><b>tags</b></td><td>seo,growth,ads</td><td>Comma separated tags</td></tr>
    <tr><td><b>featured_image_url</b></td><td>https://site.com/img.jpg</td><td>Optional image URL</td></tr>
    <tr><td><b>publish_date</b></td><td>2026-04-15</td><td>YYYY-MM-DD format</td></tr>
    <tr><td><b>publish_time</b></td><td>09:00</td><td>HH:MM (24hr, site timezone)</td></tr>
    </tbody>
    </table>

    <form method="post" enctype="multipart/form-data" style="max-width:500px;">
        ' . wp_nonce_field('advertza_schedule', 'advertza_schedule_nonce', true, false) . '
        <table class="form-table">
        <tr><th><label for="blog_csv">Select CSV File</label></th>
        <td><input type="file" name="blog_csv" id="blog_csv" accept=".csv" required></td></tr>
        </table>
        <p class="submit"><input type="submit" class="button button-primary" value="📤 Upload & Schedule Posts"></p>
    </form>

    <h3>Download Sample CSV</h3>
    <a href="' . esc_url( add_query_arg('advertza_sample_csv', '1') ) . '" class="button">⬇ Download Sample CSV</a>
    </div>';

    // Sample CSV download
    if ( isset($_GET['advertza_sample_csv']) ) {
        advertza_download_sample_csv();
    }
}

// Process uploaded CSV
function advertza_process_blog_csv( $tmp_file ) {
    $handle = fopen( $tmp_file, 'r' );
    if ( ! $handle ) return 'Error: Could not read CSV file.';

    $scheduled = 0;
    $skipped   = 0;
    $row_num   = 0;

    while ( ( $row = fgetcsv($handle) ) !== false ) {
        $row_num++;
        if ( $row_num === 1 && strtolower(trim($row[0])) === 'title' ) continue; // skip header

        if ( count($row) < 8 ) { $skipped++; continue; }

        list( $title, $content, $excerpt, $category, $tags, $img_url, $pub_date, $pub_time ) = $row;

        $title   = sanitize_text_field( trim($title) );
        $content = wp_kses_post( trim($content) );
        $excerpt = sanitize_text_field( trim($excerpt) );

        if ( empty($title) || empty($pub_date) ) { $skipped++; continue; }

        // Build scheduled datetime (site timezone)
        $pub_time  = empty(trim($pub_time)) ? '08:00' : trim($pub_time);
        $tz_string = get_option('timezone_string') ?: 'UTC';
        $tz        = new DateTimeZone( $tz_string );
        try {
            $dt = new DateTime( $pub_date . ' ' . $pub_time, $tz );
        } catch(Exception $e) {
            $skipped++; continue;
        }
        $post_date     = $dt->format('Y-m-d H:i:s');
        $dt->setTimezone( new DateTimeZone('UTC') );
        $post_date_gmt = $dt->format('Y-m-d H:i:s');

        // Category
        $cat_id = 0;
        $cat_name = sanitize_text_field( trim($category) );
        if ( $cat_name ) {
            $cat = get_term_by('name', $cat_name, 'category');
            if ( $cat ) {
                $cat_id = $cat->term_id;
            } else {
                $new_cat = wp_insert_term( $cat_name, 'category' );
                $cat_id  = is_wp_error($new_cat) ? 0 : $new_cat['term_id'];
            }
        }

        // Insert post
        $post_arr = array(
            'post_title'    => $title,
            'post_content'  => $content,
            'post_excerpt'  => $excerpt,
            'post_status'   => 'future',
            'post_date'     => $post_date,
            'post_date_gmt' => $post_date_gmt,
            'post_category' => $cat_id ? array($cat_id) : array(),
            'post_author'   => get_current_user_id(),
        );
        $post_id = wp_insert_post( $post_arr, true );
        if ( is_wp_error($post_id) ) { $skipped++; continue; }

        // Tags
        $tags_str = sanitize_text_field( trim($tags) );
        if ( $tags_str ) {
            wp_set_post_tags( $post_id, explode(',', $tags_str) );
        }

        // Featured image from URL
        $img_url = trim($img_url);
        if ( $img_url && filter_var($img_url, FILTER_VALIDATE_URL) ) {
            advertza_sideload_image( $img_url, $post_id );
        }

        $scheduled++;
    }
    fclose($handle);

    return "Done! Scheduled: {$scheduled} posts. Skipped: {$skipped} rows.";
}

// Sideload image from URL
function advertza_sideload_image( $url, $post_id ) {
    require_once ABSPATH . 'wp-admin/includes/media.php';
    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/image.php';
    $attach_id = media_sideload_image( $url, $post_id, null, 'id' );
    if ( ! is_wp_error($attach_id) ) {
        set_post_thumbnail( $post_id, $attach_id );
    }
}

// Sample CSV download
function advertza_download_sample_csv() {
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="blog-schedule-sample.csv"');
    $out = fopen('php://output', 'w');
    fputcsv($out, array('title','content','excerpt','category','tags','featured_image_url','publish_date','publish_time'));
    fputcsv($out, array(
        '5 Ways to Scale Your eCommerce Brand in 2026',
        '<p>Your full blog content here. You can use HTML tags.</p><p>Add as many paragraphs as needed.</p>',
        'Discover the top 5 proven strategies to scale your eCommerce brand this year.',
        'Marketing',
        'ecommerce,growth,strategy',
        'https://your-site.com/wp-content/uploads/blog-image.jpg',
        date('Y-m-d', strtotime('+7 days')),
        '09:00'
    ));
    fputcsv($out, array(
        'Meta Ads vs Google Ads: Which Drives Better ROI?',
        '<p>When choosing between Meta and Google ads, the answer depends on your business goals...</p>',
        'A deep dive into Meta Ads vs Google Ads performance for eCommerce brands.',
        'Advertising',
        'meta ads,google ads,roi,paid ads',
        '',
        date('Y-m-d', strtotime('+14 days')),
        '10:00'
    ));
    fclose($out);
    exit;
}


// ─── Auto-Create Blog Categories (matching Services) ─────────────────────────
/**
 * Creates blog categories automatically on theme activation / init.
 * Categories match Advertza's service offerings.
 */
function advertza_create_blog_categories() {
    $categories = array(
        // Service-based
        'Google Ads',
        'Meta Ads',
        'TikTok Ads',
        'Amazon Ads',
        'Shopify Marketing',
        'Email Marketing',
        'Web Development',
        // Topic-based
        'eCommerce Strategy',
        'Performance Marketing',
        'SEO & Content',
        'Social Media',
        'Case Studies',
        'Industry News',
        'Marketing Tips',
        // Others
        'Uncategorized',
    );

    foreach ( $categories as $cat_name ) {
        if ( ! term_exists( $cat_name, 'category' ) ) {
            wp_insert_term( $cat_name, 'category' );
        }
    }
}
add_action( 'after_switch_theme', 'advertza_create_blog_categories' );
// Also run once on init if categories don't exist yet
add_action( 'init', function() {
    if ( ! get_option('advertza_cats_created') ) {
        advertza_create_blog_categories();
        update_option( 'advertza_cats_created', '1' );
    }
});

// ─── Admin Settings Page — Google Sheets Webhook ─────────────────────────────
function advertza_admin_menu() {
    add_options_page(
        'Advertza Settings',
        'Advertza Settings',
        'manage_options',
        'advertza-settings',
        'advertza_settings_page'
    );
}
add_action( 'admin_menu', 'advertza_admin_menu' );

function advertza_settings_page() {
    if ( isset( $_POST['advertza_save_settings'] ) && check_admin_referer( 'advertza_settings_save' ) ) {
        update_option( 'advertza_sheets_webhook', esc_url_raw( $_POST['sheets_webhook'] ?? '' ) );
        echo '<div class="notice notice-success"><p>Settings saved!</p></div>';
    }
    $webhook = get_option( 'advertza_sheets_webhook', '' );
    ?>
    <div class="wrap">
        <h1>Advertza Settings</h1>
        <form method="post">
            <?php wp_nonce_field( 'advertza_settings_save' ); ?>
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="sheets_webhook">Google Sheets Webhook URL</label></th>
                    <td>
                        <input type="url" id="sheets_webhook" name="sheets_webhook"
                               value="<?php echo esc_attr( $webhook ); ?>"
                               class="regular-text" placeholder="https://script.google.com/macros/s/..." />
                        <p class="description">
                            Paste your Google Apps Script Web App URL here.<br>
                            <strong>How to set up:</strong> See the <code>google-apps-script.js</code> file included in the theme — copy that code into Google Apps Script, deploy as Web App, paste the URL above.
                        </p>
                    </td>
                </tr>
            </table>
            <p><input type="submit" name="advertza_save_settings" class="button button-primary" value="Save Settings"></p>
        </form>
    </div>
    <?php
}

