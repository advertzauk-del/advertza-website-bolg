<?php
// Social media URLs from customizer
$socials = array(
    'facebook'  => array( 'url' => get_theme_mod('advertza_social_facebook',  'https://facebook.com/'), 'label' => 'Facebook',  'svg' => '<svg viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>' ),
    'instagram' => array( 'url' => get_theme_mod('advertza_social_instagram', 'https://instagram.com/'), 'label' => 'Instagram', 'svg' => '<svg viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>' ),
    'linkedin'  => array( 'url' => get_theme_mod('advertza_social_linkedin',  'https://linkedin.com/'),  'label' => 'LinkedIn',  'svg' => '<svg viewBox="0 0 24 24"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>' ),
    'twitter'   => array( 'url' => get_theme_mod('advertza_social_twitter',   'https://twitter.com/'),   'label' => 'Twitter/X', 'svg' => '<svg viewBox="0 0 24 24"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-4.714-6.231-5.401 6.231H2.744l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>' ),
    'youtube'   => array( 'url' => get_theme_mod('advertza_social_youtube',   ''),                        'label' => 'YouTube',   'svg' => '<svg viewBox="0 0 24 24"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>' ),
    'tiktok'    => array( 'url' => get_theme_mod('advertza_social_tiktok',    ''),                        'label' => 'TikTok',    'svg' => '<svg viewBox="0 0 24 24"><path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.15 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z"/></svg>' ),
);
?>
<!-- ============================
     FOOTER
     ============================ -->
<footer id="site-footer">
    <div class="container">
        <div class="footer-grid">
            <!-- Brand -->
            <div class="footer-brand">
                <?php if ( has_custom_logo() ) {
                    $logo_id  = get_theme_mod('custom_logo');
                    $logo_url = wp_get_attachment_image_url($logo_id, 'full');
                    echo '<img src="' . esc_url($logo_url) . '" alt="' . get_bloginfo('name') . '" style="height:2.5rem;width:auto;margin-bottom:1rem;">';
                } else { ?>
                    <span style="font-family:'Plus Jakarta Sans',sans-serif;font-size:1.5rem;font-weight:800;color:var(--gold);">Advertza</span>
                <?php } ?>
                <p style="margin-top:0.75rem;font-size:0.85rem;line-height:1.7;color:rgba(255,255,255,0.6);">
                    Performance-driven digital marketing agency helping brands scale profitably across Google, Meta, TikTok, Amazon &amp; more.
                </p>

                <!-- Social icons -->
                <div class="footer-social" style="margin-top:1.25rem;">
                    <?php foreach($socials as $key => $s):
                        if ( empty($s['url']) ) continue; ?>
                    <a href="<?php echo esc_url($s['url']); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php echo esc_attr($s['label']); ?>">
                        <?php echo $s['svg']; ?>
                    </a>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Services -->
            <div class="footer-col">
                <h4>Services</h4>
                <ul>
                    <li><a href="<?php echo home_url('/services/google-ads'); ?>">Google Ads</a></li>
                    <li><a href="<?php echo home_url('/services/meta-ads'); ?>">Meta Ads</a></li>
                    <li><a href="<?php echo home_url('/services/tiktok-ads'); ?>">TikTok Ads</a></li>
                    <li><a href="<?php echo home_url('/services/amazon-ads'); ?>">Amazon Ads</a></li>
                    <li><a href="<?php echo home_url('/services/shopify'); ?>">Shopify Marketing</a></li>
                    <li><a href="<?php echo home_url('/services/email-marketing'); ?>">Email Marketing</a></li>
                    <li><a href="<?php echo home_url('/services/web-development'); ?>">Web Development</a></li>
                </ul>
            </div>

            <!-- Industries -->
            <div class="footer-col">
                <h4>Industries</h4>
                <ul>
                    <li><a href="<?php echo home_url('/industries/fashion'); ?>">Fashion &amp; Apparel</a></li>
                    <li><a href="<?php echo home_url('/industries/beauty'); ?>">Beauty &amp; Cosmetics</a></li>
                    <li><a href="<?php echo home_url('/industries/health-wellness'); ?>">Health &amp; Wellness</a></li>
                    <li><a href="<?php echo home_url('/industries/electronics'); ?>">Electronics &amp; Tech</a></li>
                    <li><a href="<?php echo home_url('/industries'); ?>">All Industries</a></li>
                </ul>
            </div>

            <!-- Company -->
            <div class="footer-col">
                <h4>Company</h4>
                <ul>
                    <li><a href="<?php echo home_url('/about'); ?>">About Us</a></li>
                    <li><a href="<?php echo home_url('/contact'); ?>">Contact</a></li>
                    <li><a href="<?php echo home_url('/privacy-policy'); ?>">Privacy Policy</a></li>
                    <li><a href="<?php echo home_url('/terms-of-service'); ?>">Terms of Service</a></li>
                </ul>
            </div>

            <!-- Contact -->
            <div class="footer-col">
                <h4>Contact Us</h4>
                <ul class="footer-contact">
                    <li>
                        <span class="footer-contact-icon">📍</span>
                        <span><strong style="color:#fff;">India:</strong> 1-74 Ambe Village Near Chikhodra Chokdi Anand, Gujarat 388001</span>
                    </li>
                    <li>
                        <span class="footer-contact-icon">📍</span>
                        <span><strong style="color:#fff;">UK:</strong> United Kingdom</span>
                    </li>
                    <li>
                        <span class="footer-contact-icon">📞</span>
                        <div>
                            <a href="tel:<?php echo preg_replace('/[^0-9+]/', '', advertza_opt('phone_india', '+919725487887')); ?>">
                                🇮🇳 <?php echo esc_html( advertza_opt('phone_india', '+91 97254 87887') ); ?>
                            </a><br>
                            <a href="tel:<?php echo preg_replace('/[^0-9+]/', '', advertza_opt('phone_uk', '+447442193744')); ?>" style="display:block;margin-top:0.2rem;">
                                🇬🇧 <?php echo esc_html( advertza_opt('phone_uk', '+44 7442 193744') ); ?>
                            </a>
                        </div>
                    </li>
                    <li>
                        <span class="footer-contact-icon">✉️</span>
                        <a href="mailto:<?php echo esc_attr( advertza_opt('email', 'hello@advertza.com') ); ?>">
                            <?php echo esc_html( advertza_opt('email', 'hello@advertza.com') ); ?>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>

    <!-- Bottom bar -->
    <div style="border-top:1px solid hsl(220 14% 22%);">
        <div class="container" style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:1rem;padding-top:1.25rem;padding-bottom:1.25rem;">
            <p style="font-size:0.75rem;color:rgba(255,255,255,0.4);">
                &copy; <?php echo date('Y'); ?> Advertza. All rights reserved.
            </p>
            <span style="font-size:0.75rem;color:rgba(255,255,255,0.4);display:flex;align-items:center;gap:6px;">
                <span style="display:inline-block;width:7px;height:7px;border-radius:50%;background:var(--gold);"></span>
                Offices in UK &amp; India
            </span>
        </div>
    </div>
</footer>

<!-- WhatsApp Button -->
<a href="https://wa.me/<?php echo esc_attr( advertza_opt('whatsapp', '919725487887') ); ?>?text=Hello!%20I'd%20like%20to%20discuss%20my%20marketing%20needs."
   class="whatsapp-btn" target="_blank" rel="noopener noreferrer" aria-label="Chat on WhatsApp">
    <svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
        <path d="M16 0C7.163 0 0 7.163 0 16c0 2.824.734 5.476 2.018 7.779L0 32l8.451-2.018A15.94 15.94 0 0016 32c8.837 0 16-7.163 16-16S24.837 0 16 0zm8.278 22.389c-.344.968-1.998 1.85-2.75 1.963-.704.105-1.596.149-2.574-.161-.595-.19-1.358-.446-2.332-.873-4.101-1.771-6.779-5.9-6.984-6.172-.205-.272-1.671-2.219-1.671-4.231s1.059-3.003 1.435-3.414c.376-.411.82-.513 1.094-.513.273 0 .547.003.786.015.252.012.59-.096.923.703.344.82 1.168 2.832 1.27 3.037.103.205.171.445.034.717-.137.273-.205.444-.41.683-.205.239-.431.534-.615.716-.205.205-.418.427-.18.838.239.411 1.059 1.748 2.274 2.832 1.562 1.393 2.879 1.825 3.29 2.03.41.205.649.171.888-.103.239-.273 1.024-1.196 1.297-1.606.272-.411.547-.342.923-.205.376.137 2.388 1.127 2.798 1.332.41.205.683.308.786.479.103.172.103 1.001-.24 1.969z"/>
    </svg>
</a>

<?php wp_footer(); ?>
</body>
</html>
